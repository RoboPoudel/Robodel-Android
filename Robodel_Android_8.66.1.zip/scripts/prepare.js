// Copies the Robodel page and helper into the app project. Put Robodel_8_NN.html and Robodel_8_NN.py in the project folder (or pass the html path).
const fs = require('fs'), path = require('path'), root = path.join(__dirname, '..');
const latest = re => fs.readdirSync(root).filter(f => re.test(f)).sort((a, b) => (parseInt(a.match(/_(\d+)\./)[1]) - parseInt(b.match(/_(\d+)\./)[1]))).pop();
const html = process.argv[2] || latest(/^Robodel_8_\d+\.html$/), py = latest(/^Robodel_8_\d+\.py$/);
if (!html || !py) { console.error('Put Robodel_8_NN.html AND Robodel_8_NN.py in this folder first.'); process.exit(1); }
fs.mkdirSync(path.join(root, 'www'), { recursive: true });
const put = (from, to) => { try { fs.rmSync(to, { force: true }); } catch (e) { } fs.copyFileSync(from, to); fs.chmodSync(to, 0o644); };   // the zip may keep files read-only
put(path.join(root, html), path.join(root, 'www', 'index.html'));
const pydir = path.join(root, 'android', 'app', 'src', 'main', 'python'); fs.mkdirSync(pydir, { recursive: true });
put(path.join(root, py), path.join(pydir, 'robodel8.py'));
console.log('Using', html, 'and', py);
