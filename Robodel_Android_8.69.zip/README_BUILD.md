# Robodel for Android (8.69) — developed by Henry Poudel

One app, one install. The helper (live prices, alerts, robot, orders) is built into the app and starts by itself; a small notification "Robodel helper is running" shows while it works. You do not need Termux, Python or a second file.

## Build the APK on GitHub (no Android Studio needed)
1. Put this whole folder in a GitHub repository (or keep the single zip in the repository and use the workflow from the chat).
2. Actions tab → **Build Robodel APK** → **Run workflow**. It takes 10–15 minutes the first time.
3. Download **Robodel-APK** from the run, unzip, install `app-debug.apk`.
If the Settrade library cannot be added, the build still finishes but shows a yellow warning "NO live Settrade prices": tell the author.

## Build on a computer (Android Studio)
Install Node.js 22, Python 3.13 (Chaquopy needs it on the build machine), Android Studio (Java 21). Then:  `npm install`  `npm run sync`  and Build → Build APK(s) in the `android` folder.

## New version later
Replace `Robodel_8_NN.html` and `Robodel_8_NN.py` here (delete the old ones), then build again.

## Notes
* The first start takes a few seconds while the helper starts. Allow notifications when asked, so Android keeps the helper alive.
* Your API keys are stored only inside the app's private storage, never in the page or backups.
* Optional: the app can instead use a helper on your computer (About → Preferences → Phone and Android; start the helper with `--lan`). PIN, secrets and the real-order switch are never accepted over Wi-Fi.
* The APK is debug-signed: fine for your own phone. Google Play needs your own release key.
* Only 64-bit phones are supported (arm64-v8a and x86_64).
