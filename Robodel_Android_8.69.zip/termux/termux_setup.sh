#!/data/data/com.termux/files/usr/bin/sh
# Robodel helper on this phone (Termux). Run once:   sh termux_setup.sh
# Before: install Termux from F-Droid (not the old Play Store build) and put Robodel_8_69.py in your Download folder.
set -e
echo "== Robodel helper setup (Termux) =="
termux-setup-storage || true
sleep 2
pkg update -y
pkg install -y python python-cryptography openssl termux-api
mkdir -p "$HOME/robodel"
SRC=""
for d in "$PWD" "$HOME/storage/downloads" "$HOME/storage/shared/Download"; do
  [ -f "$d/Robodel_8_69.py" ] && SRC="$d" && break
done
if [ -z "$SRC" ]; then echo "Cannot find Robodel_8_69.py. Put it in your Download folder and run this again."; exit 1; fi
cp "$SRC/Robodel_8_69.py" "$HOME/robodel/robodel8.py"
[ -f "$SRC/Robodel_8_69.html" ] && cp "$SRC/Robodel_8_69.html" "$HOME/robodel/"
pip install --upgrade certifi pypdf || true
pip install settrade-v2 || echo "NOTE: settrade-v2 did not install. Live Settrade prices and orders will not work until it does (the rest of Robodel works)."
cat > "$HOME/robodel/start.sh" <<'EOF'
#!/data/data/com.termux/files/usr/bin/sh
# Starts the Robodel helper and keeps the phone's CPU awake while it runs.
termux-wake-lock 2>/dev/null || true
cd "$HOME/robodel"
NO_BROWSER=1 exec python robodel8.py "$@"
EOF
chmod +x "$HOME/robodel/start.sh"
echo
echo "Done. Start the helper any time with:   sh ~/robodel/start.sh"
echo "Then open the Robodel app. Keep Termux running (pull down its notification and tap Acquire wakelock)."
