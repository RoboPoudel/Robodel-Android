// Copies the Robodel page next to this project as www/index.html. Put Robodel_8_65.html in this folder (or pass its path).
const fs = require('fs'), path = require('path');
const src = process.argv[2] || fs.readdirSync(__dirname + '/..').filter(f => /^Robodel_8_\d+\.html$/.test(f)).sort().pop();
if (!src) { console.error('Put the Robodel html file (for example Robodel_8_65.html) in this folder first.'); process.exit(1); }
fs.mkdirSync(path.join(__dirname, '..', 'www'), { recursive: true });
fs.copyFileSync(path.resolve(__dirname, '..', src), path.join(__dirname, '..', 'www', 'index.html'));
console.log('Using', src);
