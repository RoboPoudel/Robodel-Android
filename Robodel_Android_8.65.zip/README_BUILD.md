# Robodel for Android (8.65) — developed by Henry Poudel

This folder is an Android app project (Capacitor) that wraps the Robodel page. It could not be compiled where it was made, so the first build is yours to run. Two ways:

## A. Build on GitHub (no Android Studio needed)
1. Create a new **private** GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab, choose **Build Robodel APK**, press **Run workflow**.
3. When it turns green, open the run and download the **Robodel-APK** file. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone and open it. Android will ask to allow installs from this source: allow it for that one app (your browser or Files).

## B. Build on a computer with Android Studio
1. Install Node.js 22 and Android Studio (it includes the Android SDK and Java 21).
2. In this folder run:  `npm install`  then  `npm run sync`
3. Open the `android` folder in Android Studio, press **Build > Build APK(s)**. The file is in `android/app/build/outputs/apk/debug/`.

## Using a new Robodel version later
Put the new `Robodel_8_NN.html` in this folder (delete the old one), then repeat A or B.

## The helper
The app is only the screen. Live prices, the robot and orders need the helper:
* **On this phone:** install Termux from F-Droid, put `Robodel_8_65.py` in Downloads, copy `termux/termux_setup.sh` there too, run `sh termux_setup.sh`, then `sh ~/robodel/start.sh`. The app finds it at http://localhost:8787 by itself.
* **On your computer:** run `python Robodel_8_65.py --lan`. In the app open About > Preferences > Phone and Android, type the address and pairing code the helper window prints, press Test connection, then Save and restart.

## Safety
* Your PIN, API secrets and the real-order switch are never accepted over Wi-Fi; do those on the computer, or on the phone when the helper runs on the phone itself.
* The Wi-Fi link is not encrypted. Use only your own home Wi-Fi.
* The APK is signed with a debug key. It is fine for your own phone. Publishing on Google Play needs a release key, which only you should hold.
