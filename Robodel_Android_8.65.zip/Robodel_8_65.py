#!/usr/bin/env python3
"""
Local data helper for Robodel 8.65, developed by Henry Poudel (SET & mai).

Browsers block web pages from reading Yahoo Finance directly. This tiny server
fetches the price data for the page and serves the page itself.

Works on Windows, macOS, Linux and Android (Pydroid 3 or Termux). Python 3.8+,
no extra packages needed.

  Windows:  double-click proxy.py, or run  py proxy.py  in the folder
  Android:  open proxy.py in Pydroid 3 and press Run (keep Pydroid open)
  Others:   python3 proxy.py

Then open http://localhost:8787 in your browser (the exact address is printed).
The page file can sit next to proxy.py or in Downloads/Documents; the newest
copy is served. You can also pass a folder:  python proxy.py /path/to/folder

Endpoints used by the page:
  /proxy?url=...      price history from Yahoo Finance charts
  /fund?symbol=PTT.BK company fundamentals and profile (Yahoo quoteSummary; needs
                      a session cookie and "crumb", which this helper manages)
  /iaa?symbol=PTT     IAA analyst consensus table from Settrade's portal page,
                      returned as JSON (best effort: the page layout may change)
  /9hoon?p=view_dividend.php&symbol=PTT
                      tables, links and text from the listed 9hoon.com pages
                      (cached 10 minutes); &check=1 reports whether a chart page
                      may be embedded in a frame
  /drlist             depositary receipts traded on SET, from SET's own data
                      service (best effort; the page has a built-in fallback list)
  /drratios           DR list with conversion ratios from the open-source SET DR
                      Collection (github.com/1sttati/set-dr-directory), cached a day
  /news?symbol=PTT&name=...&kind=dr
                      latest articles about the company from Kaohoon International
                      (full text, for summaries) and Google News (many publishers);
                      kind=dr adds SET news and news about the underlying company
  /tfex/config|test|quotes|account
                      TFEX derivatives through a second Settrade Open API login (view only):
                      /tfex/quotes?symbols=S50Z26,... gives live quotes
  /quote?symbols=PTT.BK,AOT.BK
                      live quotes for many symbols in ONE request (Yahoo v7, needs the
                      session crumb this helper manages); used for fast refreshes
  /siamchart/table    SiamChart's official Magic1, Magic2 and CG figures (and other
                      screener columns it finds), cached 30 minutes; ?url=... forces a
                      data address, ?force=1 skips the cache
  /siamchart/probe    diagnostic: finds where siamchart.com/stock/ loads its screener
                      table from, so the scanner can read those figures directly
  /robot/*            automatic-order guard: status, config, arm, kill, resume, order, cancel, audit log (python robodel8.py --kill = emergency stop)
  /dw/list            every DW symbol from siamchart.com/stock/DW
  /dw/history         daily price history of one DW (?sym=...), for the in-app DW chart
  /dw/quotes          DW prices and terms read from set.or.th (?syms=A,B,...)
  /wr/list            every company warrant symbol (ABC-W1 ...) from siamchart.com/stock/W and SET
  /wr/history         all daily history of one warrant (?sym=...): SET, SiamChart, Yahoo Finance
  /wr/quotes          warrant prices and terms read from set.or.th (?syms=A-W1,B-W2,...)
  /investor           SET investor-type statistics (foreign / institution / proprietary / individual net buy-sell) read from set.or.th when it allows
  /signs              SET sign postings (C, NP, SP ...) read from set.or.th when it allows; ?url=... forces an address
  /companies          every listed company's English and Thai name from SET's stock list (used to match shareholders to listed companies)
  /translate          POST {"strings": [...]} -> Thai to English (dictionary first,
                      then machine translation, cached in translations_cache.json)

Only Yahoo Finance chart endpoints are relayed, and the server listens on
127.0.0.1 only, so nothing on your network can use it.
"""
import html as htmllib
import http.cookiejar
import http.server
import json
import os
import re
import platform
import socket
import base64
import socketserver
import ssl
import sys
import threading
import traceback
import time
import urllib.error
import urllib.parse
import urllib.request

PORT = int(os.environ.get("PORT", "8787"))
try:
    HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:  # some phone editors run code without a file name
    HERE = os.getcwd()
IS_WINDOWS = os.name == "nt"
IS_ANDROID = "ANDROID_ROOT" in os.environ or "ANDROID_DATA" in os.environ or hasattr(sys, "getandroidapilevel")

# Windows consoles can choke on non-ASCII text; never let printing crash the helper
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:
        pass


def _writable(folder):
    try:
        test = os.path.join(folder, ".scanner_write_test")
        with open(test, "w") as f:
            f.write("ok")
        os.remove(test)
        return True
    except Exception:
        return False


# Where the translation cache is kept: next to proxy.py if possible, else the home folder
DATA_DIR = HERE if _writable(HERE) else os.path.expanduser("~")


def _make_ssl_context():
    """HTTPS with certificate checks on every platform.

    Python on Android (Pydroid 3, some Termux builds) often ships with an empty
    certificate store, so every HTTPS request fails. In that case load certifi
    if installed, or the phone's own system certificates."""
    ctx = ssl.create_default_context()
    if ctx.cert_store_stats().get("x509_ca", 0) > 0:
        return ctx, "system certificate store"
    try:
        import certifi
        ctx.load_verify_locations(certifi.where())
        return ctx, "certifi"
    except Exception:
        pass
    for f in ("/etc/ssl/certs/ca-certificates.crt", "/etc/pki/tls/certs/ca-bundle.crt", "/etc/ssl/cert.pem",
              "/data/data/com.termux/files/usr/etc/tls/cert.pem"):
        try:
            if os.path.isfile(f):
                ctx.load_verify_locations(f)
                return ctx, f
        except Exception:
            pass
    loaded = 0
    for d in ("/apex/com.android.conscrypt/cacerts", "/system/etc/security/cacerts"):
        try:
            for name in os.listdir(d):
                try:
                    ctx.load_verify_locations(os.path.join(d, name))
                    loaded += 1
                except Exception:
                    pass
        except Exception:
            pass
        if loaded:
            return ctx, f"Android system certificates ({loaded})"
    return ctx, "default (may be empty)"


SSL_CTX, SSL_SOURCE = _make_ssl_context()
PAGE = "Robodel_8_24.html"  # preferred name; see pick_page()
ALLOWED_HOSTS = {"query1.finance.yahoo.com", "query2.finance.yahoo.com"}
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
FUND_MODULES = "price,summaryDetail,defaultKeyStatistics,financialData,assetProfile"
SYMBOL_RE = re.compile(r"^[\^A-Za-z0-9&.\-]{1,24}$")

_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=SSL_CTX),
                                      urllib.request.HTTPCookieProcessor(_jar))
_crumb = {"value": None, "at": 0.0}
_crumb_lock = threading.Lock()


EXTRA_DIRS = []   # folders given on the command line or in SCANNER_DIR


def page_folders():
    home = os.path.expanduser("~")
    dirs = EXTRA_DIRS + [HERE, os.getcwd()]
    if IS_ANDROID:
        for base in ("/storage/emulated/0", "/sdcard"):
            dirs += [os.path.join(base, x) for x in ("Download", "Downloads", "Documents", "Pydroid3", "")]
    dirs += [os.path.join(home, x) for x in ("Downloads", "Download", "Desktop", "Documents")]
    seen, out = set(), []
    for d in dirs:
        d = os.path.abspath(d)
        if d not in seen:
            seen.add(d)
            out.append(d)
    return out


PAGE_ERRORS = {}


def pick_page():
    """Full path of the newest page copy.

    Browsers often save a fresh download as "wyckoff_radar_set (1).html", so any file
    whose name starts with "robodel" or "wyckoff_radar_set" counts, and the newest one wins. Other
    .html files are only used when they sit next to proxy.py."""
    found = []
    PAGE_ERRORS.clear()
    for d in page_folders():
        try:
            names = os.listdir(d)
        except FileNotFoundError:
            continue
        except Exception as e:
            PAGE_ERRORS[d] = str(e)
            continue
        for f in names:
            if f.lower().startswith(("robodel", "wyckoff_radar_set")) and f.lower().endswith(".html"):
                found.append(os.path.join(d, f))
    if not found:
        try:
            found = [os.path.join(HERE, f) for f in os.listdir(HERE) if f.lower().endswith(".html")]
        except Exception:
            found = []
    if not found:
        return None

    def mtime(p):
        try:
            return os.path.getmtime(p)
        except Exception:
            return 0
    return max(found, key=mtime)


def _open(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    return _opener.open(req, timeout=timeout)


def get_crumb(force=False):
    """Yahoo's fundamentals API needs a session cookie plus a matching crumb."""
    with _crumb_lock:
        if _crumb["value"] and not force and time.time() - _crumb["at"] < 3600:
            return _crumb["value"]
        try:
            _open("https://fc.yahoo.com", 10).read()
        except Exception:
            pass  # this page answers 404 but still sets the session cookie
        crumb = _open("https://query1.finance.yahoo.com/v1/test/getcrumb").read().decode().strip()
        if not crumb or "<" in crumb or len(crumb) > 40:
            raise RuntimeError("Yahoo did not issue a session crumb")
        _crumb.update(value=crumb, at=time.time())
        return crumb


IAA_URL = ("https://portal.settrade.com/AnalystConsensus/C04_10_stock_saa_p1.jsp"
           "?txtSymbol={sym}&ssoPageId=11&selectPage=10")


def _cells(row_html):
    cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row_html, re.S | re.I)
    out = []
    for c in cells:
        c = re.sub(r"<[^>]+>", " ", c)
        c = c.replace("&nbsp;", " ").replace("&amp;", "&")
        out.append(re.sub(r"\s+", " ", c).strip())
    return out


def fetch_iaa(symbol):
    """Parse the per-broker IAA consensus table. Returns rows or raises."""
    url = IAA_URL.format(sym=urllib.parse.quote(symbol))
    with _open(url, 20) as r:
        raw = r.read()
    html = raw.decode("cp874", errors="ignore")
    rows, header = [], None
    for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", html, re.S | re.I):
        cells = _cells(tr)
        if not cells:
            continue
        joined = " ".join(cells).lower()
        if header is None and "broker" in joined and "target" in joined:
            header = [c.lower() for c in cells]
            continue
        if header and cells[0].isdigit() and len(cells) >= 4:
            def col(*names):
                for i, hcell in enumerate(header):
                    if any(n in hcell for n in names) and i < len(cells):
                        return cells[i]
                return ""
            rows.append({
                "broker": col("broker") or (cells[1] if len(cells) > 1 else ""),
                "target": col("target"),
                "rec": col("rec"),
                "date": col("update", "date"),
            })
    if not rows:
        raise RuntimeError("No IAA consensus table found for this symbol")
    return {"source_url": url, "rows": rows}


KAOHOON = "https://www.kaohooninternational.com"
NAME_SUFFIX = re.compile(r"\s*(public company limited|public co\.?,? ltd\.?|pcl\.?|co\.?,? ltd\.?|corporation|holdings?)\s*$", re.I)


def _text(s):
    s = (s or "").replace("<![CDATA[", "").replace("]]>", "")
    s = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", s, flags=re.S | re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", htmllib.unescape(s)).strip()


def _mentions(sym, title, text):
    """True when an article is really about this ticker, not just a substring match."""
    blob = f"{title} {text}"
    if f"SET: {sym}" in blob or f"SET:{sym}" in blob or f"({sym})" in blob:
        return True
    pat = rf"(?<![A-Za-z0-9]){re.escape(sym)}(?![A-Za-z0-9])"
    if len(sym) >= 3 and re.search(pat, title):
        return True
    return len(sym) >= 4 and bool(re.search(pat, text[:800]))


def _iso(rfc822):
    try:
        from email.utils import parsedate_to_datetime
        return parsedate_to_datetime(rfc822).isoformat()
    except Exception:
        return rfc822 or ""


def _rss_items(xml):
    out = []
    for it in re.findall(r"<item>(.*?)</item>", xml, re.S):
        def tag(name):
            m = re.search(rf"<{name}[^>]*>(.*?)</{name}>", it, re.S)
            return m.group(1) if m else ""
        src = re.search(r"<source[^>]*>(.*?)</source>", it, re.S)
        out.append({"title": _text(tag("title")), "link": _text(tag("link")), "date": _iso(_text(tag("pubDate"))),
                    "desc": tag("description"), "content": tag("content:encoded"),
                    "source": _text(src.group(1)) if src else ""})
    return out


def kaohoon_news(sym, limit=10):
    items = []
    try:
        url = (f"{KAOHOON}/wp-json/wp/v2/posts?search={urllib.parse.quote(sym)}"
               "&per_page=30&_fields=id,date,link,title,excerpt,content")
        with _open(url, 20) as r:
            posts = json.loads(r.read().decode("utf-8", "ignore"))
        for p in posts:
            title = _text(p.get("title", {}).get("rendered", ""))
            body = _text(p.get("content", {}).get("rendered", ""))
            if not _mentions(sym, title, body):
                continue
            items.append({"id": f"kh{p.get('id')}", "source": "Kaohoon International", "title": title,
                          "url": p.get("link"), "date": p.get("date"),
                          "excerpt": _text(p.get("excerpt", {}).get("rendered", ""))[:700], "text": body[:4000]})
    except Exception:
        # Fallback: WordPress search feed
        with _open(f"{KAOHOON}/?s={urllib.parse.quote(sym)}&feed=rss2", 20) as r:
            xml = r.read().decode("utf-8", "ignore")
        for i, it in enumerate(_rss_items(xml)):
            body = _text(it["content"]) or _text(it["desc"])
            if not _mentions(sym, it["title"], body):
                continue
            items.append({"id": f"khr{i}-{abs(hash(it['link'])) % 10**8}", "source": "Kaohoon International",
                          "title": it["title"], "url": it["link"], "date": it["date"],
                          "excerpt": _text(it["desc"])[:700], "text": body[:4000]})
    return items[:limit]


def google_news(sym, name, limit=10):
    short = NAME_SUFFIX.sub("", name or "").strip()
    q = f'"{short}" Thailand when:30d' if short and short.upper() != sym else f'"{sym}" SET Thailand when:30d'
    url = "https://news.google.com/rss/search?" + urllib.parse.urlencode({"q": q, "hl": "en-TH", "gl": "TH", "ceid": "TH:en"})
    with _open(url, 20) as r:
        xml = r.read().decode("utf-8", "ignore")
    items = []
    for it in _rss_items(xml)[:limit]:
        title = it["title"]
        if it["source"] and title.endswith(" - " + it["source"]):
            title = title[: -len(it["source"]) - 3]
        items.append({"id": f"gn{abs(hash(it['link'])) % 10**10}", "source": it["source"] or "Google News",
                      "title": title, "url": it["link"], "date": it["date"], "excerpt": "", "text": ""})
    return items


def fetch_news(sym, name):
    out, errors, seen = [], {}, set()
    for label, fn in (("kaohoon", lambda: kaohoon_news(sym)), ("google", lambda: google_news(sym, name)), ("set", lambda: set_news(sym, 60))):
        try:
            for it in fn():
                key = re.sub(r"\W+", "", it["title"].lower())[:80]
                if key and key not in seen:
                    seen.add(key)
                    out.append(it)
        except Exception as e:
            errors[label] = str(e)
    out.sort(key=lambda x: x.get("date") or "", reverse=True)
    return {"items": out, "errors": errors}


_wn_cache = {}


def watch_news(syms):
    """Headlines for several stocks at once (cached 15 minutes per stock)."""
    now, out, errs = time.time(), {}, {}

    def one(sy):
        c = _wn_cache.get(sy)
        if c and now - c[0] < 900:
            out[sy] = c[1]
            return
        try:
            r = fetch_news(sy, "")
            items = [{k: it.get(k) for k in ("title", "url", "source", "date")} for it in r["items"][:12]]
            _wn_cache[sy] = (time.time(), items)
            out[sy] = items
            if r["errors"] and not items:
                errs[sy] = "; ".join("%s: %s" % kv for kv in r["errors"].items())[:140]
        except Exception as e:
            errs[sy] = str(e)[:120]
    ths = [threading.Thread(target=one, args=(s_,), daemon=True) for s_ in syms]
    for i in range(0, len(ths), 5):
        for t in ths[i:i + 5]:
            t.start()
        for t in ths[i:i + 5]:
            t.join(25)
    return {"ok": True, "items": out, "errors": errs, "at": int(time.time() * 1000)}


# ---------------------------------------------------------------- 9hoon.com
NINEHOON = "https://9hoon.com/aset/"
NINEHOON_PAGES = {
    "view_shareholder.php", "view_research_reports.php", "view_pe_valuation.php",
    "view_financials_table.php", "view_dividend.php", "view_stock_news.php",
    "view_index_stocks.php", "view_index_overview.php", "stock_screener.php", "view_tv_pe_chart.php", "view_tv_financials_chart.php",
    "view_tv_chart.php",
}
NINEHOON_PARAMS = {"symbol", "index", "page", "q"}
_cache = {}
_cache_lock = threading.Lock()


class _Node:
    __slots__ = ("tag", "attrs", "children", "parent")

    def __init__(self, tag, attrs, parent):
        self.tag, self.attrs, self.children, self.parent = tag, dict(attrs), [], parent

    def text(self):
        out = []
        for c in self.children:
            out.append(c if isinstance(c, str) else c.text())
        return " ".join(x for x in out if x)

    def iter(self, tag=None):
        for c in self.children:
            if isinstance(c, _Node):
                if tag is None or c.tag == tag:
                    yield c
                yield from c.iter(tag)


VOID = {"br", "img", "input", "meta", "link", "hr", "area", "base", "col", "source", "wbr"}
SKIP = {"script", "style", "noscript", "svg"}


class _Tree(__import__("html.parser").parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = _Node("root", {}, None)
        self.cur = self.root
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in SKIP:
            self.skip += 1
            return
        if self.skip:
            return
        node = _Node(tag, attrs, self.cur)
        self.cur.children.append(node)
        if tag not in VOID:
            self.cur = node

    def handle_endtag(self, tag):
        if tag in SKIP:
            self.skip = max(0, self.skip - 1)
            return
        if self.skip:
            return
        n = self.cur
        while n is not self.root and n.tag != tag:
            n = n.parent
        if n is not self.root:
            self.cur = n.parent

    def handle_data(self, data):
        if not self.skip:
            d = re.sub(r"\s+", " ", data).strip()
            if d:
                self.cur.children.append(d)


def _clean(s):
    return re.sub(r"\s+", " ", s or "").strip()


def _abs(href):
    return urllib.parse.urljoin(NINEHOON, href or "")


def parse_9hoon(html_text, url):
    t = _Tree()
    t.feed(html_text)
    root = t.root
    title = ""
    for h in root.iter():
        if h.tag in ("h1", "h2"):
            title = _clean(h.text())
            if title:
                break
    tables = []
    for tb in root.iter("table"):
        if any(p.tag == "table" for p in _ancestors(tb)):
            continue
        rows = []
        for tr in tb.iter("tr"):
            cells = []
            for td in tr.children:
                if isinstance(td, _Node) and td.tag in ("td", "th"):
                    a = next(td.iter("a"), None)
                    cells.append({"t": _clean(td.text()), "h": _abs(a.attrs.get("href")) if a is not None and a.attrs.get("href", "").strip() not in ("", "#") else None,
                                  "th": td.tag == "th", "span": int(td.attrs.get("colspan", "1") or 1) if str(td.attrs.get("colspan", "1")).isdigit() else 1})
            if cells:
                rows.append(cells)
        if rows:
            cap = next(tb.iter("caption"), None)
            tables.append({"caption": _clean(cap.text()) if cap is not None else _heading_before(tb), "rows": rows[:2500]})
    links = []
    for a in root.iter("a"):
        href = a.attrs.get("href", "")
        if not href or href.startswith(("#", "javascript", "about:")):
            continue
        box = _box(a)
        links.append({"text": _clean(a.text()), "href": _abs(href), "context": _clean(box.text())[:600] if box is not None else ""})
    body = next(root.iter("body"), root)
    return {"source_url": url, "title": title, "tables": tables, "links": links[:400], "text": _clean(body.text())[:20000]}


def _ancestors(n):
    p = n.parent
    while p is not None:
        yield p
        p = p.parent


def _heading_before(node):
    """Nearest heading text that comes before a table, used as its caption."""
    p = node
    for _ in range(4):
        par = p.parent
        if par is None:
            break
        idx = par.children.index(p)
        for sib in reversed(par.children[:idx]):
            if isinstance(sib, _Node):
                hs = [sib] if sib.tag in ("h1", "h2", "h3", "h4", "h5") else list(x for x in sib.iter() if x.tag in ("h2", "h3", "h4", "h5"))
                if hs:
                    return _clean(hs[-1].text())[:160]
        p = par
    return ""


def _box(a):
    """Smallest block around a link that carries some context (date, rating...)."""
    own = len(_clean(a.text()))
    for p in _ancestors(a):
        if p.tag in ("tr", "li", "article", "div", "section", "p") and len(_clean(p.text())) > own + 15:
            return p
        if p.tag in ("body", "root"):
            return None
    return None


def fetch_9hoon(page, params, check=False):
    if page not in NINEHOON_PAGES:
        raise ValueError("Page not allowed")
    q = {k: v for k, v in params.items() if k in NINEHOON_PARAMS and re.match(r"^[A-Za-z0-9&._\-]{1,30}$", v)}
    url = NINEHOON + page + ("?" + urllib.parse.urlencode(q) if q else "")
    if check:
        try:
            with _open(url, 15) as r:
                xfo = (r.headers.get("X-Frame-Options") or "").lower()
                csp = (r.headers.get("Content-Security-Policy") or "").lower()
        except urllib.error.HTTPError as e:
            return {"source_url": url, "frameable": False, "reason": f"HTTP {e.code}"}
        fa = re.search(r"frame-ancestors([^;]*)", csp)
        blocked = xfo in ("deny", "sameorigin") or (fa is not None and "*" not in fa.group(1))
        return {"source_url": url, "frameable": not blocked, "reason": xfo or (fa.group(0) if fa else "")}
    with _cache_lock:
        hit = _cache.get(url)
        if hit and time.time() - hit[0] < 600:
            return hit[1]
    with _open(url, 25) as r:
        raw = r.read()
        ctype = r.headers.get("Content-Type", "")
    m = re.search(r"charset=([\w-]+)", ctype)
    enc = m.group(1) if m else "utf-8"
    try:
        text = raw.decode(enc)
    except Exception:
        text = raw.decode("utf-8", "ignore")
    data = parse_9hoon(text, url)
    with _cache_lock:
        _cache[url] = (time.time(), data)
        if len(_cache) > 300:
            for k in sorted(_cache, key=lambda k: _cache[k][0])[:100]:
                _cache.pop(k, None)
    return data


# ---------------------------------------------------------------- Thai -> English
THAI = re.compile(r"[฀-๿]")
TR_FILE = os.path.join(DATA_DIR, "translations_cache.json")
_tr_lock = threading.Lock()
try:
    with open(TR_FILE, encoding="utf-8") as _f:
        _tr_cache = json.load(_f)
except Exception:
    _tr_cache = {}

# Exact labels used on 9hoon pages. Checked first so financial terms are always consistent.
TH_EN = {
    # financial statements
    "งบกำไรขาดทุน": "Income statement", "งบดุล": "Balance sheet", "กระแสเงินสด": "Cash flow",
    "รายได้รวม": "Total revenue", "ต้นทุนขาย": "Cost of sales", "กำไรขั้นต้น": "Gross profit",
    "% กำไรขั้นต้น (GPM)": "Gross margin % (GPM)", "ค่าใช้จ่ายในการขายและบริหาร": "Selling & admin expenses (SG&A)",
    "% SG&A ต่อรายได้": "SG&A % of revenue", "กำไรจากการดำเนินงาน": "Operating profit",
    "% กำไรจากการดำเนินงาน (OPM)": "Operating margin % (OPM)", "กำไรก่อนภาษี": "Profit before tax",
    "ภาษีเงินได้": "Income tax", "กำไรสุทธิ": "Net profit", "% กำไรสุทธิ (NPM)": "Net margin % (NPM)",
    "EPS (บาท/หุ้น)": "EPS (THB/share)", "ค่าเสื่อมราคาและค่าตัดจำหน่าย *": "Depreciation & amortisation *",
    "ค่าเสื่อมราคาและค่าตัดจำหน่าย": "Depreciation & amortisation",
    "สินทรัพย์รวม": "Total assets", "หนี้สินรวม": "Total liabilities", "ส่วนของผู้ถือหุ้น": "Shareholders’ equity",
    "หนี้สินที่มีภาระดอกเบี้ย": "Interest-bearing debt", "หนี้สินสุทธิ": "Net debt",
    "BVPS (มูลค่าทางบัญชีต่อหุ้น)": "BVPS (book value per share)",
    "D/E (หนี้สินรวม ÷ ส่วนผู้ถือหุ้น)": "D/E (total liabilities ÷ equity)",
    "กระแสเงินสดจากดำเนินงาน (CFO)": "Cash flow from operations (CFO)",
    "กระแสเงินสดจากลงทุน (CFI)": "Cash flow from investing (CFI)",
    "กระแสเงินสดจากจัดหาเงิน (CFF)": "Cash flow from financing (CFF)",
    "กระแสเงินสดอิสระ (FCF)": "Free cash flow (FCF)", "รายการ": "Item",
    "ตารางงบการเงินรายไตรมาส": "Quarterly financial statements",
    "กำไรรายไตรมาส": "Quarterly net profit", "กำไรสุทธิรายไตรมาส": "Quarterly net profit",
    # dividends
    "ประวัติการจ่ายปันผล": "Dividend history", "ประวัติการจ่ายปันผลและคืนทุน": "Dividend and capital return history",
    "วันขึ้นเครื่องหมาย": "Ex-date", "วันปิดสมุด": "Record date", "จำนวนเงิน/หน่วย": "Amount/share",
    "ประเภท": "Type", "อัตราส่วน": "Ratio", "วันจ่ายเงิน": "Payment date", "รอบผลประกอบการ": "Operating period",
    "เงินปันผลจาก": "Paid from", "เงินปันผล": "Cash dividend", "ปันผลจากกำไรสุทธิ": "From net profit",
    "ปันผลจากกำไรสะสม": "From retained earnings", "คืนทุน": "Capital return", "ปันผลเป็นหุ้น": "Stock dividend",
    "ยอดรวมปันผล/คืนทุนรายปีงบ (บาท/หุ้น)": "Total dividend / capital return per fiscal year (THB/share)",
    "ปันผล (XD) คืนทุน (XN)": "Dividend (XD) · Capital return (XN)",
    # shareholders
    "อันดับ": "Rank", "ชื่อผู้ถือหุ้น": "Shareholder", "จำนวนหุ้น": "Shares", "% การถือหุ้น": "% held",
    "เปลี่ยนแปลง": "Change", "ไม่เปลี่ยนแปลง": "No change", "- ไม่เปลี่ยนแปลง": "- No change", "ใหม่": "New",
    "ผู้ถือหุ้น": "Shareholders", "ผู้ถือหุ้นรายใหญ่": "Major shareholders",
    # P/E valuation and stats
    "มูลค่าหุ้น": "Share valuation", "เครื่องคำนวณมูลค่าหุ้น": "Share value calculator",
    "เครื่องคำนวณมูลค่าหุ้น (PE Valuation)": "Share value calculator (P/E valuation)",
    "ราคา (บาท)": "Price (THB)", "จำนวนหุ้น (ล้านหุ้น)": "Shares (million)", "กำไร (ล้านบาท)": "Profit (THB m)",
    "กำไรปีนี้ (F)": "Profit this year (F)", "กำไรปีหน้า (F+1)": "Profit next year (F+1)", "PE (เท่า)": "P/E (x)",
    "ล่าสุด": "Latest", "เฉลี่ย 4 ปี": "4-year average", "มัธยฐาน": "Median", "ต่ำสุด": "Low", "สูงสุด": "High",
    "ปัจจุบันห่างเฉลี่ย": "Distance from average", "ราคาล่าสุด": "Last price", "ล้านบาท": "THB m",
    "บาท": "THB", "บาท/หุ้น": "THB/share", "เท่า": "x", "ปี": "Year", "รายปีงบ": "By fiscal year",
    "ย้อนหลัง 4 ปี": "Last 4 years", "ย้อนหลัง 10 ไตรมาส": "Last 10 quarters",
    # research / news / navigation
    "บทวิเคราะห์": "Research reports", "เป้าหมาย": "Target", "ข่าว": "News", "ข่าวหุ้น": "Stock news",
    "เปิดที่ SET": "Open on SET", "เปิดฉบับเต็มในแท็บใหม่ ↗": "Open full report in new tab ↗",
    "ภาพรวมตลาด": "Market overview", "คัดกรองหุ้น": "Stock screener", "หุ้นรายตัว": "Individual stock",
    "งบ": "Financials", "ปันผล": "Dividends", "กราฟ": "Chart", "ดูตาราง": "View table",
    "งบการเงินแบบกราฟ": "Financial charts", "งบการเงินแบบตาราง": "Financial tables", "หน้าหลักหุ้นตัวนี้": "Stock home",
}
TH_MONTH = {"ม.ค.": "Jan", "ก.พ.": "Feb", "มี.ค.": "Mar", "เม.ย.": "Apr", "พ.ค.": "May", "มิ.ย.": "Jun",
            "ก.ค.": "Jul", "ส.ค.": "Aug", "ก.ย.": "Sep", "ต.ค.": "Oct", "พ.ย.": "Nov", "ธ.ค.": "Dec"}
_be = lambda m: str(int(m.group(0)) - 543)
RULES = [
    (re.compile(r"(\d{1,2})\s*(" + "|".join(re.escape(k) for k in TH_MONTH) + r")\s*(25\d\d)"),
     lambda m: f"{m.group(1)} {TH_MONTH[m.group(2)]} {int(m.group(3)) - 543}"),
    (re.compile(r"งบปี\s*(\d{4})\s*รวมปันผล\s*\((\w+)\)\s*:?\s*([\d.,]+)\s*บาท/หุ้น"), lambda m: f"FY{m.group(1)} total dividend ({m.group(2)}): {m.group(3)} THB/share"),
    (re.compile(r"ณ\s*วันปิดสมุด\s*"), lambda m: "As of record date "),
    (re.compile(r"รวม\s*\((\d+)\s*ราย\)"), lambda m: f"Total ({m.group(1)} holders)"),
    (re.compile(r"ปี\s*(25\d\d)F\s*/\s*(25\d\d)F"), lambda m: f"FY{int(m.group(1)) - 543}F/{int(m.group(2)) - 543}F"),
    (re.compile(r"ปี\s*(25\d\d)F?"), lambda m: f"FY{int(m.group(1)) - 543}" + ("F" if m.group(0).endswith("F") else "")),
    (re.compile(r"(\d+)\s*วันก่อน"), lambda m: f"{m.group(1)} days ago"),
    (re.compile(r"(\d+)\s*ชั่วโมงก่อน"), lambda m: f"{m.group(1)} hours ago"),
    (re.compile(r"(\d+)\s*นาทีก่อน"), lambda m: f"{m.group(1)} minutes ago"),
    (re.compile(r"เมื่อวาน"), lambda m: "yesterday"),
    (re.compile(r"(\d+)\s*ไตรมาส"), lambda m: f"{m.group(1)} quarters"),
    (re.compile(r"ไม่เปลี่ยนแปลง"), lambda m: "No change"),
    (re.compile(r"เป้าหมาย"), lambda m: "Target"),
    (re.compile(r"เปิดฉบับเต็มในแท็บใหม่"), lambda m: "Open full report in new tab"),
    (re.compile(r"เปิดที่ SET"), lambda m: "Open on SET"),
    (re.compile(r"ล้านบาท"), lambda m: "THB m"),
    (re.compile(r"บาท/หุ้น"), lambda m: "THB/share"),
    (re.compile(r"(?<=\d)\s*บาท"), lambda m: " THB"),
]
# Longest labels first, so "กำไรขั้นต้น" inside a longer label is replaced as part of it
_PHRASES = sorted(((k, v) for k, v in TH_EN.items() if len(k) >= 3), key=lambda kv: -len(kv[0]))


def _rule_translate(s):
    s0 = s.strip()
    if s0 in TH_EN:
        return TH_EN[s0]
    out = s0
    for rx, fn in RULES:
        out = rx.sub(fn, out)
    for k, v in _PHRASES:
        if k in out:
            out = out.replace(k, v)
    return out


def _gtx(text):
    """Machine translation through Google Translate's public web endpoint."""
    url = "https://translate.googleapis.com/translate_a/single?" + urllib.parse.urlencode(
        {"client": "gtx", "sl": "th", "tl": "en", "dt": "t", "q": text})
    with _open(url, 15) as r:
        data = json.loads(r.read().decode("utf-8"))
    return "".join(part[0] for part in data[0] if part and part[0]).strip()


def translate_many(strings):
    """Returns ({original: english}, [untranslated]). Exact labels and dates use the
    built-in dictionary; anything else is machine-translated and cached on disk."""
    result, todo = {}, []
    for s in {x for x in strings if x and THAI.search(x)}:
        ruled = _rule_translate(s)
        if not THAI.search(ruled):
            result[s] = ruled
        elif s in _tr_cache:
            result[s] = _tr_cache[s]
        else:
            todo.append(s)
    failed = []
    if todo:
        from concurrent.futures import ThreadPoolExecutor

        def one(s):
            try:
                return s, _gtx(s[:4500])
            except Exception:
                return s, None
        with ThreadPoolExecutor(max_workers=6) as ex:
            got = list(ex.map(one, todo))
        new = {}
        for s, t in got:
            if t and not THAI.search(t):
                result[s] = new[s] = t
            else:
                failed.append(s)   # left in Thai: the page can ask Claude, or show the original
        if new:
            with _tr_lock:
                _tr_cache.update(new)
                try:
                    with open(TR_FILE, "w", encoding="utf-8") as f:
                        json.dump(_tr_cache, f, ensure_ascii=False)
                except Exception:
                    pass
    return result, failed


def translate_9hoon(data, page):
    """Adds data['tr'] = {thai: english} for everything shown, except shareholder names."""
    keep = set()
    if page == "view_shareholder.php":
        for t in data.get("tables", []):
            if not t["rows"]:
                continue
            head = [c["t"] for c in t["rows"][0]]
            name_cols = {i for i, h in enumerate(head) if "ชื่อ" in h or "shareholder" in h.lower()}
            for r in t["rows"][1:]:
                for i, c in enumerate(r):
                    if i in name_cols or (c.get("h") or "").find("view_holder_portfolio") >= 0:
                        keep.add(c["t"])
        for l in data.get("links", []):
            if "view_holder_portfolio" in l.get("href", ""):
                keep.add(l.get("text", ""))
    strings = [data.get("title", "")]
    for t in data.get("tables", []):
        strings.append(t.get("caption", ""))
        for r in t["rows"]:
            strings.extend(c["t"] for c in r if c["t"] not in keep)
    for l in data.get("links", []):
        if l.get("text") not in keep:
            strings.append(l.get("text", ""))
        if page != "view_shareholder.php":
            strings.append(l.get("context", ""))
    if not data.get("tables") and not data.get("links"):
        data["text_short"] = data.get("text", "")[:1500]
        strings.append(data["text_short"])
    tr, failed = translate_many(strings)
    data["tr"], data["untranslated"] = tr, failed[:200]
    return data


# ---------------------------------------------------------------- SET: DR list and DR news
SET_BASE = "https://www.set.or.th"
DR_NAME = re.compile(r"depositary\s+receipts?\s+on\s+(.+?)\s+issued\s+by\s+(.+)$", re.I)


def _set_json(path):
    """GET a SET website data endpoint the way its own pages do (cookies + referer)."""
    try:
        _open(SET_BASE + "/en/market/product/dr/marketdata", 15).read()
    except Exception:
        pass
    req = urllib.request.Request(SET_BASE + path, headers={
        "User-Agent": UA, "Accept": "application/json, text/plain, */*",
        "Referer": SET_BASE + "/en/market/product/dr/marketdata", "Accept-Language": "en-US,en;q=0.9"})
    with _opener.open(req, timeout=20) as r:
        body = r.read().decode("utf-8", "ignore")
    try:
        return json.loads(body)
    except Exception:
        raise RuntimeError("SET answered with a web page instead of data (probably bot protection)")


def _dicts(obj):
    if isinstance(obj, dict):
        yield obj
        for v in obj.values():
            yield from _dicts(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _dicts(v)


def fetch_dr_list():
    j = _set_json("/api/set/stock/list")
    items, seen = [], set()
    for d in _dicts(j):
        sym = d.get("symbol")
        if not isinstance(sym, str) or sym in seen:
            continue
        name = next((v for k, v in d.items() if isinstance(v, str) and DR_NAME.search(v)), None)
        if not name:
            continue
        m = DR_NAME.search(name)
        seen.add(sym)
        items.append({"symbol": sym.upper(), "name": name.strip(), "underlying": m.group(1).strip(),
                      "issuer": m.group(2).strip(), "market": d.get("market") or ""})
    if not items:
        raise RuntimeError("SET's securities list had no depositary receipts")
    items.sort(key=lambda x: x["symbol"])
    return {"source_url": SET_BASE + "/en/market/product/dr/marketdata?tradeDateType=C", "items": items}


def set_news(sym, days=90):
    from datetime import date, timedelta
    to, fr = date.today(), date.today() - timedelta(days=days)
    q = urllib.parse.urlencode({"symbol": sym, "fromDate": fr.strftime("%d/%m/%Y"), "toDate": to.strftime("%d/%m/%Y"),
                                "keyword": "", "lang": "en"})
    j = _set_json("/api/set/news/search?" + q)
    out = []
    for d in _dicts(j):
        title = d.get("headline") or d.get("title")
        when = d.get("datetime") or d.get("date") or d.get("newsDate")
        if not isinstance(title, str) or not when:
            continue
        link = d.get("url") or d.get("link") or ""
        if link and link.startswith("/"):
            link = SET_BASE + link
        if not link and d.get("id"):
            link = f"{SET_BASE}/en/market/news-and-alert/newsdetails?id={d['id']}&symbol={urllib.parse.quote(sym)}"
        out.append({"id": f"set{d.get('id') or abs(hash(title)) % 10**8}", "source": "SET news", "title": _clean(title),
                    "url": link, "date": str(when), "excerpt": "", "text": ""})
    return out[:15]


def google_news_q(q, hl="en-US", gl="US", ceid="US:en", limit=10):
    url = "https://news.google.com/rss/search?" + urllib.parse.urlencode({"q": q, "hl": hl, "gl": gl, "ceid": ceid})
    with _open(url, 20) as r:
        xml = r.read().decode("utf-8", "ignore")
    items = []
    for it in _rss_items(xml)[:limit]:
        title = it["title"]
        if it["source"] and title.endswith(" - " + it["source"]):
            title = title[: -len(it["source"]) - 3]
        items.append({"id": f"gn{abs(hash(it['link'])) % 10**10}", "source": it["source"] or "Google News",
                      "title": title, "url": it["link"], "date": it["date"], "excerpt": "", "text": ""})
    return items



_ix_news = {}


def index_news(name, country, sym):
    key = (name, country)
    c = _ix_news.get(key)
    if c and time.time() - c[0] < 900:
        return c[1]
    errs = {}
    seen, items = set(), []
    queries = [f'"{name}" when:14d', f'{name} {country} stock market when:14d', f'{country} stock market index when:7d']
    for q in queries:
        if len(items) >= 6:
            break
        try:
            for it in google_news_q(q, limit=10):
                k = re.sub(r"\W+", "", it["title"].lower())[:60]
                if k and k not in seen:
                    seen.add(k)
                    items.append(it)
        except Exception as e:
            errs["google"] = str(e)[:100]
    def ts(it):
        try:
            import datetime as _dt
            return _dt.datetime.fromisoformat(str(it["date"]).replace("Z", "+00:00")).timestamp()
        except Exception:
            return 0
    items.sort(key=ts, reverse=True)
    out = {"items": items[:10], "errors": errs}
    if items or not errs:
        _ix_news[key] = (time.time(), out)
    return out


# ---------------------------------------------------------------- Macro news (economy, fiscal policy, central banks) by region
MACRO_REGIONS = {
    "th": {"name": "Thailand", "cb": "Bank of Thailand", "when": "7d", "gl": ("en-TH", "TH", "TH:en"),
           "th": {"economy": "เศรษฐกิจไทย GDP", "fiscal": "นโยบายการคลัง งบประมาณ รัฐบาล หนี้สาธารณะ", "central": "ธปท. กนง. อัตราดอกเบี้ย", "trade": "ส่งออก ไทย ภาษีนำเข้า สหรัฐ", "inflation": "เงินเฟ้อ ไทย ราคาสินค้า การจ้างงาน"}},
    "us": {"name": "United States", "cb": "Federal Reserve", "when": "3d", "gl": ("en-US", "US", "US:en")},
    "mm": {"name": "Myanmar", "cb": "Central Bank of Myanmar", "when": "14d", "gl": ("en-US", "US", "US:en")},
    "asean": {"name": "ASEAN", "cb": "ASEAN central banks", "when": "7d", "gl": ("en-SG", "SG", "SG:en"), "alt": "Southeast Asia"},
    "eu": {"name": "Europe", "cb": "European Central Bank ECB", "when": "3d", "gl": ("en-GB", "GB", "GB:en"), "alt": "Eurozone"},
    "cn": {"name": "China", "cb": "People's Bank of China", "when": "5d", "gl": ("en-US", "US", "US:en")},
    "jp": {"name": "Japan", "cb": "Bank of Japan", "when": "5d", "gl": ("en-US", "US", "US:en")},
    "in": {"name": "India", "cb": "Reserve Bank of India", "when": "5d", "gl": ("en-IN", "IN", "IN:en")},
    "world": {"name": "the global", "cb": "IMF World Bank OECD central banks", "when": "3d", "gl": ("en-US", "US", "US:en"), "alt": "world"},
}
MACRO_TOPICS = {"economy": "{r} economy GDP growth outlook", "fiscal": "{r} fiscal policy government budget deficit spending debt",
                "central": "{cb} interest rate decision monetary policy", "trade": "{r} trade exports tariffs", "inflation": "{r} inflation consumer prices jobs unemployment"}
_mn_cache = {}


def _iso_ts(d):
    try:
        import datetime as _dt
        return _dt.datetime.fromisoformat(str(d).replace("Z", "+00:00")).timestamp()
    except Exception:
        try:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(str(d)).timestamp()
        except Exception:
            return 0


def macro_news(region, topic, force=False):
    reg = MACRO_REGIONS.get(region)
    if not reg:
        return {"error": "Unknown region"}
    topic = topic if topic in MACRO_TOPICS else "all"
    key = (region, topic); c = _mn_cache.get(key)
    if c and not force and time.time() - c[0] < 900:
        return c[1]
    topics = list(MACRO_TOPICS) if topic == "all" else [topic]
    r = reg.get("alt") or reg["name"]; jobs = []
    for tp in topics:
        q = MACRO_TOPICS[tp].format(r=r, cb=reg["cb"]) + " when:" + reg["when"]
        hl, gl, ce = reg["gl"]; jobs.append((tp, q, hl, gl, ce, "en"))
        if tp in reg.get("th", {}):
            jobs.append((tp, reg["th"][tp] + " when:" + reg["when"], "th", "TH", "TH:th", "th"))
    results, errs, lock = [], {}, threading.Lock()

    def one(j):
        tp, q, hl, gl, ce, lang = j
        try:
            its = google_news_q(q, hl=hl, gl=gl, ceid=ce, limit=10)
            with lock:
                results.extend((tp, lang, it) for it in its)
        except Exception as e:
            with lock:
                errs[lang + ":" + tp] = str(e)[:100]
    ths = [threading.Thread(target=one, args=(j,), daemon=True) for j in jobs]
    for i in range(0, len(ths), 6):
        b = ths[i:i + 6]
        for t in b:
            t.start()
        for t in b:
            t.join(25)
    seen, items = set(), []
    for tp, lang, it in results:
        k = re.sub(r"\W+", "", it["title"].lower())[:70]
        if not k or k in seen:
            continue
        seen.add(k); items.append(dict(it, topic=tp, lang=lang))
    items.sort(key=lambda x: _iso_ts(x.get("date")), reverse=True)
    out = {"ok": True, "region": region, "name": reg["name"], "topic": topic, "items": items[:60], "errors": errs, "at": int(time.time() * 1000)}
    if items or not errs:
        _mn_cache[key] = (time.time(), out)
    return out


def kaohoon_by_name(name, sym, limit=6):
    short = NAME_SUFFIX.sub("", name or "").strip()
    if len(short) < 3:
        return []
    url = (f"{KAOHOON}/wp-json/wp/v2/posts?search={urllib.parse.quote(short)}"
           "&per_page=20&_fields=id,date,link,title,excerpt,content")
    with _open(url, 20) as r:
        posts = json.loads(r.read().decode("utf-8", "ignore"))
    out = []
    for p in posts:
        title = _text(p.get("title", {}).get("rendered", ""))
        if short.lower() not in title.lower() and sym not in title:
            continue
        body = _text(p.get("content", {}).get("rendered", ""))
        out.append({"id": f"kh{p.get('id')}", "source": "Kaohoon International", "title": title, "url": p.get("link"),
                    "date": p.get("date"), "excerpt": _text(p.get("excerpt", {}).get("rendered", ""))[:700], "text": body[:4000]})
    return out[:limit]


DR_DIR_URL = "https://raw.githubusercontent.com/1sttati/set-dr-directory/main/data/dr.json"
_dr_dir = {"at": 0.0, "data": None}
_DR_CTRY = {"us": "US", "cn": "China", "jp": "Japan", "vn": "Vietnam", "sg": "Singapore", "tw": "Taiwan", "eu": "Europe"}
_DR_CCY = {"HKD": "Hong Kong", "DKK": "Denmark", "EUR": "Europe"}


def fetch_dr_ratios():
    if _dr_dir["data"] and time.time() - _dr_dir["at"] < 86400:
        return _dr_dir["data"]
    with _open(DR_DIR_URL, 25) as r:
        items = json.loads(r.read().decode("utf-8"))
    out = []
    for x in items if isinstance(items, list) else []:
        name = (x.get("name") or x.get("symbol") or "").strip()
        if x.get("type") == "etf" and "etf" not in name.lower():
            name = "ETF: " + name
        ctry = _DR_CCY.get(x.get("ccy")) or _DR_CTRY.get(x.get("country"), "")
        for d in x.get("drs") or []:
            sym = str(d.get("sym") or "").upper()
            if not SYMBOL_RE.match(sym):
                continue
            ratio = d.get("ratio")
            try:
                ratio = float(ratio) if ratio not in (None, "") else None
            except (TypeError, ValueError):
                ratio = None
            out.append({"symbol": sym, "company": name, "country": ctry, "underlying": x.get("symbol") or "", "ratio": ratio})
    if not out:
        raise RuntimeError("The DR directory had no entries")
    data = {"source_url": "https://github.com/1sttati/set-dr-directory", "items": out}
    _dr_dir.update(at=time.time(), data=data)
    return data


def fetch_dr_news(sym, underlying):
    short = NAME_SUFFIX.sub("", underlying or "").strip()
    sources = [
        ("set", lambda: set_news(sym)),
        ("kaohoon", lambda: kaohoon_by_name(short, sym)),
        ("google", lambda: google_news_q(f'"{short}" when:30d') if short else []),
        ("google_th", lambda: google_news_q(f'"{sym}" DR when:90d', "en-TH", "TH", "TH:en", 6)),
    ]
    out, errors, seen = [], {}, set()
    for label, fn in sources:
        try:
            for it in fn():
                key = re.sub(r"\W+", "", it["title"].lower())[:80]
                if key and key not in seen:
                    seen.add(key)
                    out.append(it)
        except Exception as e:
            errors[label] = str(e)
    out.sort(key=lambda x: x.get("date") or "", reverse=True)
    return {"items": out, "errors": errors}


# ---------------------------------------------------------------- siamchart.com probe
SIAM = os.environ.get("SIAM_URL", "https://siamchart.com/stock/")
_URLISH = re.compile(r"""["'`]((?:https?:)?//?[^"'`\s<>]{2,200}?(?:\.php|\.json|\.csv|\.txt|\.js|/api/|ajax|data)[^"'`\s<>]{0,200})["'`]""", re.I)


def _same_site(url):
    a = urllib.parse.urlparse(url).netloc.split(":")[0].lower().replace("www.", "")
    b = urllib.parse.urlparse(SIAM).netloc.split(":")[0].lower().replace("www.", "")
    return bool(a) and a == b


def _get(url, limit=600_000, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*", "Referer": SIAM,
                                               "X-Requested-With": "XMLHttpRequest"})
    with _opener.open(req, timeout=timeout) as r:
        body = r.read(limit)
        return r.status, r.headers.get("Content-Type", ""), body


def siam_probe():
    """Reads the screener page and the scripts it loads, lists data-like URLs and
    tests each one for something that looks like the stock table."""
    out = {"page": SIAM, "scripts": [], "candidates": [], "inline_snippets": [], "tables": [], "errors": {}}
    try:
        st, ct, body = _get(SIAM)
        html = body.decode("utf-8", "ignore")
        out["page_status"], out["page_bytes"] = st, len(body)
    except Exception as e:
        out["errors"]["page"] = str(e)
        return out
    out["tables"] = [_clean(re.sub(r"<[^>]+>", " | ", t))[:600] for t in re.findall(r"<table.*?</table>", html, re.S | re.I)[:3]]
    srcs = re.findall(r"<script[^>]+src=[\"']([^\"']+)", html, re.I)
    inline = re.findall(r"<script(?![^>]*src=)[^>]*>(.*?)</script>", html, re.S | re.I)
    found = set()
    for code in inline:
        for m in _URLISH.finditer(code):
            found.add(m.group(1))
        for m in re.finditer(r"(\$\.(?:get|post|ajax|getJSON)|fetch|XMLHttpRequest|\.open\()[^;]{0,200}", code):
            out["inline_snippets"].append(_clean(m.group(0))[:240])
    for src in srcs[:15]:
        url = urllib.parse.urljoin(SIAM, src)
        info = {"url": url}
        if _same_site(url):
            try:
                _, _, js = _get(url, 400_000)
                code = js.decode("utf-8", "ignore")
                info["bytes"] = len(js)
                for m in _URLISH.finditer(code):
                    found.add(m.group(1))
                calls = [_clean(m.group(0))[:240] for m in re.finditer(r"(\$\.(?:get|post|ajax|getJSON)|fetch\(|XMLHttpRequest|\.open\()[^;]{0,200}", code)]
                info["calls"] = calls[:8]
            except Exception as e:
                info["error"] = str(e)
        out["scripts"].append(info)
    for u in sorted(found)[:40]:
        url = urllib.parse.urljoin(SIAM, u)
        if not _same_site(url) or url.endswith(".js") or re.search(r"\.(png|gif|jpg|css)$", url):
            out["candidates"].append({"url": url, "tested": False})
            continue
        c = {"url": url, "tested": True}
        try:
            st, ct, body = _get(url, 300_000, 15)
            text = body.decode("utf-8", "ignore")
            c.update(status=st, type=ct, bytes=len(body), start=text[:300])
            c["looks_like_table"] = bool(re.search(r"\b2S\b", text) and re.search(r"PTT|ADVANC|CPALL", text))
        except Exception as e:
            c["error"] = str(e)
        out["candidates"].append(c)
    return out


# ---------------------------------------------------------------- siamchart.com official figures
# SiamChart's screener loads its table with JavaScript. This reader finds the data address
# itself, then maps columns BY HEADER NAME (never by position), so a re-ordered table still
# reads correctly. It accepts JSON (list of objects, or header + rows), HTML tables and CSV/TSV.
_SIAM_COLS = {
    "symbol": "symbol", "sym": "symbol", "ticker": "symbol", "stock": "symbol", "security": "symbol", "code": "symbol",
    "magic1": "magic1", "magic2": "magic2", "cg": "cg", "cgr": "cg", "cgscore": "cg", "cgrating": "cg", "cgreport": "cg",
    "mcap": "mcap", "mcapm": "mcap", "marketcap": "mcap", "pe": "pe", "pbv": "pbv", "pb": "pbv", "de": "de", "dps": "dps",
    "eps": "eps", "roa": "roa", "roe": "roe", "npm": "npm", "yield": "yield", "dividendyield": "yield",
    "ffloat": "ffloat", "freefloat": "ffloat", "mg": "mg", "peg": "peg",
}
_CG_TEXT = {"excellent": 5, "ดีเลิศ": 5, "very good": 4, "ดีมาก": 4, "ดีเยี่ยม": 4, "good": 3, "ดี": 3, "satisfactory": 2, "ผ่าน": 2, "pass": 2, "n/a": None}
_siam_cache = {"at": 0.0, "data": None}
SIAM_SAVE = os.path.join(HERE, "siamchart_source.json")


def _hnorm(h):
    return re.sub(r"[^a-z0-9]", "", str(h).lower())


def _siam_val(key, v):
    if v is None:
        return None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    t = _clean(re.sub(r"<[^>]+>", "", str(v))).strip()
    if not t or t in ("-", "--", "n/a", "N/A", "NA", "null"):
        return None
    if key == "cg":
        n = t.count("★") or t.count("*")
        if n:
            return float(n)
        if t.lower() in _CG_TEXT or t in _CG_TEXT:
            r = _CG_TEXT.get(t.lower(), _CG_TEXT.get(t))
            return None if r is None else float(r)
    try:
        return float(re.sub(r"[%,\s]", "", t))
    except ValueError:
        return None


def _siam_rows(header, rows):
    """header: list of column titles; rows: list of cell lists -> {SYMBOL: {key: number}} or None."""
    keys = [_SIAM_COLS.get(_hnorm(h)) for h in header]
    if "symbol" not in keys or not any(k in keys for k in ("magic1", "magic2", "cg")):
        return None
    si = keys.index("symbol")
    out = {}
    for r in rows:
        if len(r) <= si:
            continue
        sym = re.sub(r"<[^>]+>", "", str(r[si] or "")).strip().upper().replace(".BK", "")
        sym = sym.split()[0] if sym else ""
        if not re.match(r"^[A-Z0-9&\-]{1,12}$", sym):
            continue
        row = {}
        for k, cell in zip(keys, r):
            if k and k != "symbol":
                v = _siam_val(k, cell)
                if v is not None:
                    row[k] = v
        if row:
            out[sym] = row
    return out if len(out) >= 20 else None


def _json_tables(o, depth=0):
    if depth > 7:
        return
    if isinstance(o, list) and len(o) >= 5:
        if all(isinstance(x, dict) for x in o[:5]):
            head = list(o[0].keys())
            yield head, [[x.get(h) for h in head] for x in o if isinstance(x, dict)]
        elif all(isinstance(x, list) for x in o[:5]):
            yield [str(c) for c in o[0]], o[1:]
    if isinstance(o, dict):
        cols = next((o[k] for k in ("columns", "headers", "header", "fields", "cols") if isinstance(o.get(k), list)), None)
        data = next((o[k] for k in ("data", "rows", "aaData", "items", "result", "stocks") if isinstance(o.get(k), list)), None)
        if cols and data and data and isinstance(data[0], list):
            head = [c.get("title") or c.get("name") or c.get("data") or "" if isinstance(c, dict) else str(c) for c in cols]
            yield head, data
        for v in o.values():
            yield from _json_tables(v, depth + 1)
    elif isinstance(o, list):
        for v in o[:50]:
            yield from _json_tables(v, depth + 1)


def _siam_extract(text):
    """Try JSON, then HTML tables, then CSV/TSV. Returns {SYMBOL: {...}} or None."""
    t = text.lstrip("﻿ \r\n\t")
    if t[:1] in "[{":
        try:
            for head, rows in _json_tables(json.loads(t)):
                got = _siam_rows(head, rows)
                if got:
                    return got
        except ValueError:
            pass
    if "<tr" in t.lower():
        for tbl in re.findall(r"<table.*?</table>", t, re.S | re.I):
            grid = []
            for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", tbl, re.S | re.I):
                grid.append([_clean(re.sub(r"<[^>]+>", " ", c)) for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", tr, re.S | re.I)])
            if len(grid) > 20:
                got = _siam_rows(grid[0], grid[1:])
                if got:
                    return got
    lines = [l for l in t.replace("\r", "").split("\n") if l.strip()]
    if len(lines) > 20:
        d = max([",", ";", "\t", "|"], key=lambda c: lines[0].count(c))
        if lines[0].count(d) >= 3:
            got = _siam_rows([c.strip().strip('"') for c in lines[0].split(d)], [[c.strip().strip('"') for c in l.split(d)] for l in lines[1:]])
            if got:
                return got
    return None


def _siam_candidates(html):
    found = []
    def add(u):
        u = urllib.parse.urljoin(SIAM, u)
        if _same_site(u) and u not in found and not re.search(r"\.(png|gif|jpg|jpeg|svg|css|woff2?|ico)(\?|$)", u, re.I):
            found.append(u)
    codes = re.findall(r"<script(?![^>]*src=)[^>]*>(.*?)</script>", html, re.S | re.I)
    for src in re.findall(r"<script[^>]+src=[\"']([^\"']+)", html, re.I)[:20]:
        url = urllib.parse.urljoin(SIAM, src)
        if _same_site(url):
            try:
                codes.append(_get(url, 500_000, 15)[2].decode("utf-8", "ignore"))
            except Exception:
                pass
    for code in codes:
        for m in _URLISH.finditer(code):
            add(m.group(1))
    # data addresses first, scripts last
    return sorted(found, key=lambda u: (u.lower().endswith(".js"), "stock" not in u.lower() and "data" not in u.lower()))[:40]


def siam_table(url=None, force=False):
    now = time.time()
    if not force and not url and _siam_cache["data"] and now - _siam_cache["at"] < 1800:
        return _siam_cache["data"]
    tried, order = [], []
    if url:
        order.append(url)
    else:
        try:
            order.append(json.load(open(SIAM_SAVE, encoding="utf-8")).get("url"))
        except Exception:
            pass
    page_html = ""
    try:
        page_html = _get(SIAM, 800_000)[2].decode("utf-8", "ignore")
    except Exception as e:
        tried.append({"url": SIAM, "error": str(e)})
    for u in (_siam_candidates(page_html) if page_html and not url else []):
        if u not in order:
            order.append(u)
    if page_html and SIAM not in order:
        order.append(SIAM)   # tables rendered into the page itself
    for u in [x for x in order if x]:
        try:
            st, ct, body = _get(u, 3_000_000, 25)
            rows = _siam_extract(body.decode("utf-8", "ignore"))
            if rows:
                cols = sorted({k for r in rows.values() for k in r})
                data = {"ok": True, "url": u, "count": len(rows), "columns": cols, "at": int(now * 1000), "rows": rows}
                _siam_cache.update(at=now, data=data)
                try:
                    json.dump({"url": u}, open(SIAM_SAVE, "w", encoding="utf-8"))
                except Exception:
                    pass
                return data
            tried.append({"url": u, "status": st, "bytes": len(body), "note": "no table with Symbol + Magic1/Magic2/CG columns"})
        except Exception as e:
            tried.append({"url": u, "error": str(e)})
    return {"ok": False, "error": "Could not find SiamChart's stock table. Open /siamchart/probe, then pass the right address as /siamchart/table?url=...", "tried": tried[:20]}


SIGN_CODES = {"CB", "CS", "CF", "CC", "C", "NP", "NR", "NC", "ST", "H", "SP", "P", "XD", "XR", "XW", "XB", "XN", "XA", "XT", "XM", "XE"}
_SIGN_CANDIDATES = ["/api/set/market/sign-posting", "/api/set/news/sign-posting", "/api/set/stock/sign-posting"]


def signs_fetch(url=None):
    """Best effort: read SET's own sign-posting data. Walks any JSON and keeps rows that pair a symbol with sign codes."""
    paths = [url] if url else _SIGN_CANDIDATES
    tried, last = [], None
    for path in paths:
        try:
            if path.startswith("http"):
                if not path.startswith(SET_BASE + "/"):
                    raise RuntimeError("Only set.or.th addresses are allowed")
                path = path[len(SET_BASE):]
            j = _set_json(path)
        except Exception as e:
            tried.append({"url": path, "error": str(e)}); continue
        out = {}
        for d in _dicts(j):
            sym = next((d[k] for k in ("symbol", "securities", "security", "securitySymbol") if isinstance(d.get(k), str)), None)
            raw = next((d[k] for k in ("sign", "signType", "signs", "notificationSign", "signCode") if isinstance(d.get(k), str)), None)
            if not sym or not raw:
                continue
            codes = [c for c in re.split(r"[,\s/]+", raw.upper()) if c in SIGN_CODES]
            if codes:
                out.setdefault(sym.strip().upper(), set()).update(codes)
        if out:
            return {"ok": True, "url": SET_BASE + path, "count": len(out), "map": {k: sorted(v) for k, v in out.items()}}
        tried.append({"url": path, "error": "no symbol/sign pairs found"})
    return {"ok": False, "error": "Could not read SET's sign list automatically. Paste its table in Settings instead.", "tried": tried}


_INV_CANDIDATES = ["/api/set/market/investor-type", "/api/set/market/statistics/investor-type", "/api/set/statistics/investor-type",
                   "/api/set/market-statistics/investor-type", "/api/set/market/investor-type/trading-value", "/api/set/stock/market-statistics/investor-type"]
_INV_TYPES = [("foreign", re.compile(r"foreign", re.I), "Foreign Investors"), ("inst", re.compile(r"institution", re.I), "Local Institutions"),
              ("prop", re.compile(r"propriet", re.I), "Proprietary Trading"), ("indiv", re.compile(r"individual|retail", re.I), "Local Individuals")]


def _walk_paths(obj, path=()):
    if isinstance(obj, dict):
        yield path, obj
        for k, v in obj.items():
            yield from _walk_paths(v, path + (str(k),))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _walk_paths(v, path + (str(i),))


def _num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        t = v.replace(",", "").strip()
        try:
            return float(t)
        except Exception:
            return None
    return None


def investor_parse(j):
    """Walk any JSON and keep dicts that name an investor type and carry buy / sell / net figures."""
    sets, cur, last_parent = [], {}, None
    for path, d in _walk_paths(j):
        name = next((d[k] for k in d if isinstance(d[k], str) and re.search(r"type|name|investor", k, re.I) and any(rx.search(d[k]) for _, rx, _ in _INV_TYPES)), None)
        if not name:
            continue
        key = next(k for k, rx, _ in _INV_TYPES if rx.search(name))
        buy = sell = net = None
        for k, v in d.items():
            kl = k.lower(); x = _num(v)
            if x is None or "percent" in kl or "pct" in kl or kl.endswith("%"):
                continue
            if "buy" in kl and "net" not in kl and buy is None:
                buy = x
            elif "sell" in kl and "net" not in kl and sell is None:
                sell = x
            elif "net" in kl and net is None:
                net = x
        if net is None and buy is not None and sell is not None:
            net = buy - sell
        if net is None:
            continue
        parent = path[:-1] if path and path[-1].isdigit() else path
        if key in cur or (last_parent is not None and parent != last_parent and cur):
            sets.append((last_parent, cur)); cur = {}
        cur[key] = {"type": key, "label": next(l for k2, _, l in _INV_TYPES if k2 == key), "buy": buy, "sell": sell, "net": net}
        last_parent = parent
    if cur:
        sets.append((last_parent, cur))
    out = []
    for parent, c in sets:
        if len(c) >= 3:
            label = " / ".join(x for x in (parent or ()) if x and not x.isdigit())[-60:]
            out.append({"label": label, "rows": [c[k] for k, _, _ in _INV_TYPES if k in c]})
    date = None
    for _, d in _walk_paths(j):
        for k, v in d.items():
            if isinstance(v, str) and re.search(r"date|asof|time", k, re.I) and re.search(r"20\d\d", v):
                date = v; break
        if date:
            break
    return {"sets": out, "asOf": date}


def investor_fetch(url=None):
    paths = [url] if url else _INV_CANDIDATES
    tried = []
    for path in paths:
        try:
            if path.startswith("http"):
                if not path.startswith(SET_BASE + "/"):
                    raise RuntimeError("Only set.or.th addresses are allowed")
                path = path[len(SET_BASE):]
            j = _set_json(path)
            r = investor_parse(j)
            if r["sets"]:
                r.update({"ok": True, "url": SET_BASE + path, "at": int(time.time() * 1000)}); return r
            tried.append({"url": path, "error": "no investor-type rows found"})
        except Exception as e:
            tried.append({"url": path, "error": str(e)})
    # the page itself (Next.js sites embed their data as JSON in the HTML)
    try:
        html = _open(SET_BASE + "/en/market/statistics/investor-type", 20).read().decode("utf-8", "ignore")
        m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.S)
        if m:
            r = investor_parse(json.loads(m.group(1)))
            if r["sets"]:
                r.update({"ok": True, "url": SET_BASE + "/en/market/statistics/investor-type", "at": int(time.time() * 1000)}); return r
        tried.append({"url": "page html", "error": "the page loads its numbers with scripts; none embedded"})
    except Exception as e:
        tried.append({"url": "page html", "error": str(e)})
    return {"ok": False, "error": "Could not read SET's investor-type data automatically. Paste the table from the page instead.", "tried": tried}


# ---------------------------------------------------------------- Derivative Warrants (DW)
DW_LIST_URL = "https://siamchart.com/stock/DW"
DW_RE = re.compile(r"^[A-Z0-9&]{1,10}?\d{2}[CP]\d{4}[A-Z0-9]$")
_dw_cache = {"at": 0.0, "data": None}
_dw_path = {"p": None}
_DW_PATHS = ["/api/set/stock/{s}/quote", "/api/set/stock/{s}/info", "/api/set/dw/{s}/quote", "/api/set/dw/{s}/info", "/api/set/stock/{s}/overview"]


def dw_list(force=False, url=None):
    now = time.time()
    if not force and not url and _dw_cache["data"] and now - _dw_cache["at"] < 6 * 3600:
        return _dw_cache["data"]
    u = url or DW_LIST_URL
    try:
        st, ct, body = _get(u, 4_000_000, 30)
    except Exception as e:
        return {"ok": False, "error": "Could not read SiamChart's DW list: %s" % e}
    html = body.decode("utf-8", "ignore")
    syms = []
    for m in re.finditer(r"/stock-chart/([A-Za-z0-9&\-]+)/", html):
        t = m.group(1).upper()
        if DW_RE.match(t) and t not in syms:
            syms.append(t)
    if not syms:
        return {"ok": False, "error": "The page loaded but no DW symbols were found in it.", "bytes": len(body)}
    data = {"ok": True, "url": u, "count": len(syms), "syms": syms, "at": int(now * 1000)}
    if not url:
        _dw_cache.update(at=now, data=data)
    return data


def _first_num(d, names, excl=()):
    for k, v in d.items():
        kl = re.sub(r"[^a-z0-9]", "", k.lower())
        if any(kl == n or (len(n) > 5 and n in kl) for n in names) and not any(x in kl for x in excl):
            x = _num(v)
            if x is None and isinstance(v, str):
                m = re.match(r"^\s*([\d.,]+)\s*[:/]", v)
                x = _num(m.group(1)) if m else None
            if x is not None:
                return x
    return None


def _first_str(d, names):
    for k, v in d.items():
        kl = re.sub(r"[^a-z0-9]", "", k.lower())
        if isinstance(v, str) and v.strip() and any(kl == n or (len(n) > 5 and n in kl) for n in names):
            return v.strip()
    return None


def dw_parse(j):
    out = {}
    for d in _dicts(j):
        for key, names, ex in (("last", ("last", "lastprice", "close", "price"), ("prior", "percent")), ("prior", ("prior", "previousclose", "prevclose"), ()),
                               ("chg", ("change", "chg"), ("percent", "pct")), ("pct", ("percentchange", "pctchange", "changepercent"), ()),
                               ("vol", ("totalvolume", "volume"), ()), ("value", ("totalvalue", "tradedvalue", "value"), ("percent",)),
                               ("strike", ("exerciseprice", "strikeprice", "strike"), ()), ("ratio", ("exerciseratio", "conversionratio", "ratio"), ()),
                               ("os", ("outstanding", "outstandingunits", "outstandingwarrants", "osunits"), ("percent", "pct")), ("listed", ("listedunits", "issuedunits", "listedshare", "issuedvolume"), ())):
            if key not in out:
                v = _first_num(d, names, ex)
                if v is not None:
                    out[key] = v
        for key, names in (("expiry", ("maturitydate", "lastexercisedate", "expirydate", "expirationdate", "lasttradingdate")), ("issuer", ("issuer", "issuername", "issuershortname")), ("underlying", ("underlying", "underlyingsymbol", "underlyingname"))):
            if key not in out:
                v = _first_str(d, names)
                if v:
                    out[key] = v
    return out


def dw_quote(sym):
    paths = [_dw_path["p"]] if _dw_path["p"] else _DW_PATHS
    err = None
    for pth in paths:
        try:
            j = _set_json(pth.format(s=urllib.parse.quote(sym)))
            r = dw_parse(j)
            if "last" in r or "strike" in r or "vol" in r:
                _dw_path["p"] = pth
                r["at"] = int(time.time() * 1000)
                return r
            err = "no DW fields in the answer"
        except Exception as e:
            err = str(e)
    return {"error": err or "no data"}


def dw_quotes(syms):
    from concurrent.futures import ThreadPoolExecutor
    out = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        for s, r in zip(syms, ex.map(dw_quote, syms)):
            out[s] = r
    ok = sum(1 for r in out.values() if "error" not in r)
    return {"ok": ok > 0, "count": ok, "q": out, "path": _dw_path["p"],
            "error": None if ok else "SET did not return DW quotes (it may block scripts). Paste a DW table instead.", "at": int(time.time() * 1000)}


_DW_HIST_PATHS = ["/api/set/stock/{s}/chart-quotation?period=1Y&accumulated=false", "/api/set/stock/{s}/historical-trading", "/api/set/stock/{s}/chart-quotation?period=6M&accumulated=false"]
_dw_hist_cache = {}


def _to_ms(v):
    if isinstance(v, (int, float)):
        return int(v if v > 1e11 else v * 1000)
    if isinstance(v, str):
        t = v.strip()
        if re.fullmatch(r"\d{10,13}", t):
            return _to_ms(int(t))
        m = re.match(r"(\d{4})-(\d{2})-(\d{2})", t)
        if m:
            import calendar
            return calendar.timegm((int(m.group(1)), int(m.group(2)), int(m.group(3)), 0, 0, 0)) * 1000
    return None


def ohlc_rows(j):
    """Longest daily price series found anywhere in a JSON answer: list of dicts or list of [t,o,h,l,c,v]."""
    best = []

    def walk(o, depth=0):
        nonlocal best
        if depth > 7:
            return
        if isinstance(o, list) and len(o) >= 2:
            rows = []
            if all(isinstance(x, dict) for x in o[:3]):
                for x in o:
                    kl = {re.sub(r"[^a-z0-9]", "", k.lower()): v for k, v in x.items()}
                    t = next((_to_ms(kl[k]) for k in ("date", "datetime", "localdatetime", "time", "tradedate", "t") if k in kl and _to_ms(kl[k])), None)
                    c = next((_num(kl[k]) for k in ("close", "last", "price", "c", "closeprice") if k in kl and _num(kl[k]) is not None), None)
                    if t is None or c is None:
                        continue
                    g = lambda *ks: next((_num(kl[k]) for k in ks if k in kl and _num(kl[k]) is not None), None)
                    rows.append([t, g("open", "o") or c, g("high", "h") or c, g("low", "l") or c, c, g("volume", "totalvolume", "v") or 0])
            elif all(isinstance(x, list) and len(x) >= 5 for x in o[:3]):
                for x in o:
                    t = _to_ms(x[0])
                    if t is not None and all(_num(v) is not None for v in x[1:5]):
                        rows.append([t] + [float(_num(v)) for v in x[1:5]] + [float(_num(x[5]) or 0) if len(x) > 5 else 0.0])
            if len(rows) > len(best):
                best = rows
            for v in o[:50]:
                walk(v, depth + 1)
        elif isinstance(o, dict):
            for v in o.values():
                walk(v, depth + 1)
    walk(j)
    # one bar per day (intraday ticks collapse into daily OHLC)
    days = {}
    for r in sorted(best):
        d = int(r[0] // 86400000)
        b = days.get(d)
        if b is None:
            days[d] = [d * 86400000, r[1], r[2], r[3], r[4], r[5]]
        else:
            b[2] = max(b[2], r[2]); b[3] = min(b[3], r[3]); b[4] = r[4]; b[5] += r[5]
    return [days[k] for k in sorted(days)]


def dw_history(sym, force=False):
    now = time.time(); c = _dw_hist_cache.get(sym)
    if c and not force and now - c["at"] < 900:
        return c["data"]
    tried = []
    for pth in _DW_HIST_PATHS:
        try:
            rows = ohlc_rows(_set_json(pth.format(s=urllib.parse.quote(sym))))
            if len(rows) >= 2:
                data = {"ok": True, "source": "set.or.th", "bars": rows, "count": len(rows)}
                _dw_hist_cache[sym] = {"at": now, "data": data}; return data
            tried.append({"url": pth, "error": "fewer than 2 daily prices"})
        except Exception as e:
            tried.append({"url": pth, "error": str(e)})
    try:
        st, ct, body = _get("https://siamchart.com/stock-chart/%s/" % urllib.parse.quote(sym), 3_000_000, 25)
        html = body.decode("utf-8", "ignore")
        for m in re.finditer(r"\[\s*\[\s*\d{9,13}\s*,[^\[\]]+\](?:\s*,\s*\[[^\[\]]+\])+\s*\]", html):
            try:
                rows = ohlc_rows(json.loads(m.group(0)))
            except Exception:
                continue
            if len(rows) >= 2:
                data = {"ok": True, "source": "siamchart.com", "bars": rows, "count": len(rows)}
                _dw_hist_cache[sym] = {"at": now, "data": data}; return data
        tried.append({"url": "siamchart.com chart page", "error": "no price series embedded in the page"})
    except Exception as e:
        tried.append({"url": "siamchart.com chart page", "error": str(e)})
    return {"ok": False, "error": "No daily price history found for %s" % sym, "tried": tried}


# ---------------------------------------------------------------- Stock warrants (company warrants such as ABC-W1)
WR_LIST_URL = "https://siamchart.com/stock/W"
WR_RE = re.compile(r"^[A-Z0-9&]{1,12}-W[A-Z0-9]{0,3}$")
_wr_cache = {"at": 0.0, "data": None}
_WR_PATHS = ["/api/set/stock/{s}/quote", "/api/set/stock/{s}/info", "/api/set/stock/{s}/overview", "/api/set/stock/{s}/profile"]
_wr_path = {"p": None}


def wr_list(force=False, url=None):
    now = time.time()
    if not force and not url and _wr_cache["data"] and now - _wr_cache["at"] < 6 * 3600:
        return _wr_cache["data"]
    syms, notes = [], []
    try:
        st, ct, body = _get(url or WR_LIST_URL, 4_000_000, 30)
        html = body.decode("utf-8", "ignore")
        for m in re.finditer(r"/stock-chart/([A-Za-z0-9&\-]+)/", html):
            t = m.group(1).upper()
            if WR_RE.match(t) and t not in syms:
                syms.append(t)
        notes.append("siamchart.com: %d" % len(syms))
    except Exception as e:
        notes.append("siamchart.com failed: %s" % e)
    if not url:
        try:   # SET's own securities list also names warrants
            j = _set_json("/api/set/stock/list")
            n0 = len(syms)
            for d in _dicts(j):
                t = str(d.get("symbol") or d.get("Symbol") or "").upper()
                if t and WR_RE.match(t) and t not in syms:
                    syms.append(t)
            notes.append("set.or.th: +%d" % (len(syms) - n0))
        except Exception as e:
            notes.append("set.or.th list failed: %s" % e)
    if not syms:
        return {"ok": False, "error": "No warrant symbols found (%s)." % "; ".join(notes)}
    data = {"ok": True, "count": len(syms), "syms": sorted(syms), "notes": notes, "at": int(now * 1000)}
    if not url:
        _wr_cache.update(at=now, data=data)
    return data


def _wr_ratio(j):
    """Shares received per warrant. SET writes 'warrants : shares' (1 : 1.25), so the second number counts."""
    for d in _dicts(j):
        for k, v in d.items():
            if "ratio" not in re.sub(r"[^a-z0-9]", "", k.lower()):
                continue
            if isinstance(v, str):
                m = re.match(r"^\s*([\d.,]+)\s*[:/]\s*([\d.,]+)", v)
                if m:
                    a, b = _num(m.group(1)), _num(m.group(2))
                    if a and b:
                        return b / a
                x = _num(v)
                if x:
                    return x
            else:
                x = _num(v)
                if x:
                    return x
    return None


def wr_parse(j):
    r = dw_parse(j); r.pop("ratio", None)
    x = _wr_ratio(j)
    if x:
        r["ratio"] = x
    return r


def _yahoo_quote(sym):
    """Last price, previous close and volume from Yahoo Finance (SYMBOL.BK), used when SET gives none."""
    url = "https://query1.finance.yahoo.com/v8/finance/chart/%s.BK?range=5d&interval=1d" % urllib.parse.quote(sym)
    with _open(url, 15) as r:
        j = json.loads(r.read().decode("utf-8", "ignore"))
    res = j["chart"]["result"][0]; m = res.get("meta") or {}; out = {}
    px = m.get("regularMarketPrice"); pv = m.get("chartPreviousClose") or m.get("previousClose")
    q = (res.get("indicators", {}).get("quote") or [{}])[0]; cl = [c for c in (q.get("close") or []) if c is not None]
    if px is None and cl:
        px = cl[-1]
    if pv is None and len(cl) > 1:
        pv = cl[-2]
    if px is not None and px > 0:
        out["last"] = float(px)
    if pv is not None and pv > 0:
        out["prior"] = float(pv)
    if "last" in out and "prior" in out:
        out["chg"] = out["last"] - out["prior"]; out["pct"] = out["chg"] / out["prior"] * 100
    vv = m.get("regularMarketVolume")
    if vv:
        out["vol"] = float(vv)
    return out


def wr_quote(sym):
    """SET first. One SET page rarely carries everything, so every known page is read and merged until the
    price and the three terms (ratio, exercise price, last exercise date) are all found; Yahoo fills in the price."""
    paths = ([_wr_path["p"]] if _wr_path["p"] else []) + [p for p in _WR_PATHS if p != _wr_path["p"]]
    r, errs, hit = {}, [], None
    for pth in paths:
        try:
            got = wr_parse(_set_json(pth.format(s=urllib.parse.quote(sym))))
        except Exception as e:
            errs.append(str(e)); continue
        if got and hit is None and ("last" in got or "strike" in got or "vol" in got):
            hit = pth
        for k, v in got.items():
            r.setdefault(k, v)
        if ("last" in r or "prior" in r) and all(k in r for k in ("strike", "ratio", "expiry")):
            break
    if hit:
        _wr_path["p"] = hit
    src = ["set.or.th"] if r else []
    if not (r.get("last") or 0) > 0:
        try:
            y = _yahoo_quote(sym)
            if y:
                for k, v in y.items():
                    if k == "last" or r.get(k) in (None, 0):
                        r[k] = v
                src.append("yahoo")
        except Exception as e:
            errs.append("yahoo: %s" % e)
    if "last" in r or "strike" in r or "vol" in r or "prior" in r:
        r["at"] = int(time.time() * 1000); r["src"] = "+".join(src)
        r["missing"] = [k for k, lab in (("last", "price"), ("strike", "exercise price"), ("ratio", "ratio"), ("expiry", "last exercise date")) if k not in r and not (k == "last" and "prior" in r)]
        return r
    return {"error": (errs[-1] if errs else "no warrant fields in the answer")}


def wr_quotes(syms):
    from concurrent.futures import ThreadPoolExecutor
    out = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        for s, r in zip(syms, ex.map(wr_quote, syms)):
            out[s] = r
    ok = sum(1 for r in out.values() if "error" not in r)
    return {"ok": ok > 0, "count": ok, "q": out, "path": _wr_path["p"],
            "error": None if ok else "SET did not return warrant quotes (it may block scripts). Paste the warrant table from set.or.th instead.", "at": int(time.time() * 1000)}


_WR_HIST_PATHS = ["/api/set/stock/{s}/chart-quotation?period=5Y&accumulated=false", "/api/set/stock/{s}/chart-quotation?period=1Y&accumulated=false",
                  "/api/set/stock/{s}/historical-trading", "/api/set/stock/{s}/chart-quotation?period=6M&accumulated=false"]
_wr_hist_cache = {}


def _yahoo_daily(sym_bk):
    """Yahoo Finance daily bars, as many as it has."""
    url = "https://query1.finance.yahoo.com/v8/finance/chart/%s?range=max&interval=1d&includePrePost=false" % urllib.parse.quote(sym_bk)
    with _open(url, 20) as r:
        j = json.loads(r.read().decode("utf-8", "ignore"))
    res = j["chart"]["result"][0]; ts = res.get("timestamp") or []; q = res["indicators"]["quote"][0]
    rows = []
    for i, t in enumerate(ts):
        o, h, l, c, v = (q.get(k, [None] * len(ts))[i] for k in ("open", "high", "low", "close", "volume"))
        if c is None:
            continue
        rows.append([int(t // 86400) * 86400000, o if o is not None else c, h if h is not None else c, l if l is not None else c, c, v or 0])
    return rows


def wr_history(sym, force=False):
    """All the daily history we can find: SET, then SiamChart, then Yahoo Finance. The longest series wins."""
    now = time.time(); c = _wr_hist_cache.get(sym)
    if c and not force and now - c["at"] < 900:
        return c["data"]
    best, src, tried = [], "", []
    def take(rows, name):
        nonlocal best, src
        if len(rows) > len(best):
            best, src = rows, name
    for pth in _WR_HIST_PATHS:
        if len(best) >= 250:
            break
        try:
            rows = ohlc_rows(_set_json(pth.format(s=urllib.parse.quote(sym))))
            if len(rows) >= 2:
                take(rows, "set.or.th")
            else:
                tried.append({"url": pth, "error": "fewer than 2 daily prices"})
        except Exception as e:
            tried.append({"url": pth, "error": str(e)})
    if len(best) < 250:
        try:
            st, ct, body = _get("https://siamchart.com/stock-chart/%s/" % urllib.parse.quote(sym), 3_000_000, 25)
            html = body.decode("utf-8", "ignore"); got = False
            for m in re.finditer(r"\[\s*\[\s*\d{9,13}\s*,[^\[\]]+\](?:\s*,\s*\[[^\[\]]+\])+\s*\]", html):
                try:
                    rows = ohlc_rows(json.loads(m.group(0)))
                except Exception:
                    continue
                if len(rows) >= 2:
                    take(rows, "siamchart.com"); got = True
            if not got:
                tried.append({"url": "siamchart.com chart page", "error": "no price series embedded in the page"})
        except Exception as e:
            tried.append({"url": "siamchart.com chart page", "error": str(e)})
    if len(best) < 250:
        try:
            rows = _yahoo_daily(sym + ".BK")
            if len(rows) >= 2:
                take(rows, "Yahoo Finance")
            else:
                tried.append({"url": "Yahoo Finance", "error": "fewer than 2 daily prices"})
        except Exception as e:
            tried.append({"url": "Yahoo Finance", "error": str(e)})
    if len(best) >= 2:
        data = {"ok": True, "source": src, "bars": best, "count": len(best)}
        _wr_hist_cache[sym] = {"at": now, "data": data}
        return data
    return {"ok": False, "error": "No daily price history found for %s" % sym, "tried": tried}


_companies_cache = {"at": 0, "data": None}


def fetch_companies(force=False):
    """Every listed security with its English and Thai names, from SET's own stock list (cached 12 hours)."""
    if not force and _companies_cache["data"] and time.time() - _companies_cache["at"] < 12 * 3600:
        return _companies_cache["data"]
    j = _set_json("/api/set/stock/list")
    items, seen = [], set()

    def pick(d, *keys):
        for k in keys:
            v = d.get(k)
            if isinstance(v, str) and v.strip():
                return v.strip()
        return ""
    for d in _dicts(j):
        sym = d.get("symbol")
        if not isinstance(sym, str) or sym in seen or not SYMBOL_RE.match(sym):
            continue
        en = pick(d, "nameEN", "nameEn", "name_en", "englishName", "longNameEn")
        th = pick(d, "nameTH", "nameTh", "name_th", "thaiName", "longNameTh")
        if not (en or th):
            continue
        seen.add(sym)
        items.append({"symbol": sym.upper(), "nameEn": en, "nameTh": th, "market": pick(d, "market"),
                      "industry": pick(d, "industry", "industryName"), "sector": pick(d, "sector", "sectorName"),
                      "type": pick(d, "securityType", "typeSequence", "type")})
    if not items:
        raise RuntimeError("SET's stock list had no company names")
    out = {"ok": True, "count": len(items), "items": items}
    _companies_cache.update(at=time.time(), data=out)
    return out


def fetch_quotes(symbols):
    for attempt in (0, 1):
        crumb = get_crumb(force=attempt == 1)
        url = ("https://query1.finance.yahoo.com/v7/finance/quote?symbols="
               f"{urllib.parse.quote(','.join(symbols), safe=',^.')}&crumb={urllib.parse.quote(crumb)}")
        try:
            with _open(url, 20) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            if e.code in (401, 403) and attempt == 0:
                continue
            return e.code, e.read() or b"{}"
    return 502, b'{"error":"Yahoo refused the session"}'


def fetch_fundamentals(symbol):
    for attempt in (0, 1):
        crumb = get_crumb(force=attempt == 1)
        url = ("https://query2.finance.yahoo.com/v10/finance/quoteSummary/"
               f"{urllib.parse.quote(symbol)}?modules={FUND_MODULES}&crumb={urllib.parse.quote(crumb)}")
        try:
            with _open(url) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            if e.code in (401, 403) and attempt == 0:
                continue  # crumb expired, get a fresh one
            return e.code, e.read() or b"{}"
    return 502, b'{"error":"Yahoo refused the session"}'


# ================= YSX (Yangon Stock Exchange) and World Bank relay =================
from html.parser import HTMLParser

YSX = "https://ysx-mm.com"
YSX_PAGES = {"home": "/", "mb": "/main-board/mktdata/stocktradingdata/", "plb": "/pre-listing-board/marketdata/stock-trading-data/"}
WB_MCAP = "https://api.worldbank.org/v2/country/all/indicator/CM.MKT.LCAP.CD?format=json&mrnev=1&per_page=400"
_MONTHS = {m: i + 1 for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}


class _Tables(HTMLParser):
    """Collects every table as rows of cell text, remembers the last heading before it."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self.stack, self.cell, self.heading, self.hbuf, self.in_h, self.text = [], [], None, "", [], False, []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript"):
            self.skip += 1
        elif tag == "table":
            self.stack.append({"head": self.heading, "rows": [], "row": None})
        elif tag == "tr" and self.stack:
            self.stack[-1]["row"] = []
        elif tag in ("td", "th") and self.stack:
            self.cell = []
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6", "caption"):
            self.in_h, self.hbuf = True, []
        elif tag == "br" and self.cell is not None:
            self.cell.append(" ")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript"):
            self.skip = max(0, self.skip - 1)
        elif tag in ("td", "th") and self.stack and self.cell is not None:
            t = re.sub(r"\s+", " ", "".join(self.cell)).strip()
            if self.stack[-1]["row"] is not None:
                self.stack[-1]["row"].append(t)
            self.cell = None
        elif tag == "tr" and self.stack and self.stack[-1]["row"] is not None:
            if any(self.stack[-1]["row"]):
                self.stack[-1]["rows"].append(self.stack[-1]["row"])
            self.stack[-1]["row"] = None
        elif tag == "table" and self.stack:
            self.tables.append(self.stack.pop())
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6", "caption") and self.in_h:
            h = re.sub(r"\s+", " ", "".join(self.hbuf)).strip()
            if h:
                self.heading = h[:120]
            self.in_h = False

    def handle_data(self, d):
        if self.skip:
            return
        if self.cell is not None:
            self.cell.append(d)
        if self.in_h:
            self.hbuf.append(d)
        self.text.append(d)


def _ysx_num(s):
    if s is None:
        return None
    t = str(s).replace("−", "-").replace("–", "-")
    neg = bool(re.search(r"[▼↓]", t)) or bool(re.match(r"^\s*\(", t))
    m = re.search(r"[-+]?\s*\d[\d,]*(?:\.\d+)?", t)
    if not m:
        return None
    v = float(m.group(0).replace(",", "").replace(" ", ""))
    return -abs(v) if neg and v > 0 else v


def _ysx_date(text):
    """First 'DD(st) Mon(.) YYYY' in the text, as YYYY-MM-DD."""
    for m in re.finditer(r"(\d{1,2})(?:st|nd|rd|th)?\.?\s+([A-Za-z]{3,9})\.?,?\s+(20\d\d)", text):
        mon = _MONTHS.get(m.group(2)[:3].lower())
        if mon:
            return "%04d-%02d-%02d" % (int(m.group(3)), mon, int(m.group(1)))
    return None


def _ysx_cols(head):
    cols = {}
    for i, h in enumerate(head):
        k = re.sub(r"[^a-z%. ]", " ", h.lower()); k = re.sub(r"\s+", " ", k).strip()
        key = None
        if k == "name":
            key = "name"
        elif k == "code" or k.endswith(" code"):
            key = "code"
        elif "%" in k or "pct" in k:
            key = "pct"
        elif "change" in k or k == "chg":
            key = "chg"
        elif "close" in k or k in ("price", "last", "last price"):
            key = "close"
        elif k.startswith("open"):
            key = "open"
        elif k.startswith("high"):
            key = "high"
        elif k.startswith("low"):
            key = "low"
        elif "volume" in k:
            key = "vol"
        elif "value" in k:
            key = "val"
        elif "listed shares" in k or "no. of listed" in k or "number of listed" in k:
            key = "shares"
        elif "market cap" in k:
            key = "mcap"
        if key and key not in cols:
            cols[key] = i
    return cols


def ysx_parse(html, board_hint=None):
    p = _Tables()
    p.feed(html)
    text = re.sub(r"\s+", " ", " ".join(p.text))
    out = {"asOf": _ysx_date(text), "tables": [], "index": None}
    for t in p.tables:
        rows = t["rows"]
        hi = next((i for i, r in enumerate(rows) if any(c.strip().lower() == "code" or c.strip().lower().endswith(" code") for c in r)), None)
        if hi is None:
            continue
        cols = _ysx_cols(rows[hi])
        if "code" not in cols or not ({"close", "chg"} & set(cols)):
            continue
        recs = []
        for r in rows[hi + 1:]:
            if len(r) <= cols["code"]:
                continue
            code = r[cols["code"]].strip()
            if not re.fullmatch(r"\d{4,6}", code):
                continue
            rec = {"code": code.zfill(5)}
            for k, i in cols.items():
                if i >= len(r) or k == "code":
                    continue
                rec[k] = r[i].strip() if k == "name" else _ysx_num(r[i])
            recs.append(rec)
        if recs:
            head = (t["head"] or "")
            board = board_hint or ("PLB" if re.search(r"PLB|pre.?listing", head, re.I) else "MB")
            out["tables"].append({"heading": head, "board": board, "rows": recs})
    m = re.search(r"MYANPIX[^0-9\-]{0,80}(\d[\d,]*(?:\.\d+)?)", text)
    if m:
        out["index"] = _ysx_num(m.group(1))
    return out


_ysx_cache = {"at": 0, "data": None}


def ysx_fetch(force=False):
    if not force and _ysx_cache["data"] and time.time() - _ysx_cache["at"] < 60:
        return _ysx_cache["data"]
    out = {"fetchedAt": int(time.time() * 1000), "pages": {}, "errors": {}, "source": YSX}
    for key, path in YSX_PAGES.items():
        try:
            req = urllib.request.Request(YSX + path, headers={"User-Agent": UA, "Accept": "text/html,*/*"})
            with _opener.open(req, timeout=25) as r:
                body = r.read(2_500_000).decode("utf-8", "ignore")
            hint = {"mb": "MB", "plb": "PLB"}.get(key)
            out["pages"][key] = ysx_parse(body, hint)
            if not out["pages"][key]["tables"]:
                out["errors"][key] = "Page loaded but no stock table was found (the site layout may have changed)"
        except Exception as e:
            out["errors"][key] = str(e)
    _ysx_cache.update(at=time.time(), data=out)
    return out


def wb_mcap():
    req = urllib.request.Request(WB_MCAP, headers={"User-Agent": UA, "Accept": "application/json"})
    with _opener.open(req, timeout=25) as r:
        return r.read(3_000_000)


# ================= YSX history: monthly and daily PDF reports -> price history =================


# ---------------------------------------------------------------- phone alerts (Telegram, ntfy, LINE)
NOTIFY_FILE = os.path.join(DATA_DIR, "notify.json")
_nt = {"sent": []}
_nt_lock = threading.Lock()


def notify_load():
    try:
        with open(NOTIFY_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def notify_masked(cfg):
    def m(v):
        v = str(v or "")
        return ("*" * max(0, len(v) - 4) + v[-4:]) if v else ""
    return {"telegram": {"token": m(cfg.get("telegram", {}).get("token")), "chat": str(cfg.get("telegram", {}).get("chat") or ""), "on": bool(cfg.get("telegram", {}).get("token") and cfg.get("telegram", {}).get("chat"))},
            "ntfy": {"server": cfg.get("ntfy", {}).get("server") or "https://ntfy.sh", "topic": cfg.get("ntfy", {}).get("topic") or "", "on": bool(cfg.get("ntfy", {}).get("topic"))},
            "line": {"token": m(cfg.get("line", {}).get("token")), "to": m(cfg.get("line", {}).get("to")), "on": bool(cfg.get("line", {}).get("token") and cfg.get("line", {}).get("to"))},
            "daily": {"on": cfg.get("daily", {}).get("on", True), "at": cfg.get("daily", {}).get("at") or "17:45"}}


def notify_save(new):
    cfg = notify_load()
    for ch, fields in (("telegram", ("token", "chat")), ("ntfy", ("server", "topic")), ("line", ("token", "to"))):
        if ch not in new or not isinstance(new[ch], dict):
            continue
        cur = cfg.setdefault(ch, {})
        for k in fields:
            v = new[ch].get(k)
            if v is None:
                continue
            v = str(v).strip()
            if v.startswith("*") and k in ("token", "to"):
                continue  # the masked copy came back unchanged: keep the saved secret
            if v == "":
                cur.pop(k, None)
            else:
                cur[k] = v
    if isinstance(new.get("daily"), dict):
        d = cfg.setdefault("daily", {}); nd = new["daily"]
        if "on" in nd:
            d["on"] = bool(nd["on"])
        if re.match(r"^([01]\d|2[0-3]):[0-5]\d$", str(nd.get("at") or "")):
            d["at"] = nd["at"]
    with open(NOTIFY_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f)
    try:
        os.chmod(NOTIFY_FILE, 0o600)
    except Exception:
        pass
    return cfg


def _post(url, data, headers, timeout=15):
    req = urllib.request.Request(url, data=data, headers={"User-Agent": UA, **headers}, method="POST")
    with _opener.open(req, timeout=timeout) as r:
        return r.status, r.read(20000)


def notify_send(title, text):
    cfg = notify_load()
    out = {}
    with _nt_lock:
        now = time.time()
        _nt["sent"] = [t for t in _nt["sent"] if now - t < 3600]
        if len(_nt["sent"]) >= 40:
            return {"_limit": {"ok": False, "error": "More than 40 messages in an hour. Stopped to avoid spamming you."}}
        _nt["sent"].append(now)
    title = str(title or "Robodel")[:120]
    text = str(text or "")[:3500]
    tg = cfg.get("telegram") or {}
    if tg.get("token") and tg.get("chat"):
        try:
            body = json.dumps({"chat_id": tg["chat"], "text": (title + "\n" + text).strip()}).encode()
            st, _ = _post("https://api.telegram.org/bot" + urllib.parse.quote(tg["token"], safe=":") + "/sendMessage", body, {"Content-Type": "application/json"})
            out["telegram"] = {"ok": st == 200}
        except urllib.error.HTTPError as e:
            out["telegram"] = {"ok": False, "error": "Telegram said " + str(e.code) + (": check the bot token and that you pressed Start in the chat" if e.code in (400, 401, 403, 404) else "")}
        except Exception as e:
            out["telegram"] = {"ok": False, "error": str(e)[:120]}
    nt = cfg.get("ntfy") or {}
    if nt.get("topic"):
        try:
            server = (nt.get("server") or "https://ntfy.sh").rstrip("/")
            if not server.startswith(("https://", "http://")):
                raise ValueError("The ntfy server address must start with https://")
            st, _ = _post(server + "/" + urllib.parse.quote(nt["topic"], safe=""), text.encode("utf-8"), {"Title": title.encode("ascii", "replace").decode(), "Priority": "default", "Content-Type": "text/plain; charset=utf-8"})
            out["ntfy"] = {"ok": st == 200}
        except urllib.error.HTTPError as e:
            out["ntfy"] = {"ok": False, "error": "ntfy said " + str(e.code)}
        except Exception as e:
            out["ntfy"] = {"ok": False, "error": str(e)[:120]}
    ln = cfg.get("line") or {}
    if ln.get("token") and ln.get("to"):
        try:
            body = json.dumps({"to": ln["to"], "messages": [{"type": "text", "text": (title + "\n" + text).strip()[:4900]}]}).encode()
            st, _ = _post("https://api.line.me/v2/bot/message/push", body, {"Content-Type": "application/json", "Authorization": "Bearer " + ln["token"]})
            out["line"] = {"ok": st == 200}
        except urllib.error.HTTPError as e:
            out["line"] = {"ok": False, "error": "LINE said " + str(e.code) + (": check the channel access token and user ID" if e.code in (400, 401, 403) else "")}
        except Exception as e:
            out["line"] = {"ok": False, "error": str(e)[:120]}
    if not out:
        out["_none"] = {"ok": False, "error": "No phone channel is set up yet."}
    return out


# ---------------------------------------------------------------- Order ticket (Settrade Equity orders, every order confirmed by the person)
TRADE_FILE = os.path.join(DATA_DIR, "trade.json")
TRADE_LOG = os.path.join(DATA_DIR, "trade_log.json")
_tr_lock = threading.Lock()
_tr_tokens = {}
TR_DEFAULT = {"enabled": False, "dry_run": True, "account_no": "", "max_order_value": 50000, "max_daily_value": 200000, "max_orders_per_day": 10,
              "max_dev_pct": 10, "allow_market": False, "symbols": [], "fee_pct": 0.157}


def trade_cfg():
    try:
        with open(TRADE_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        d = {}
    c = dict(TR_DEFAULT); c.update(d if isinstance(d, dict) else {})
    return c


def trade_save(new):
    c = trade_cfg()
    for k in ("enabled", "dry_run", "allow_market"):
        if k in new:
            c[k] = bool(new[k])
    if "account_no" in new:
        c["account_no"] = re.sub(r"[^A-Za-z0-9\-]", "", str(new["account_no"]))[:20]
    for k, lo, hi in (("max_order_value", 0, 10_000_000), ("max_daily_value", 0, 100_000_000), ("max_orders_per_day", 1, 200), ("max_dev_pct", 1, 50), ("fee_pct", 0, 2)):
        if k in new:
            try:
                c[k] = max(lo, min(hi, float(new[k])))
            except Exception:
                pass
    if "symbols" in new:
        c["symbols"] = sorted({x for x in re.split(r"[,\s]+", str(new["symbols"] if not isinstance(new["symbols"], list) else ",".join(new["symbols"])).upper()) if re.match(r"^[A-Z0-9&\-]{1,16}$", x)})[:200]
    with open(TRADE_FILE, "w", encoding="utf-8") as f:
        json.dump(c, f)
    try:
        os.chmod(TRADE_FILE, 0o600)
    except Exception:
        pass
    return c


def trade_log_load():
    try:
        with open(TRADE_LOG, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except Exception:
        return []


def trade_log_add(e):
    with _tr_lock:
        d = trade_log_load(); d.append(e); d = d[-1000:]
        with open(TRADE_LOG, "w", encoding="utf-8") as f:
            json.dump(d, f)


def _bkk_day():
    return time.strftime("%Y-%m-%d", time.gmtime(time.time() + 7 * 3600))


def set_tick(p):
    """SET tick size for a stock price (THB)."""
    for lim, t in ((2, 0.01), (5, 0.02), (10, 0.05), (25, 0.10), (100, 0.25), (200, 0.50), (400, 1.0)):
        if p < lim:
            return t
    return 2.0


def trade_check(o, cfg=None):
    """Validate an order. Returns (clean order, errors, warnings). Nothing is sent from here."""
    cfg = cfg or trade_cfg(); errs, warns = [], []
    sym = str(o.get("symbol") or "").strip().upper(); side = str(o.get("side") or "").strip().capitalize()
    ptype = str(o.get("price_type") or "Limit"); validity = str(o.get("validity") or "Day")
    try:
        vol = int(float(o.get("volume") or 0))
    except Exception:
        vol = 0
    try:
        px = float(o.get("price") or 0)
    except Exception:
        px = 0.0
    try:
        ref = float(o.get("ref") or 0)
    except Exception:
        ref = 0.0
    if not re.match(r"^[A-Z0-9&\-]{1,16}$", sym):
        errs.append("Symbol is missing or has odd characters.")
    if side not in ("Buy", "Sell"):
        errs.append("Choose Buy or Sell.")
    if ptype not in ("Limit", "ATO", "ATC", "MP-MKT", "MP-MTL"):
        errs.append("Unknown price type.")
    if validity not in ("Day", "IOC", "FOK"):
        errs.append("Unknown validity.")
    if vol <= 0:
        errs.append("Volume must be a positive whole number.")
    elif vol % 100:
        warns.append("Volume is not a multiple of 100 (a board lot). It goes to the odd-lot board and may not fill.")
    if ptype != "Limit" and not cfg["allow_market"]:
        errs.append("Market-type orders are switched off in your trading settings. Use a limit price.")
    if ptype == "Limit":
        if px <= 0:
            errs.append("A limit order needs a price.")
        elif not re.search(r"-W|\d[CP]\d{4}", sym) and abs(px / set_tick(px) - round(px / set_tick(px))) > 1e-6:
            errs.append("Price %s is not on SET's tick size (%s at this price)." % (px, set_tick(px)))
    value = px * vol if px > 0 else 0.0
    if px > 0 and value > cfg["max_order_value"]:
        errs.append("Order value %s THB is above your limit of %s THB per order." % (format(value, ",.0f"), format(cfg["max_order_value"], ",.0f")))
    if cfg["symbols"] and sym not in cfg["symbols"]:
        errs.append("%s is not on your list of allowed symbols." % sym)
    if px > 0 and ref > 0:
        dev = abs(px / ref - 1) * 100
        if dev > cfg["max_dev_pct"]:
            errs.append("Price is %.1f%% away from the last price %s, more than your %.0f%% limit. Check for a typing mistake." % (dev, ref, cfg["max_dev_pct"]))
    elif ptype == "Limit":
        warns.append("No reference price was given, so the price could not be checked against the market.")
    day = _bkk_day(); today = [e for e in trade_log_load() if e.get("date") == day and e.get("status") in ("sent", "practice")]
    if len(today) >= cfg["max_orders_per_day"]:
        errs.append("You already reached %d orders today (your limit)." % cfg["max_orders_per_day"])
    used = sum(float(e.get("value") or 0) for e in today)
    if px > 0 and used + value > cfg["max_daily_value"]:
        errs.append("With today's %s THB already sent, this goes over your daily limit of %s THB." % (format(used, ",.0f"), format(cfg["max_daily_value"], ",.0f")))
    if not cfg["enabled"]:
        errs.append("Order tickets are switched off. Turn them on in Settings first.")
    if not cfg["dry_run"] and not cfg["account_no"]:
        errs.append("Enter your equity account number in the trading settings.")
    clean = {"symbol": sym, "side": side, "volume": vol, "price": px, "price_type": ptype, "validity": validity, "value": round(value, 2), "ref": ref}
    return clean, errs, warns


def trade_preview(o):
    cfg = trade_cfg(); clean, errs, warns = trade_check(o, cfg)
    r = {"ok": not errs, "errors": errs, "warnings": warns, "order": clean, "practice": bool(cfg["dry_run"]),
         "fee_est": round(clean["value"] * cfg["fee_pct"] / 100, 2)}
    if not errs:
        import secrets
        tok = secrets.token_urlsafe(18); now = time.time()
        for k in [k for k, v in _tr_tokens.items() if v[0] < now]:
            _tr_tokens.pop(k, None)
        _tr_tokens[tok] = (now + 120, clean); r["token"] = tok; r["expires_in"] = 120
    return r


def _st_equity(cfg):
    _st_market({**settrade_load()})                       # logs in (and keeps the login for 3 hours)
    inv = _st["inv"]
    if inv is None:
        raise RuntimeError("Not logged in to Settrade. Save your Settrade keys and press Test connection first.")
    return inv.Equity(account_no=cfg["account_no"])


def trade_place(body):
    cfg = trade_cfg(); tok = str(body.get("token") or ""); item = _tr_tokens.pop(tok, None)
    if not item or item[0] < time.time():
        return {"ok": False, "error": "This confirmation expired or was already used. Review the order again."}
    clean, errs, _w = trade_check(item[1], cfg)            # re-check at the moment of sending
    if errs:
        return {"ok": False, "error": errs[0], "errors": errs}
    e = dict(clean, at=int(time.time() * 1000), date=_bkk_day(), account=("..." + cfg["account_no"][-3:]) if cfg["account_no"] else "")
    if cfg["dry_run"]:
        e.update(status="practice", note="Practice mode: nothing was sent to the broker."); trade_log_add(e)
        return {"ok": True, "practice": True, "order": e}
    pin = str(body.get("pin") or "").strip()
    if not re.match(r"^\d{4,8}$", pin):
        return {"ok": False, "error": "Type your trading PIN (digits only). It is used for this order and not stored."}
    try:
        eq = _st_equity(cfg)
        kw = dict(symbol=clean["symbol"], price=clean["price"] if clean["price_type"] == "Limit" else clean["price_type"], volume=clean["volume"], side=clean["side"], pin=pin)
        if clean["price_type"] != "Limit":
            kw["price"] = clean["price_type"]
        else:
            kw["price_type"] = "Limit"
        kw["validity_type"] = clean["validity"]
        res = eq.place_order(**kw)
        e.update(status="sent", order_no=str((res or {}).get("orderNo") or (res or {}).get("order_no") or "") if isinstance(res, dict) else "")
        trade_log_add(e)
        return {"ok": True, "practice": False, "order": e, "reply": res if isinstance(res, dict) else None}
    except Exception as ex:
        msg = str(ex)
        msg = msg.replace(pin, "****")[:300]
        e.update(status="failed", error=msg); trade_log_add(e)
        return {"ok": False, "error": "The broker did not accept the order: " + msg}


def trade_orders():
    cfg = trade_cfg(); out = {"ok": True, "log": trade_log_load()[-60:][::-1], "live": None}
    if cfg["enabled"] and not cfg["dry_run"] and cfg["account_no"]:
        try:
            out["live"] = _st_equity(cfg).get_orders()
        except Exception as ex:
            out["live_error"] = str(ex)[:200]
    return out


def trade_account():
    cfg = trade_cfg()
    if not cfg["account_no"]:
        return {"ok": False, "error": "No account number saved."}
    try:
        return {"ok": True, "info": _st_equity(cfg).get_account_info()}
    except Exception as ex:
        return {"ok": False, "error": str(ex)[:200]}


def trade_cancel(body):
    cfg = trade_cfg(); pin = str(body.get("pin") or "").strip(); no = str(body.get("order_no") or "").strip()
    if cfg["dry_run"]:
        return {"ok": False, "error": "Practice mode has no live orders to cancel."}
    if not re.match(r"^\d{4,8}$", pin) or not re.match(r"^[A-Za-z0-9\-]{1,40}$", no):
        return {"ok": False, "error": "Order number or PIN is missing."}
    try:
        _st_equity(cfg).cancel_order(order_no=no, pin=pin)
        trade_log_add({"at": int(time.time() * 1000), "date": _bkk_day(), "status": "cancelled", "order_no": no, "symbol": str(body.get("symbol") or ""), "value": 0})
        return {"ok": True}
    except Exception as ex:
        return {"ok": False, "error": str(ex).replace(pin, "****")[:300]}


# ---------------------------------------------------------------- Robot guard (8.48): hard limits, arming, kill switch and audit log for automatic orders
# ---------------- Financial history (annual figures, as many years as free sources give) ----------------
FINHIST_FILE = os.path.join(DATA_DIR, "finhist.json")
_fh_lock = threading.Lock()
FH_FIELDS = ["rev", "gp", "op", "ni", "eps", "assets", "equity", "debt", "ocf", "capex", "fcf", "div", "shares"]
FH_YAHOO = {"annualTotalRevenue": "rev", "annualGrossProfit": "gp", "annualOperatingIncome": "op", "annualNetIncome": "ni",
            "annualBasicEPS": "eps", "annualTotalAssets": "assets", "annualStockholdersEquity": "equity", "annualTotalDebt": "debt",
            "annualOperatingCashFlow": "ocf", "annualCapitalExpenditure": "capex", "annualFreeCashFlow": "fcf",
            "annualCashDividendsPaid": "div", "annualOrdinarySharesNumber": "shares"}
# SET's own company-highlight feed uses names we cannot check from outside Thailand, so match by keyword
FH_SETKEYS = [("rev", ("totalrevenue", "revenue", "sales")), ("gp", ("grossprofit",)), ("ni", ("netprofit", "netincome", "profitloss")),
              ("eps", ("eps", "earningpershare")), ("assets", ("totalasset",)), ("equity", ("equity", "shareholder")),
              ("debt", ("totaldebt", "interestbearing")), ("ocf", ("operatingcashflow", "cashflowfromoperating", "cfo"))]


def fh_load():
    try:
        with open(FINHIST_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def fh_save(d):
    tmp = FINHIST_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, FINHIST_FILE)


def fh_yahoo(sym):
    types = ",".join(FH_YAHOO)
    out = {}
    for attempt in (0, 1):
        crumb = get_crumb(force=attempt == 1)
        url = ("https://query2.finance.yahoo.com/ws/fundamentals-timeseries/v1/finance/timeseries/"
               f"{urllib.parse.quote(sym)}.BK?type={types}&merge=false&period1=946684800&period2={int(time.time()) + 86400 * 30}"
               f"&crumb={urllib.parse.quote(crumb)}")
        try:
            with _open(url, 25) as r:
                j = json.loads(r.read().decode("utf-8", "replace"))
            break
        except urllib.error.HTTPError as e:
            if e.code in (401, 403) and attempt == 0:
                continue
            raise
    for res in (j.get("timeseries", {}).get("result") or []):
        t = (res.get("meta", {}).get("type") or [""])[0]
        k = FH_YAHOO.get(t)
        for pt in (res.get(t) or []):
            if not pt:
                continue
            v = (pt.get("reportedValue") or {}).get("raw")
            y = str(pt.get("asOfDate", ""))[:4]
            if k and y.isdigit() and v is not None:
                out.setdefault(int(y), {})[k] = v
    return out


def fh_set(sym):
    """SET's public company-highlight feed (same one the SET website uses). Field names are matched loosely."""
    url = f"https://www.set.or.th/api/set/stock/{urllib.parse.quote(sym)}/company-highlight/financial-data?lang=en"
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json", "Referer": f"https://www.set.or.th/en/market/product/stock/quote/{sym}/financial-statement/company-highlights"})
    with _opener.open(req, timeout=25) as r:
        j = json.loads(r.read().decode("utf-8", "replace"))
    rows = j if isinstance(j, list) else (j.get("data") or j.get("items") or [])
    out = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        y = row.get("year") or row.get("fiscalYear")
        q = str(row.get("quarter") or row.get("period") or "").upper()
        if not y or (q and q not in ("Q9", "9", "FY", "YEAR", "ANNUAL", "")):
            continue
        try:
            y = int(y)
            if y > 2400:
                y -= 543
        except Exception:
            continue
        for k, keys in FH_SETKEYS:
            for name, val in row.items():
                n = re.sub(r"[^a-z]", "", name.lower())
                if isinstance(val, (int, float)) and any(n == w or n.startswith(w) for w in keys):
                    out.setdefault(y, {}).setdefault(k, val)
                    break
    return out


def fh_get(sym, refresh=False):
    sym = sym.upper()
    with _fh_lock:
        store = fh_load()
    cur = store.get(sym, {"years": {}, "at": 0, "src": {}})
    if refresh or time.time() - cur.get("at", 0) > 86400 * 3:
        errs = {}
        for name, fn in (("SET", fh_set), ("Yahoo", fh_yahoo)):
            try:
                got = fn(sym)
                for y, d in got.items():
                    ent = cur["years"].setdefault(str(y), {})
                    for k, v in d.items():
                        if k not in ent or name == "SET":  # keep earlier figures, SET wins when both exist
                            ent[k] = v
                            cur["src"][f"{y}:{k}"] = name
                errs[name] = f"{len(got)} years"
            except Exception as e:
                errs[name] = "failed: " + str(e)[:120]
        cur["at"] = time.time()
        cur["tried"] = errs
        with _fh_lock:
            store = fh_load()
            store[sym] = cur
            fh_save(store)
    return {"ok": True, "symbol": sym, "years": cur["years"], "tried": cur.get("tried", {}), "at": cur.get("at"), "src": cur.get("src", {})}


# ---------------- YouTube channel logos and banners (for the Video Links tab) ----------------
YT_FILE = os.path.join(DATA_DIR, "ytmeta.json")
_yt = {"m": None, "q": [], "lock": threading.Lock(), "run": False}


def _yt_host_ok(u):
    try:
        p = urllib.parse.urlparse(u)
        return p.scheme == "https" and p.hostname in ("www.youtube.com", "youtube.com", "m.youtube.com")
    except Exception:
        return False


def yt_fetch(url):
    p = urllib.parse.urlparse(url)
    if p.path == "/watch":
        j = json.loads(_yt_get("https://www.youtube.com/oembed?format=json&url=" + urllib.parse.quote(url, safe="")))
        return {"name": j.get("title") or "", "sub": j.get("author_name") or "", "avatar": "", "banner": j.get("thumbnail_url") or ""}
    seg = p.path.split("/")[1] if p.path.count("/") >= 1 else ""
    if not seg:
        raise ValueError("no channel in link")
    h = _yt_get("https://www.youtube.com/" + seg)
    import html as _h
    def meta(prop):
        m = re.search(r'<meta[^>]+property="%s"[^>]+content="([^"]*)"' % re.escape(prop), h)
        return _h.unescape(m.group(1)) if m else ""
    av = meta("og:image")
    av = re.sub(r"=s\d+(-[^\s\"]*)?$", "=s120-c-k-c0x00ffffff-no-rj", av) if "googleusercontent" in av else av
    bn = ""
    m = re.search(r'"banner":\{"imageBannerViewModel":\{"image":\{"sources":\[(.*?)\]', h) or re.search(r'"banner":\{"thumbnails":\[(.*?)\]', h)
    if m:
        cand = re.findall(r'"url":"([^"]+)"(?:,"width":(\d+))?', m.group(1))
        best = None
        for u, w in cand:
            w = int(w or 0)
            if best is None or (w >= 640 and (best[1] < 640 or w < best[1])) or (best[1] < 640 and w > best[1]):
                best = (u, w)
        if best:
            try:
                bn = json.loads('"' + best[0] + '"')
            except Exception:
                bn = best[0]
    return {"name": meta("og:title"), "sub": "", "avatar": av, "banner": bn}


def _yt_get(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9", "Cookie": "CONSENT=YES+cb.20230531-17-p0.en+FX+000; SOCS=CAI"})
    with _opener.open(req, timeout=20) as r:
        return r.read(3_000_000).decode("utf-8", "replace")


def _yt_cache():
    if _yt["m"] is None:
        try:
            with open(YT_FILE, encoding="utf-8") as f:
                _yt["m"] = json.load(f)
        except Exception:
            _yt["m"] = {}
    return _yt["m"]


def _yt_worker():
    try:
        while True:
            with _yt["lock"]:
                if not _yt["q"]:
                    _yt["run"] = False
                    return
                u = _yt["q"].pop(0)
            try:
                d = yt_fetch(u)
                d["at"] = time.time()
            except Exception as e:
                d = {"err": str(e)[:100], "at": time.time()}
            with _yt["lock"]:
                _yt_cache()[u] = d
                try:
                    tmp = YT_FILE + ".tmp"
                    with open(tmp, "w", encoding="utf-8") as f:
                        json.dump(_yt["m"], f)
                    os.replace(tmp, YT_FILE)
                except Exception:
                    pass
            time.sleep(0.4)
    except Exception:
        _yt["run"] = False


def yt_meta(urls):
    urls = [u for u in urls if isinstance(u, str) and len(u) < 400 and _yt_host_ok(u)][:200]
    out = {}
    with _yt["lock"]:
        c = _yt_cache()
        for u in urls:
            e = c.get(u)
            ttl = 14 * 86400 if e and not e.get("err") else 86400
            if e and time.time() - e.get("at", 0) < ttl:
                if not e.get("err"):
                    out[u] = {k: e.get(k, "") for k in ("name", "sub", "avatar", "banner")}
            elif u not in _yt["q"]:
                _yt["q"].append(u)
        pending = len(_yt["q"])
        if pending and not _yt["run"]:
            _yt["run"] = True
            threading.Thread(target=_yt_worker, daemon=True).start()
    return {"ok": True, "meta": out, "pending": pending}


ROBOT_FILE = os.path.join(DATA_DIR, "robot.json")
ROBOT_LOG = os.path.join(DATA_DIR, "robot_log.jsonl")
KILL_FILE = os.path.join(DATA_DIR, "KILL")
_rb_lock = threading.Lock()
_rb = {"pin": None, "armed_until": 0.0, "recent": {}}
RB_DEFAULT = {"killed": False, "killed_at": 0, "kill_reason": "", "mode": "off", "max_order_value": 20000, "max_daily_value": 100000,
              "max_daily_orders": 20, "max_symbol_value": 50000, "max_dev_pct": 3.0, "symbols": [], "dup_secs": 60,
              "windows": [["10:05", "12:25"], ["14:35", "16:25"]]}
RB_MODES = ("off", "suggest", "confirm", "auto")


def robot_cfg():
    try:
        with open(ROBOT_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        d = {}
    c = json.loads(json.dumps(RB_DEFAULT))
    if isinstance(d, dict):
        c.update(d)
    return c


def _rb_write(c):
    tmp = ROBOT_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(c, f)
    os.replace(tmp, ROBOT_FILE)
    try:
        os.chmod(ROBOT_FILE, 0o600)
    except Exception:
        pass


def robot_save(new):
    """Change limits and mode. The kill state can only be cleared by robot_resume, never from here."""
    with _rb_lock:
        c = robot_cfg()
        if "mode" in new and str(new["mode"]) in RB_MODES:
            if c["killed"] and new["mode"] != "off":
                raise ValueError("The kill switch is on. Resume the robot first.")
            c["mode"] = str(new["mode"])
        for k, lo, hi in (("max_order_value", 0, 10_000_000), ("max_daily_value", 0, 100_000_000), ("max_daily_orders", 1, 500), ("max_symbol_value", 0, 50_000_000), ("max_dev_pct", 0.1, 20), ("dup_secs", 0, 3600)):
            if k in new:
                try:
                    c[k] = max(lo, min(hi, float(new[k])))
                except Exception:
                    pass
        if "symbols" in new:
            raw = new["symbols"] if isinstance(new["symbols"], list) else re.split(r"[,\s]+", str(new["symbols"]))
            c["symbols"] = sorted({str(x).upper() for x in raw if re.match(r"^[A-Za-z0-9&\-]{1,16}$", str(x))})[:300]
        if "windows" in new and isinstance(new["windows"], list):
            w = [[a, b] for a, b in (x for x in new["windows"] if isinstance(x, (list, tuple)) and len(x) == 2) if re.match(r"^\d{2}:\d{2}$", str(a)) and re.match(r"^\d{2}:\d{2}$", str(b))]
            if w:
                c["windows"] = w[:4]
        _rb_write(c)
    robot_audit("config", {"mode": c["mode"], "limits": {k: c[k] for k in ("max_order_value", "max_daily_value", "max_daily_orders", "max_symbol_value", "max_dev_pct")}})
    return c


def robot_audit(kind, data=None):
    try:
        e = {"t": int(time.time() * 1000), "day": _bkk_day(), "kind": str(kind)[:30], "d": data if isinstance(data, (dict, list)) else {"text": str(data)[:300]}}
        line = json.dumps(e, default=str)
        pin = _rb.get("pin")
        if pin:
            line = line.replace(pin, "****")
        with _rb_lock:
            try:
                if os.path.getsize(ROBOT_LOG) > 5_000_000:
                    os.replace(ROBOT_LOG, ROBOT_LOG + ".1")
            except OSError:
                pass
            with open(ROBOT_LOG, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        pass


def robot_log(n=200):
    try:
        with open(ROBOT_LOG, "r", encoding="utf-8") as f:
            lines = f.readlines()[-max(1, min(2000, int(n))):]
        out = []
        for ln in lines:
            try:
                out.append(json.loads(ln))
            except Exception:
                continue
        return out[::-1]
    except Exception:
        return []


def _rb_is_killed(c=None):
    c = c or robot_cfg()
    return bool(c.get("killed")) or os.path.exists(KILL_FILE)


def _rb_now_bkk():
    t = time.gmtime(time.time() + 7 * 3600)
    return t.tm_wday, t.tm_hour * 60 + t.tm_min


RB_AUCTION_WIN = {"ATO": [["09:30", "09:55"]], "ATC": [["16:30", "16:38"]]}


def _rb_in_window(c, ptype="Limit"):
    wd, m = _rb_now_bkk()
    if wd >= 5:
        return False
    for a, b in RB_AUCTION_WIN.get(ptype, c["windows"]):
        try:
            if int(a[:2]) * 60 + int(a[3:]) <= m <= int(b[:2]) * 60 + int(b[3:]):
                return True
        except Exception:
            continue
    return False


def _rb_keys_saved():
    """True when the Equity API key fields exist in settrade.json (the values are never sent anywhere)."""
    try:
        d = settrade_load()
        return bool(str(d.get("app_id") or "").strip() and str(d.get("app_secret") or "").strip() and str(d.get("broker_id") or "").strip())
    except Exception:
        return False


def robot_status():
    c = robot_cfg(); t = trade_cfg(); day = _bkk_day()
    today = [e for e in trade_log_load() if e.get("date") == day and e.get("status") in ("sent", "practice") and e.get("by") == "robot"]
    armed = bool(_rb["pin"]) and _rb["armed_until"] > time.time()
    return {"ok": True, "cfg": c, "killed": _rb_is_killed(c), "kill_file": os.path.exists(KILL_FILE), "armed": armed, "armed_until": int(_rb["armed_until"] * 1000) if armed else 0,
            "practice": bool(t["dry_run"]), "orders_enabled": bool(t["enabled"]), "account": ("..." + t["account_no"][-3:]) if t["account_no"] else "",
            "today_orders": len(today), "today_value": round(sum(float(e.get("value") or 0) for e in today), 2), "in_window": _rb_in_window(c),
            "keys_saved": _rb_keys_saved(), "shock_block": bool(shock_blocks()), "max_daily_orders": int(c.get("max_daily_orders") or 0)}


_rb_dd = {"peak": 0.0, "dd": 0.0, "limit": 9.0, "at": 0.0, "real": False}


def robot_equity(body):
    """The page reports the robot's money every ~30 s. The helper keeps its own peak and, in a real mode, enforces the drawdown limit itself."""
    try:
        e = float(body.get("equity")); lim = max(2.0, min(10.0, float(body.get("limit") or 9.0)))
    except Exception:
        return {"ok": False, "error": "bad equity"}
    real = bool(body.get("real"))
    with _rb_lock:
        if not real or e <= 0:
            _rb_dd.update(real=False, at=time.time())
            return {"ok": True, "dd": 0.0}
        if not _rb_dd["real"] or _rb_dd["peak"] <= 0:
            _rb_dd["peak"] = 0.0
        _rb_dd["peak"] = max(_rb_dd["peak"], e, float(body.get("peak") or 0))
        dd = (_rb_dd["peak"] - e) / _rb_dd["peak"] * 100.0
        _rb_dd.update(dd=dd, limit=lim, at=time.time(), real=True)
    c = robot_cfg()
    if dd >= min(10.0, lim + 1.0) and not _rb_is_killed(c) and c["mode"] in ("confirm", "auto"):
        robot_audit("dd_kill", {"dd": round(dd, 2), "limit": lim, "equity": e, "peak": _rb_dd["peak"]})
        robot_kill("Drawdown limit: robot is %.1f%% below its best level" % dd)
        return {"ok": True, "dd": dd, "killed": True}
    return {"ok": True, "dd": dd}


def robot_arm(body):
    c = robot_cfg()
    if _rb_is_killed(c):
        return {"ok": False, "error": "The kill switch is on. Resume the robot first."}
    pin = str(body.get("pin") or "").strip()
    if not re.match(r"^\d{4,8}$", pin):
        return {"ok": False, "error": "Type your trading PIN (digits only). It is kept in the helper's memory only, never saved."}
    try:
        mins = max(5, min(480, int(float(body.get("minutes") or 240))))
    except Exception:
        mins = 240
    _rb["pin"] = pin
    _rb["armed_until"] = time.time() + mins * 60
    robot_audit("arm", {"minutes": mins})
    return dict(robot_status(), ok=True)


def robot_disarm(reason="disarmed"):
    _rb["pin"] = None
    _rb["armed_until"] = 0.0
    robot_audit("disarm", reason)
    return robot_status()


def _rb_cancel_open(cfg_t):
    """Best effort: cancel every open order at the broker. Needs the armed PIN. Returns (cancelled, failed, note)."""
    pin = _rb["pin"]
    if cfg_t["dry_run"]:
        return 0, 0, "Practice mode: nothing was ever sent to the broker, so there is nothing to cancel."
    if not pin:
        return 0, 0, "The robot was not armed with your PIN, so the helper cannot cancel by itself. Open your broker app and cancel any open orders."
    done = bad = 0
    try:
        eq = _st_equity(cfg_t)
        orders = eq.get_orders() or []
    except Exception as ex:
        return 0, 0, "Could not read open orders (%s). Open your broker app and cancel them." % str(ex).replace(pin, "****")[:120]
    for o in orders if isinstance(orders, list) else []:
        if not isinstance(o, dict):
            continue
        st = str(o.get("status") or o.get("orderStatus") or "").lower()
        if any(w in st for w in ("match", "cancel", "reject", "expire", "done", "fill")) and "partial" not in st:
            continue
        no = str(o.get("orderNo") or o.get("order_no") or "")
        if not no:
            continue
        try:
            eq.cancel_order(order_no=no, pin=pin)
            done += 1
        except Exception:
            bad += 1
    return done, bad, ""


def robot_kill(reason="manual"):
    t = trade_cfg()
    with _rb_lock:
        c = robot_cfg()
        c.update(killed=True, killed_at=int(time.time() * 1000), kill_reason=str(reason)[:120], mode="off")
        _rb_write(c)
    done, bad, note = _rb_cancel_open(t)
    _rb["pin"] = None
    _rb["armed_until"] = 0.0
    robot_audit("kill", {"reason": str(reason)[:120], "cancelled": done, "cancel_failed": bad, "note": note})
    return {"ok": True, "killed": True, "cancelled": done, "cancel_failed": bad, "note": note}


def robot_resume(body):
    _rb_dd.update(peak=0.0, dd=0.0)
    if str(body.get("phrase") or "").strip() != "RESUME ROBOT":
        return {"ok": False, "error": "Type RESUME ROBOT exactly to resume."}
    with _rb_lock:
        c = robot_cfg()
        c.update(killed=False, kill_reason="", mode="off")
        _rb_write(c)
    try:
        os.remove(KILL_FILE)
    except OSError:
        pass
    robot_audit("resume", {})
    return robot_status()


def robot_check(o, body):
    """Every rule the helper enforces itself, whatever the page says. Returns (clean order, errors, warnings)."""
    c = robot_cfg(); t = trade_cfg(); errs = []
    if _rb_is_killed(c):
        errs.append("The kill switch is on. No order can be sent.")
    if c["mode"] not in ("confirm", "auto"):
        errs.append("The helper's robot mode is '%s'. Orders are only sent in confirm or auto mode." % c["mode"])
    elif c["mode"] == "confirm" and not body.get("confirmed"):
        errs.append("Confirm mode: the order needs your approval first.")
    if str(o.get("side")) == "Buy" and shock_blocks():
        errs.append("Overnight shock: new buys are blocked today (" + str(_shock.get("why") or "")[:120] + "). Selling is still allowed.")
    ptype = str(o.get("price_type") or "Limit")
    if ptype not in ("Limit", "ATO", "ATC"):
        errs.append("The robot sends limit, at-the-open (ATO) or at-the-close (ATC) orders only. Market orders are not allowed.")
    if not t["dry_run"]:
        if not (_rb["pin"] and _rb["armed_until"] > time.time()):
            errs.append("The robot is not armed. Arm it with your PIN (kept in memory only) for today.")
    merged = dict(t)
    merged.update(max_order_value=min(t["max_order_value"], c["max_order_value"]), max_daily_value=min(t["max_daily_value"], c["max_daily_value"]),
                  max_orders_per_day=min(t["max_orders_per_day"], int(c["max_daily_orders"])), max_dev_pct=min(t["max_dev_pct"], c["max_dev_pct"]), allow_market=False)
    if c["symbols"]:
        merged["symbols"] = sorted(set(c["symbols"]) & set(t["symbols"])) if t["symbols"] else list(c["symbols"])
        if not merged["symbols"]:
            merged["symbols"] = ["-"]
    # ATO/ATC have no price of their own: check the size against the reference (last) price as if it were a limit order
    probe = dict(o, price_type="Limit")
    if ptype in ("ATO", "ATC"):
        probe["price"] = o.get("ref")
    clean, e2, warns = trade_check(probe, merged)
    if ptype in ("ATO", "ATC"):
        clean["price_type"] = ptype
    errs += e2
    if not clean.get("ref"):
        errs.append("A reference (last) price is required so the helper can check the limit price.")
    if clean["volume"] % 100:
        errs.append("The robot trades whole board lots (multiples of 100) only.")
    if not _rb_in_window(c, ptype if ptype in ("ATO", "ATC") else "Limit"):
        wins = RB_AUCTION_WIN.get(ptype, c["windows"])
        errs.append("Outside the allowed time %s (Bangkok time, weekdays)." % ", ".join("%s-%s" % tuple(w) for w in wins))
    day = _bkk_day()
    if clean["side"] == "Buy" and _rb_dd["real"] and time.time() - _rb_dd["at"] < 300 and _rb_dd["dd"] >= 0.85 * _rb_dd["limit"]:
        errs.append("Drawdown guard: the robot is %.1f%% below its best level (limit %.0f%%), so no new buys." % (_rb_dd["dd"], _rb_dd["limit"]))
    if clean["side"] == "Buy":
        have = sum(float(e.get("value") or 0) for e in trade_log_load() if e.get("date") == day and e.get("status") in ("sent", "practice") and e.get("by") == "robot" and e.get("symbol") == clean["symbol"] and e.get("side") == "Buy")
        if have + clean["value"] > c["max_symbol_value"]:
            errs.append("Buying %s today would reach %s THB, above the per-stock limit of %s THB." % (clean["symbol"], format(have + clean["value"], ",.0f"), format(c["max_symbol_value"], ",.0f")))
    key = clean["symbol"] + "|" + clean["side"]
    last = _rb["recent"].get(key, 0)
    if c["dup_secs"] and time.time() - last < c["dup_secs"]:
        errs.append("The same %s order for %s was sent %d seconds ago (duplicate guard)." % (clean["side"].lower(), clean["symbol"], time.time() - last))
    return clean, errs, warns


def robot_order(body):
    o = body.get("order") if isinstance(body.get("order"), dict) else {}
    meta = {"rule": str(body.get("rule") or "")[:60], "why": str(body.get("why") or "")[:200], "oid": str(body.get("oid") or "")[:40]}
    clean, errs, warns = robot_check(o, body)
    if errs:
        robot_audit("order_rejected", dict(meta, order=clean, errors=errs))
        return {"ok": False, "error": errs[0], "errors": errs}
    t = trade_cfg()
    e = dict(clean, at=int(time.time() * 1000), date=_bkk_day(), by="robot", account=("..." + t["account_no"][-3:]) if t["account_no"] else "", rule=meta["rule"])
    _rb["recent"][clean["symbol"] + "|" + clean["side"]] = time.time()
    if t["dry_run"]:
        e.update(status="practice", note="Practice mode: nothing was sent to the broker.")
        trade_log_add(e); robot_audit("order_practice", dict(meta, order=clean))
        return {"ok": True, "practice": True, "order": e}
    pin = _rb["pin"]
    try:
        eq = _st_equity(t)
        if clean["price_type"] == "Limit":
            res = eq.place_order(symbol=clean["symbol"], price=clean["price"], volume=clean["volume"], side=clean["side"], pin=pin, price_type="Limit", validity_type=clean["validity"])
        else:
            res = eq.place_order(symbol=clean["symbol"], price=clean["price_type"], volume=clean["volume"], side=clean["side"], pin=pin, validity_type=clean["validity"])
        no = str((res or {}).get("orderNo") or (res or {}).get("order_no") or "") if isinstance(res, dict) else ""
        e.update(status="sent", order_no=no); trade_log_add(e)
        robot_audit("order_sent", dict(meta, order=clean, order_no=no))
        return {"ok": True, "practice": False, "order": e, "order_no": no}
    except Exception as ex:
        msg = str(ex).replace(pin or "\0", "****")[:300]
        e.update(status="failed", error=msg); trade_log_add(e)
        robot_audit("order_failed", dict(meta, order=clean, error=msg))
        return {"ok": False, "error": "The broker did not accept the order: " + msg}


def robot_cancel(body):
    t = trade_cfg(); no = str(body.get("order_no") or "").strip()
    if t["dry_run"]:
        return {"ok": False, "error": "Practice mode has no live orders to cancel."}
    if not (_rb["pin"] and _rb["armed_until"] > time.time()):
        return {"ok": False, "error": "The robot is not armed (needs your PIN in memory to cancel). Cancel in your broker app."}
    if not re.match(r"^[A-Za-z0-9\-]{1,40}$", no):
        return {"ok": False, "error": "Order number is missing."}
    try:
        _st_equity(t).cancel_order(order_no=no, pin=_rb["pin"])
        trade_log_add({"at": int(time.time() * 1000), "date": _bkk_day(), "status": "cancelled", "order_no": no, "symbol": str(body.get("symbol") or ""), "value": 0, "by": "robot"})
        robot_audit("order_cancelled", {"order_no": no, "why": str(body.get("why") or "")[:100]})
        return {"ok": True}
    except Exception as ex:
        return {"ok": False, "error": str(ex).replace(_rb["pin"] or "\0", "****")[:300]}


# ---------------- Robot guard: watches stops and targets every second, even when the page is closed or slow ----------------
GUARD_FILE = os.path.join(DATA_DIR, "robot_guards.json")
_gd = {"g": {}, "ev": [], "n": 0, "lock": threading.Lock(), "th": None, "px": {}}


def sg_tick(p):
    for lim, t in ((2, 0.01), (5, 0.02), (10, 0.05), (25, 0.10), (100, 0.25), (200, 0.50), (400, 1.0)):
        if p < lim:
            return t
    return 2.0


def sg_down(p, ticks=1):
    t = sg_tick(p)
    q = round(p / t - 1e-9)
    px = round((q - ticks) * t, 2)
    return max(px, 0.01)


def _gd_save():
    try:
        tmp = GUARD_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"g": _gd["g"], "n": _gd["n"]}, f)
        os.replace(tmp, GUARD_FILE)
    except Exception:
        pass


def _gd_load():
    if _gd["g"]:
        return
    try:
        with open(GUARD_FILE, encoding="utf-8") as f:
            d = json.load(f)
        _gd["g"] = {k: v for k, v in (d.get("g") or {}).items() if isinstance(v, dict)}
        for g in _gd["g"].values():
            if g.get("state") == "sent":
                g["state"] = "watch"
    except Exception:
        pass


def _gd_ev(kind, g, **kw):
    _gd["n"] += 1
    _gd["ev"].append(dict(kind=kind, sym=g.get("sym"), qty=g.get("qty"), n=_gd["n"], at=int(time.time() * 1000), **kw))
    _gd["ev"] = _gd["ev"][-200:]
    robot_audit("guard_" + kind, dict(sym=g.get("sym"), qty=g.get("qty"), **{k: v for k, v in kw.items() if isinstance(v, (str, int, float))}))


def robot_guard_set(body):
    """The page sends the exit levels of the positions it holds. The helper then watches them itself."""
    c = robot_cfg()
    items = body.get("guards") if isinstance(body.get("guards"), list) else []
    if _rb_is_killed(c) or c["mode"] not in ("confirm", "auto"):
        with _gd["lock"]:
            _gd["g"].clear(); _gd_save()
        return {"ok": True, "n": 0, "note": "Guard is idle: the helper robot is not in confirm or auto mode."}
    new = {}
    with _gd["lock"]:
        _gd_load()
        for it in items[:30]:
            try:
                sym = str(it["sym"]).upper()
                if not re.match(r"^[A-Za-z0-9&\-]{1,16}$", sym):
                    continue
                qty = int(it["qty"]); avg = float(it["avg"])
                if qty < 100 or qty % 100 or avg <= 0:
                    continue
                old = _gd["g"].get(sym, {})
                g = dict(sym=sym, qty=qty, avg=avg, stop=float(it.get("stop") or 0), target=float(it.get("target") or 0), trail=float(it.get("trail") or 0),
                         peak=max(float(it.get("peak") or 0), float(old.get("peak") or 0), avg), auto=bool(it.get("auto")), rule=str(it.get("rule") or "")[:60],
                         state=old.get("state", "watch"), tries=old.get("tries", 0), order_no=old.get("order_no", ""), t_sent=old.get("t_sent", 0), next=old.get("next", 0), errs=old.get("errs", 0))
                if old and old.get("qty") != qty and old.get("state") == "sent":
                    g.update(state="watch")
                new[sym] = g
            except Exception:
                continue
        _gd["g"] = new
        _gd_save()
        if new and (_gd["th"] is None or not _gd["th"].is_alive()):
            _gd["th"] = threading.Thread(target=_gd_loop, daemon=True)
            _gd["th"].start()
    return {"ok": True, "n": len(new)}


def robot_guards(since=0):
    with _gd["lock"]:
        _gd_load()
        gl = [dict(v, last=_gd["px"].get(k, {}).get("last"), age=round(time.time() - _gd["px"].get(k, {}).get("t", 0), 1) if _gd["px"].get(k) else None) for k, v in _gd["g"].items()]
        ev = [e for e in _gd["ev"] if e["n"] > since]
        return {"ok": True, "guards": gl, "events": ev, "n": _gd["n"], "alive": bool(_gd["th"] and _gd["th"].is_alive())}


def _gd_price(syms):
    cfg = settrade_load(); now = time.time()
    need = []
    with _lv_lock:
        for s in syms:
            q = _lv["q"].get(s)
            if q and q.get("last") and now - _lv["ts"] < 3:
                _gd["px"][s] = {"last": q["last"], "bid": q.get("bid"), "ask": q.get("ask"), "t": _lv["ts"]}
            else:
                need.append(s)
    if need and cfg.get("on") and cfg.get("app_id"):
        try:
            got = settrade_quotes(need, cfg, fresh=True)
            for s, n in got.items():
                if n and n.get("last"):
                    _gd["px"][s] = {"last": n["last"], "bid": n.get("bid"), "ask": n.get("ask"), "t": time.time()}
        except Exception:
            pass


def _gd_loop():
    idle = 0
    while True:
        try:
            with _gd["lock"]:
                gs = [dict(g) for g in _gd["g"].values()]
            if not gs:
                idle += 1
                if idle > 30:
                    break
                time.sleep(1.0); continue
            idle = 0
            c = robot_cfg()
            if _rb_is_killed(c):
                time.sleep(1.0); continue
            _gd_price([g["sym"] for g in gs if g["state"] in ("watch", "sent")])
            now = time.time()
            for g in gs:
                sym = g["sym"]; px = _gd["px"].get(sym)
                if g["state"] == "sent":
                    if now - g["t_sent"] >= 12:
                        _gd_recheck(sym)
                    continue
                if g["state"] != "watch" or not px or now - px["t"] > 20 or now < g.get("next", 0):
                    continue
                last = px["last"]; peak = max(g["peak"], last)
                why = ""
                lv = g["stop"] if g["stop"] > 0 else 0
                if g["trail"] > 0 and peak > g["avg"] * 1.005:
                    lv = max(lv, peak * (1 - g["trail"] / 100.0))
                if lv and last <= lv + 1e-9:
                    why = "guard: price %.2f reached the sell level %.2f" % (last, lv)
                elif g["target"] > 0 and last >= g["target"] - 1e-9:
                    why = "guard: price %.2f reached the target %.2f" % (last, g["target"])
                with _gd["lock"]:
                    if sym in _gd["g"]:
                        _gd["g"][sym]["peak"] = peak
                if not why or not g["auto"] or c["mode"] not in ("confirm", "auto"):
                    continue
                bid = px.get("bid") or last
                price = sg_down(min(bid, last), 1 + 2 * g["tries"])
                _rb["recent"].pop(sym + "|Sell", None)
                r = robot_order({"order": {"symbol": sym, "side": "Sell", "volume": g["qty"], "price": price, "ref": last, "price_type": "Limit", "validity": "Day"},
                                 "confirmed": True, "rule": g["rule"], "why": why, "oid": "guard"})
                with _gd["lock"]:
                    cur = _gd["g"].get(sym)
                    if not cur:
                        continue
                    if r.get("ok"):
                        cur.update(state="sent" if r.get("order_no") else "done", order_no=r.get("order_no") or "", t_sent=now, tries=cur["tries"] + 1, errs=0)
                        _gd_ev("fired", cur, order_no=r.get("order_no") or "", price=price, why=why, practice=bool(r.get("practice")), lag_ms=int((time.time() - px["t"]) * 1000), send_ms=int((time.time() - now) * 1000))
                    else:
                        cur["errs"] += 1; cur["next"] = now + (20 if "Outside the allowed time" in str(r.get("error")) else 4)
                        if cur["errs"] in (1, 10, 40):
                            _gd_ev("blocked", cur, why=str(r.get("error"))[:160])
                    _gd_save()
        except Exception as e:
            robot_audit("guard_error", {"error": str(e)[:160]})
        time.sleep(1.0)


def _gd_recheck(sym):
    """A guard sell has been working for 12 s. If it is still open, cancel it and send a lower one."""
    with _gd["lock"]:
        g = _gd["g"].get(sym)
        if not g or g["state"] != "sent":
            return
        no, tries = g["order_no"], g["tries"]
    r = robot_cancel({"order_no": no, "symbol": sym, "why": "guard: not filled in 12 s, repricing"})
    with _gd["lock"]:
        g = _gd["g"].get(sym)
        if not g:
            return
        if r.get("ok"):
            if tries >= 6:
                g.update(state="fail"); _gd_ev("failed", g, why="Six attempts did not fill. Sell by hand in your broker app.")
            else:
                g.update(state="watch", next=0); _gd_ev("repriced", g, order_no=no)
        elif "not armed" in str(r.get("error")).lower():
            g["t_sent"] = time.time()
        else:
            g.update(state="done"); _gd_ev("filled?", g, order_no=no, why="Could not cancel, so it has probably filled. Check your broker app.")
        _gd_save()


# ---------------- 8.56: entry triggers (helper buys the moment a price level is reached) ----------------
ENTRY_FILE = os.path.join(DATA_DIR, "robot_entries.json")
_en = {"e": {}, "lock": threading.Lock(), "th": None, "lat": []}


def sg_up(p, ticks=1):
    t = sg_tick(p)
    q = round(p / t + 1e-9)
    return round((q + ticks) * t, 2)


def _en_save():
    try:
        tmp = ENTRY_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_en["e"], f)
        os.replace(tmp, ENTRY_FILE)
    except Exception:
        pass


def _en_load():
    if _en["e"]:
        return
    try:
        with open(ENTRY_FILE, encoding="utf-8") as f:
            d = json.load(f)
        _en["e"] = {k: v for k, v in d.items() if isinstance(v, dict) and v.get("day") == _bkk_day()}
    except Exception:
        pass


def robot_entry_set(body):
    """body: {entries:[{sym, qty, level, when:'below'|'above', maxpx}]}. Replaces the list. Each trigger lives for the current Bangkok day only."""
    items = body.get("entries") if isinstance(body.get("entries"), list) else []
    new = {}
    with _en["lock"]:
        _en_load()
        for it in items[:20]:
            try:
                sym = str(it["sym"]).upper()
                if not re.match(r"^[A-Za-z0-9&\-]{1,16}$", sym):
                    continue
                qty = int(it["qty"]); lv = float(it["level"]); when = "above" if str(it.get("when")) == "above" else "below"
                mx = float(it.get("maxpx") or 0) or round(lv * 1.01, 2)
                if qty < 100 or qty % 100 or lv <= 0 or qty * lv > 5000000:
                    continue
                old = _en["e"].get(sym, {})
                same = old and old.get("level") == lv and old.get("qty") == qty and old.get("when") == when
                new[sym] = dict(sym=sym, qty=qty, level=lv, when=when, maxpx=mx, day=_bkk_day(), state=old.get("state", "watch") if same else "watch", rule=str(it.get("rule") or "Entry trigger")[:60])
            except Exception:
                continue
        _en["e"] = new
        _en_save()
        if new and (_en["th"] is None or not _en["th"].is_alive()):
            _en["th"] = threading.Thread(target=_en_loop, daemon=True)
            _en["th"].start()
    return {"ok": True, "n": len(new)}


def robot_entries():
    with _en["lock"]:
        _en_load()
        lat = list(_en["lat"][-20:])
        return {"ok": True, "entries": list(_en["e"].values()), "latency": lat}


def _en_loop():
    idle = 0
    while True:
        try:
            with _en["lock"]:
                es = [dict(e) for e in _en["e"].values() if e["state"] == "watch"]
            if not es:
                idle += 1
                if idle > 30:
                    break
                time.sleep(1.0); continue
            idle = 0
            c = robot_cfg()
            if _rb_is_killed(c) or c["mode"] not in ("confirm", "auto"):
                time.sleep(1.0); continue
            _gd_price([e["sym"] for e in es])
            for e in es:
                sym = e["sym"]; px = _gd["px"].get(sym)
                if e["day"] != _bkk_day():
                    with _en["lock"]:
                        _en["e"].pop(sym, None); _en_save()
                    continue
                if not px or time.time() - px["t"] > 20:
                    continue
                last = px["last"]; ask = px.get("ask") or last
                hit = (last <= e["level"]) if e["when"] == "below" else (last >= e["level"])
                if not hit:
                    continue
                if last > e["maxpx"]:
                    continue  # ran away past the highest price you accept: do not chase
                t_seen = time.time()
                why = "entry trigger: price %.2f %s %.2f" % (last, "fell to" if e["when"] == "below" else "rose to", e["level"])
                if c["mode"] != "auto":
                    with _en["lock"]:
                        _en["e"][sym]["state"] = "ready"; _en_save()
                    _gd_ev("entry_ready", dict(sym=sym, qty=e["qty"]), why=why + ". Robot is in confirm mode: approve it in the app.")
                    try:
                        notify_send("Robodel: " + sym + " reached your entry level", why)
                    except Exception:
                        pass
                    continue
                price = min(sg_up(ask, 0), e["maxpx"])
                _rb["recent"].pop(sym + "|Buy", None)
                r = robot_order({"order": {"symbol": sym, "side": "Buy", "volume": e["qty"], "price": price, "ref": last, "price_type": "Limit", "validity": "Day"},
                                 "confirmed": True, "rule": e["rule"], "why": why, "oid": "entry"})
                ms = int((time.time() - t_seen) * 1000)
                with _en["lock"]:
                    cur = _en["e"].get(sym)
                    if cur:
                        cur["state"] = "sent" if r.get("ok") else "blocked"
                        _en["lat"].append({"sym": sym, "send_ms": ms, "quote_age_ms": int((t_seen - px["t"]) * 1000), "ok": bool(r.get("ok"))})
                        _en_save()
                _gd_ev("entry_sent" if r.get("ok") else "entry_blocked", dict(sym=sym, qty=e["qty"]), why=why if r.get("ok") else str(r.get("error"))[:160], price=price, practice=bool(r.get("practice")), send_ms=ms, order_no=r.get("order_no") or "")
        except Exception as ex:
            robot_audit("entry_error", {"error": str(ex)[:160]})
        time.sleep(1.0)


# ---------------- 8.56: daily report to the phone ----------------
_dr = {"last": ""}


def daily_report_text():
    day = _bkk_day()
    try:
        log = [x for x in trade_log_load() if isinstance(x, dict) and x.get("date") == day]
    except Exception:
        log = []
    sent = [x for x in log if x.get("status") in ("sent", "practice")]
    failed = [x for x in log if x.get("status") == "failed"]
    buys = [x for x in sent if str(x.get("side")) == "Buy"]; sells = [x for x in sent if str(x.get("side")) == "Sell"]
    lines = ["Robodel daily report, " + day]
    c = robot_cfg()
    lines.append("Robot mode: %s%s" % (c.get("mode"), " (STOPPED by kill switch)" if _rb_is_killed(c) else ""))
    lines.append("Orders today: %d buy, %d sell%s" % (len(buys), len(sells), (", %d failed" % len(failed)) if failed else ""))
    for x in (buys + sells)[:8]:
        lines.append("  %s %s %s @ %s%s" % (x.get("side"), x.get("symbol"), x.get("volume"), x.get("price"), " (practice)" if x.get("status") == "practice" else ""))
    with _gd["lock"]:
        gev = [e for e in _gd["ev"] if time.strftime("%Y-%m-%d", time.gmtime(e["at"] / 1000 + 7 * 3600)) == day]
        gw = len(_gd["g"])
    if gw:
        lines.append("Guard is watching %d position(s)." % gw)
    for e in gev[:6]:
        lines.append("  Guard %s %s %s" % (e["kind"], e.get("sym"), str(e.get("why") or "")[:80]))
    if _rb_dd.get("real") and _rb_dd.get("peak", 0) > 0:
        lines.append("Robot real-money drawdown: %.1f%% below its best (limit %s%%)." % (float(_rb_dd.get("dd") or 0), _rb_dd.get("limit")))
    lines.append("Information only, not advice. Check your broker app for the real balance.")
    return "\n".join(lines)


def daily_report_send(force=False):
    cfg = notify_load(); day = _bkk_day()
    if not force and (not cfg.get("daily", {}).get("on", True) or _dr["last"] == day):
        return None
    at = str(cfg.get("daily", {}).get("at") or "17:45")
    now = time.strftime("%H:%M", time.gmtime(time.time() + 7 * 3600))
    if not force and (now < at or datetime_weekday_bkk() >= 5):
        return None
    if not any([(cfg.get("telegram") or {}).get("token"), (cfg.get("ntfy") or {}).get("topic"), (cfg.get("line") or {}).get("token")]):
        return None
    _dr["last"] = day
    return notify_send("Robodel daily report", daily_report_text())


def datetime_weekday_bkk():
    return time.gmtime(time.time() + 7 * 3600).tm_wday


def _dr_loop():
    while True:
        try:
            daily_report_send()
        except Exception as ex:
            robot_audit("daily_error", {"error": str(ex)[:120]})
        time.sleep(60)


# ---------------- 8.56: always-on (start with the computer) ----------------
def autostart_plan(script=None, python=None, home=None, system=None):
    script = os.path.abspath(script or __file__); python = python or sys.executable; home = home or os.path.expanduser("~"); system = system or platform.system()
    if system == "Windows":
        pyw = python.replace("python.exe", "pythonw.exe") if python.lower().endswith("python.exe") else python
        return {"system": "Windows", "file": None, "cmd": ["schtasks", "/Create", "/F", "/SC", "ONLOGON", "/TN", "RobodelHelper", "/TR", '"%s" "%s"' % (pyw, script)], "undo": ["schtasks", "/Delete", "/F", "/TN", "RobodelHelper"]}
    if system == "Darwin":
        f = os.path.join(home, "Library", "LaunchAgents", "com.robodel.helper.plist")
        body = ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n'
                '<key>Label</key><string>com.robodel.helper</string>\n<key>ProgramArguments</key><array><string>%s</string><string>%s</string></array>\n'
                '<key>EnvironmentVariables</key><dict><key>NO_BROWSER</key><string>1</string></dict>\n<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>\n</dict></plist>\n') % (python, script)
        return {"system": "macOS", "file": f, "body": body, "cmd": ["launchctl", "load", "-w", f], "undo": ["launchctl", "unload", "-w", f]}
    f = os.path.join(home, ".config", "systemd", "user", "robodel-helper.service")
    body = "[Unit]\nDescription=Robodel helper\nAfter=network-online.target\n\n[Service]\nEnvironment=NO_BROWSER=1\nExecStart=%s %s\nRestart=always\nRestartSec=5\n\n[Install]\nWantedBy=default.target\n" % (python, script)
    return {"system": "Linux", "file": f, "body": body, "cmd": ["systemctl", "--user", "enable", "--now", "robodel-helper.service"], "undo": ["systemctl", "--user", "disable", "--now", "robodel-helper.service"]}


def autostart(action, dry=False):
    import subprocess
    pl = autostart_plan()
    if action == "install" and pl.get("file"):
        print("Writing", pl["file"])
        if not dry:
            os.makedirs(os.path.dirname(pl["file"]), exist_ok=True)
            with open(pl["file"], "w", encoding="utf-8") as f:
                f.write(pl["body"])
    cmd = pl["cmd"] if action == "install" else pl["undo"]
    print("Running:", " ".join(cmd))
    if not dry:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            print((r.stdout or r.stderr or "done").strip()[:400])
        except Exception as e:
            print("Could not register it automatically:", e)
    if action == "uninstall" and pl.get("file") and not dry:
        try:
            os.remove(pl["file"])
        except Exception:
            pass
    print("Robodel will %s when you sign in." % ("now start" if action == "install" else "no longer start"))
    return pl



# ---------------- 8.58: overnight shock (world markets crashed: no new robot buys today) ----------------
SHOCK_FILE = os.path.join(DATA_DIR, "shock.json")
_shock = {"day": "", "level": "ok", "why": "", "override": False}


def _shock_load():
    try:
        with open(SHOCK_FILE, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and d.get("day") == _bkk_day():
            _shock.update({k: d.get(k) for k in ("day", "level", "why", "override")})
    except Exception:
        pass


def shock_blocks():
    if _shock["day"] != _bkk_day():
        _shock_load()
    return _shock["day"] == _bkk_day() and _shock["level"] == "shock" and not _shock["override"]


def robot_shock_set(body):
    lv = str(body.get("level") or "ok")
    if lv not in ("ok", "caution", "shock"):
        return {"ok": False, "error": "bad level"}
    _shock.update(day=_bkk_day(), level=lv, why=str(body.get("why") or "")[:300], override=bool(body.get("override")))
    try:
        with open(SHOCK_FILE, "w", encoding="utf-8") as f:
            json.dump(_shock, f)
    except Exception:
        pass
    robot_audit("shock", {"level": lv, "override": _shock["override"], "why": _shock["why"][:120]})
    return {"ok": True, "level": lv, "blocking": shock_blocks()}


# ---------------- 8.58: speed test ----------------
def _pct(a, q):
    a = sorted(a)
    return a[min(len(a) - 1, int(round((len(a) - 1) * q)))] if a else None


def speed_test():
    out = {"at": int(time.time() * 1000), "tests": []}

    def run(name, fn, n):
        ms = []; err = ""
        for _ in range(n):
            t0 = time.time()
            try:
                fn()
                ms.append((time.time() - t0) * 1000)
            except Exception as e:
                err = str(e)[:100]
        out["tests"].append({"name": name, "n": len(ms), "tried": n, "p50": round(_pct(ms, .5), 0) if ms else None, "p95": round(_pct(ms, .95), 0) if ms else None, "best": round(min(ms), 0) if ms else None, "error": err})
    run("Robot safety check (local)", lambda: robot_check({"symbol": "PTT", "side": "Buy", "volume": 100, "price": 30, "ref": 30, "price_type": "Limit", "validity": "Day"}, {}), 20)
    cfg = settrade_load()
    if cfg.get("on") and cfg.get("app_id"):
        run("Settrade price, one stock", lambda: settrade_quotes(["PTT"], cfg, fresh=True), 5)
        run("Settrade prices, 10 stocks together", lambda: settrade_quotes(["PTT", "AOT", "CPALL", "KBANK", "SCB", "ADVANC", "GULF", "BDMS", "SCC", "PTTEP"], cfg, fresh=True), 3)
    else:
        out["tests"].append({"name": "Settrade price", "n": 0, "tried": 0, "error": "Settrade keys are not saved, so real-time speed cannot be measured."})
    run("Yahoo price, one stock", lambda: fetch_quotes(["PTT"]), 3)
    with _gd["lock"]:
        out["guard_loop"] = {"watching": len(_gd["g"]), "events": len(_gd["ev"])}
    return out


# ---------------- Self-check: tests every outside feed from this computer and reports what really came back ----------------
def _keys_of(x, depth=0):
    if isinstance(x, dict):
        return sorted(str(k) for k in x.keys())[:60]
    if isinstance(x, list) and x:
        return _keys_of(x[0], depth + 1)
    return []


def selfcheck():
    res = []

    def run(name, fn):
        t0 = time.time()
        try:
            ok, detail = fn()
        except Exception as e:
            ok, detail = False, "error: " + str(e)[:160]
        res.append({"name": name, "ok": bool(ok), "detail": detail, "ms": int((time.time() - t0) * 1000)})

    def yahoo():
        code, body = fetch_quotes(["PTT"])
        j = json.loads(body.decode() if isinstance(body, bytes) else body)
        r = (j.get("quoteResponse", {}).get("result") or [])
        return bool(r) and code == 200, "PTT price %s" % (r[0].get("regularMarketPrice") if r else "none")

    def fund():
        code, body = fetch_fundamentals("PTT")
        return code == 200, "Yahoo fundamentals HTTP %s, %d bytes" % (code, len(body or b""))

    def fh_s():
        y = fh_set("PTT")
        return len(y) > 0, "SET feed: %d years %s; fields %s" % (len(y), sorted(y)[:12], sorted({k for d in y.values() for k in d})[:14])

    def fh_y():
        y = fh_yahoo("PTT")
        return len(y) > 0, "Yahoo: %d years %s; fields %s" % (len(y), sorted(y)[:12], sorted({k for d in y.values() for k in d})[:14])

    def yt():
        d = yt_fetch("https://www.youtube.com/@setthailand")
        return bool(d.get("avatar") or d.get("name")), "name=%r avatar=%s banner=%s" % (d.get("name"), "yes" if d.get("avatar") else "NO", "yes" if d.get("banner") else "NO")

    def st_q():
        cfg = settrade_load()
        if not (cfg.get("app_id") and cfg.get("app_secret")):
            return False, "Settrade keys are not saved yet (Settings)."
        got = settrade_quotes(["PTT"], cfg, fresh=True)
        q = got.get("PTT") or {}
        return bool(q.get("last")), "PTT last=%s bid=%s ask=%s; fields we got: %s" % (q.get("last"), q.get("bid"), q.get("ask"), ", ".join(sorted(q.keys())[:40]))

    def st_o():
        t = trade_cfg()
        if not (t["enabled"] and t["account_no"]):
            return False, "Trading is not set up (skipped)."
        if t["dry_run"]:
            return True, "Practice mode is on, so the broker order list is not read (skipped)."
        o = trade_orders()
        live = o.get("live")
        lst = live if isinstance(live, list) else (live or {}).get("data") if isinstance(live, dict) else None
        if o.get("live_error"):
            return False, "order list error: " + o["live_error"]
        return True, "order list OK, %d orders today; field names: %s" % (len(lst or []), ", ".join(_keys_of(lst or live)))

    for n, f in (("Yahoo prices", yahoo), ("Yahoo fundamentals", fund), ("Financial history: SET feed", fh_s), ("Financial history: Yahoo", fh_y),
                 ("YouTube channel logo", yt), ("Settrade live quotes", st_q), ("Settrade order list (field names only)", st_o)):
        run(n, f)
    ticks = tick_status()
    return {"ok": True, "version": "8.65", "checks": res, "ticks": ticks, "at": int(time.time() * 1000)}


# ---------------- Tick recorder: saves live prices of the robot's stocks so tests can use real data later ----------------
TICK_DIR = os.path.join(DATA_DIR, "ticks")
_tk = {"last": {}, "n": 0, "bytes": 0}


def tick_record(sym, n):
    try:
        if not n or not n.get("last"):
            return
        key = (n.get("last"), n.get("bid"), n.get("ask"), n.get("vol"))
        if _tk["last"].get(sym) == key:
            return
        _tk["last"][sym] = key
        os.makedirs(TICK_DIR, exist_ok=True)
        fn = os.path.join(TICK_DIR, _bkk_day() + ".csv")
        new = not os.path.exists(fn)
        if os.path.exists(fn) and os.path.getsize(fn) > 60_000_000:
            return
        with open(fn, "a", encoding="utf-8") as f:
            if new:
                f.write("t_ms,sym,last,bid,ask,vol\n")
            f.write("%d,%s,%s,%s,%s,%s\n" % (int(time.time() * 1000), sym, n.get("last"), n.get("bid") or "", n.get("ask") or "", n.get("vol") or ""))
        _tk["n"] += 1
    except Exception:
        pass


def tick_status():
    try:
        files = sorted(f for f in os.listdir(TICK_DIR) if f.endswith(".csv"))
        size = sum(os.path.getsize(os.path.join(TICK_DIR, f)) for f in files)
        return {"days": len(files), "first": files[0][:-4] if files else None, "last": files[-1][:-4] if files else None, "mb": round(size / 1e6, 2), "session_rows": _tk["n"]}
    except Exception:
        return {"days": 0, "first": None, "last": None, "mb": 0, "session_rows": _tk["n"]}


def _rb_watch():
    """Watches for the KILL file, so the kill switch also works from outside the page."""
    while True:
        try:
            if os.path.exists(KILL_FILE) and not robot_cfg().get("killed"):
                robot_kill("KILL file found")
            if _rb["pin"] and _rb["armed_until"] and time.time() > _rb["armed_until"]:
                robot_disarm("arming expired")
        except Exception:
            pass
        time.sleep(2.0)


# ---------------- TFEX (derivatives) through a second Settrade Open API login ----------------
TFEX_FILE = os.path.join(DATA_DIR, "settrade_d.json")
_sd = {"inv": None, "market": None, "login_at": 0, "cache": {}, "err": "", "ok_at": 0, "n": 0, "keys": []}
_sd_lock = threading.Lock()
_TFEX_SYM = re.compile(r"^[A-Za-z0-9&\-]{1,16}$")


def tfex_load():
    try:
        with open(TFEX_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        d = d if isinstance(d, dict) else {}
    except Exception:
        d = {}
    return d


def tfex_masked(cfg):
    def m(v):
        v = str(v or "")
        return ("*" * max(0, len(v) - 4) + v[-4:]) if v else ""
    return {"broker_id": cfg.get("broker_id", ""), "app_code": cfg.get("app_code", ""), "app_id": m(cfg.get("app_id")),
            "app_secret": m(cfg.get("app_secret")), "account_no": cfg.get("account_no", ""),
            "ready": bool(cfg.get("broker_id") and cfg.get("app_code") and cfg.get("app_id") and cfg.get("app_secret")),
            "status": {"err": _sd["err"], "ok_at": int(_sd["ok_at"] * 1000), "n": _sd["n"], "keys": _sd["keys"]}}


def tfex_save(new):
    cfg = tfex_load()
    for k in ("broker_id", "app_code", "app_id", "app_secret", "account_no"):
        if k in new and new[k] is not None:
            v = str(new[k]).strip()
            if v.startswith("*") and k in ("app_id", "app_secret"):
                continue
            if k == "account_no":
                v = re.sub(r"[^A-Za-z0-9\-]", "", v)[:20]
            if v:
                cfg[k] = v
            else:
                cfg.pop(k, None)
    with open(TFEX_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f)
    try:
        os.chmod(TFEX_FILE, 0o600)
    except Exception:
        pass
    with _sd_lock:
        _sd.update(inv=None, market=None, login_at=0, cache={}, err="")
    return cfg


def _sd_login(cfg):
    with _sd_lock:
        if _sd["inv"] is not None and time.time() - _sd["login_at"] < 3 * 3600:
            return _sd["inv"]
        if not (cfg.get("broker_id") and cfg.get("app_code") and cfg.get("app_id") and cfg.get("app_secret")):
            raise RuntimeError("Fill in and save the four derivatives fields first (Broker ID, App code, App ID, App secret).")
        try:
            from settrade_v2 import Investor
        except ImportError:
            raise RuntimeError("The Settrade library is not installed. Open a terminal and run:  pip install settrade-v2   then restart this helper.")
        inv = _investor_login(Investor, cfg)
        _sd.update(inv=inv, market=inv.MarketData(), login_at=time.time())
        return inv


def _sd_norm(raw):
    flat = {re.sub(r"[^a-z]", "", str(k).lower()): v for k, v in (raw or {}).items()}

    def pick(*names):
        for n in names:
            if n in flat and flat[n] is not None:
                return _st_num(flat[n])
        return None
    last = pick("last", "lastprice", "price", "close")
    if last is None:
        return None
    prior = pick("prior", "previousclose", "prevclose", "priorclose", "previoussettlement", "prevsettle")
    chg = pick("change")
    if prior is None and chg is not None:
        prior = last - chg
    return {"last": last, "prior": prior, "open": pick("open"), "high": pick("high"), "low": pick("low"),
            "vol": pick("totalvolume", "volume", "vol"), "oi": pick("openinterest", "oi", "openint"),
            "settle": pick("settlementprice", "settle", "settlement", "sp"), "bid": pick("bid", "bestbid", "bidprice"),
            "ask": pick("ask", "offer", "bestoffer", "askprice"), "status": str(flat.get("marketstatus") or flat.get("status") or "")}


def tfex_quotes(symbols):
    cfg = tfex_load(); _sd_login(cfg); market = _sd["market"]
    out, now, todo = {}, time.time(), []
    for s in symbols:
        c = _sd["cache"].get(s)
        if c and now - c[0] < 2:
            out[s] = c[1]
        else:
            todo.append(s)
    lock = threading.Lock(); errs = []

    def one(sym):
        try:
            raw = market.get_quote_symbol(sym)
            if isinstance(raw, dict) and not _sd["keys"]:
                _sd["keys"] = sorted(raw.keys())[:40]
            n = _sd_norm(raw)
            if n:
                with lock:
                    out[sym] = n
                    _sd["cache"][sym] = (time.time(), n)
            else:
                errs.append(sym + ": no last price")
        except Exception as e:
            errs.append(sym + ": " + str(e)[:100])
    ths = [threading.Thread(target=one, args=(s,), daemon=True) for s in todo]
    for i in range(0, len(ths), 10):
        for t in ths[i:i + 10]:
            t.start()
        for t in ths[i:i + 10]:
            t.join(20)
    if out:
        _sd.update(ok_at=time.time(), n=len(out), err="")
    elif errs:
        _sd["err"] = "; ".join(errs[:2])
        with _sd_lock:
            if any(("401" in e or "ogin" in e or "uthor" in e) for e in errs):
                _sd.update(market=None, inv=None)
    return out, [e for e in errs]


def _tfex_probe_symbols():
    """A few contract names that should exist now, to prove the data connection works."""
    codes = "FGHJKMNQUVXZ"; t = time.localtime(); out = []
    for k in range(0, 6):
        mo = (t.tm_mon - 1 + k) % 12; yr = (t.tm_year + (t.tm_mon - 1 + k) // 12) % 100
        if mo in (2, 5, 8, 11):                              # quarterly months H M U Z
            out.append("S50%s%02d" % (codes[mo], yr))
    return out[:3] or ["S50Z%02d" % (t.tm_year % 100)]


def tfex_test():
    """Step-by-step check. Every step records what worked and what Settrade said, so a mismatch is easy to read."""
    steps = []
    def step(name, fn):
        try:
            r = fn(); steps.append({"name": name, "ok": True, "detail": r}); return True
        except Exception as e:
            steps.append({"name": name, "ok": False, "detail": str(e)[:300]}); return False
    cfg = tfex_load()
    if not step("Log in with the derivatives app", lambda: (_sd_login(cfg), "logged in")[1]):
        return {"ok": False, "steps": steps, "fields": _sd["keys"]}
    market = _sd["market"]
    def q():
        got = {}
        for s in _tfex_probe_symbols():
            try:
                raw = market.get_quote_symbol(s)
                if isinstance(raw, dict):
                    _sd["keys"] = sorted(raw.keys())[:40]
                n = _sd_norm(raw)
                if n:
                    got[s] = n["last"]
            except Exception as e:
                pass
        if not got:
            raise RuntimeError("No quote came back for " + ", ".join(_tfex_probe_symbols()) + ". The contract name or your data permission may differ; add a symbol you know on the TFEX page.")
        return "quotes: " + ", ".join("%s %s" % kv for kv in got.items())
    step("Read a SET50 futures quote", q)
    acc = cfg.get("account_no")
    if acc:
        def der():
            d = _sd["inv"].Derivatives(account_no=acc)
            res = []
            for name in ("get_account_info", "get_portfolios"):
                f = getattr(d, name, None)
                if f is None:
                    res.append(name + ": not in this library version"); continue
                try:
                    r = f(); res.append(name + ": ok" + (" (" + ", ".join(sorted(r.keys())[:8]) + ")" if isinstance(r, dict) else " (%d rows)" % len(r) if isinstance(r, list) else ""))
                except Exception as e:
                    res.append(name + ": " + str(e)[:120])
            return "; ".join(res)
        step("Read the derivatives account (view only)", der)
    else:
        steps.append({"name": "Read the derivatives account (view only)", "ok": None, "detail": "Skipped: no derivatives account number saved."})
    return {"ok": all(s["ok"] is not False for s in steps), "steps": steps, "fields": _sd["keys"]}


def tfex_account():
    cfg = tfex_load(); acc = cfg.get("account_no")
    if not acc:
        raise RuntimeError("Save your derivatives account number first.")
    inv = _sd_login(cfg); d = inv.Derivatives(account_no=acc); out = {}
    for name, key in (("get_account_info", "account"), ("get_portfolios", "positions")):
        f = getattr(d, name, None)
        if f is None:
            out[key + "_error"] = "not in this version of the Settrade library"; continue
        try:
            out[key] = f()
        except Exception as e:
            out[key + "_error"] = str(e)[:200]
    return out


# ---------------------------------------------------------------- Installable app files (8.65)
PWA_MANIFEST = json.dumps({"name": "Robodel", "short_name": "Robodel", "description": "SET and mai Wyckoff scanner. Developed by Henry Poudel.", "start_url": "/", "scope": "/", "display": "standalone",
                           "orientation": "any", "background_color": "#0e1622", "theme_color": "#0e1622",
                           "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"}, {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]})
PWA_SW = """const C='robodel-shell-1';
self.addEventListener('install',e=>{self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==location.origin)return;
  if(r.mode==='navigate'){e.respondWith(fetch(r).then(x=>{const c=x.clone();caches.open(C).then(h=>h.put('/',c));return x}).catch(()=>caches.match('/')));return}
  if(/^\\/(icon-\\d+\\.png|manifest\\.webmanifest)$/.test(u.pathname)){e.respondWith(caches.match(r).then(m=>m||fetch(r).then(x=>{const c=x.clone();caches.open(C).then(h=>h.put(r,c));return x})))}});
"""
PWA_ICON_192 = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAF3klEQVR4nO3dO3IcVRQG4CsVMSELIPBG2A0pgatYAFUEpOzGGyHwAhx6AxDAGGk0munHfZx7z/eltjVd1v/3Od3TIz2VYL7/4ce/Rx8D7Xz98vlp9DG8NPRghJ1Sxpai+wsLPff0LkO3FxN89uhVhOYvIvic0boIzb644FNTqyJU/6KCT0u1i/Bc84sJP63VzliVNgk+I9SYBqcngPAzSo3snSqA8DPa2QweLoDwE8WZLB4qgPATzdFM7i6A8BPVkWzuKoDwE93ejG4ugPAziz1Z3VQA4Wc2WzP7sADCz6y2ZLfqoxAwm7sFcPZndo8y/G4BhJ9V3MuyFYjUbhbA2Z/VvJdpE4DU3hTA2Z9V3cq2CUBqrwrg7M/qrjNuApDatwI4+5PFy6ybAKSmAKT2XIr1h3wumTcBSE0BSE0BSE0BSO3JBTCZmQCkpgCkpgCkpgCkpgCkpgCkpgCkpgCkpgCkpgCk9t3oAyCHD58+vvtnf/30e8cjec2zQDR1L/jXRhTBCkQze8J/5O/XoAA0cTTMvUugAFR3NsQ9S6AAVFUrvL1KoACkpgBUU/us3WMKKACpKQCpKQCpKQCpKQBVjHgXtwYPw3HKrMG/UAAO6RH8Hg/HWYHYbfaz/ksmAJv1DH6vR6MVgId6n/F7fi5AAXjXiFWn94diXAPwxodPH6uEf2+YR3wizEcieaVV8H0mmNBGnPEjcA2QWM0df8bwl6IAadUK/6zBv1CAhLKuO7coALusEvwLBUjm6Nl/teBfeB8gEeF/ywRI4kj4Vw7+hQLwRobgX1iBEljp8eXaFGBxe8Of6exfigIsTfgfUwBKKTnDX4oCLMvev40CLMjqs50CJJc5/KUowHKi/06uaBRgIfb+/RRgEfb+YxQgIeH/nwIswOpznAJMzupzjgIkIvxvKcDE3PI8TwEmZe+vQwEmZO+vRwEWJ/z3KcBkrD51KcBErD71KcAkhL8NBViQ8G+nABOw97ejAMFZfdryg7GuXAdupkDNdKxR+A0x/3l0ph0RLo86tGcFKtuCVusXx21l7+8j/QSI+BOT7f39pL0GOHuGvfz70eEb/fqzS7kC1Vwvaq9GVp++0q1ArQN25oxs9ekv1QTocXbtdQYX/jrSTIARq8WekLrlOcbyF8Ejd+qtF8r2/nGWngDRgnWrCPb+sZadAGfCfx2yWkU6e+tU+OtbcgLUDH+tr1uDAtS3XAFahb/Waxwl/G0sU4CzoTwSMLc857dEAUaEv+br3yP8bU3/RtjZladGwIR0XlNPgB77/l41p4FitTdlAUavPFvMcIxMWIDZgnXkeIW/n6muAWYL/+U1BTquaSZAxH3/iIifPc5sigKsEv6XZv7pEysJXYAZVx7mEvYaQPjpIeTToCuuPMQUbgIIPz2FKoDw01uIFci+zyjDJ4DwM9LQCWDlYbShE8BnYxlt+Aq0N8zCT03DC1DK9lALP7WFKMAWwk8LoZ4FunVRLPi0FGoCXIdd+GktVAFK+T/0wk8PoVYg6C3cBICeFIDUFIDUFIDUFIDUFIDUFIDUFIDUFIDUFIDUQnwo/tpvf/w5+hBo5Ndffh59CK+EmwDCv7Zo399QBYj2n0Mbkb7PoQoAvSkAqSkAqT1//fL5afRBXES7Q0AbUb7PX798fgo3AaL859BGtO/vUyml+FgkGYWcANCTApDacyn/joLRBwI9XTJvApCaApDatwJYg8jiZdZNAFJ7VQBTgNVdZ9wEILU3BTAFWNWtbJsApHazAKYAq3kv0yYAqb1bAFOAVdzL8t0JoATM7lGGrUCk9rAApgCz2pLdTRNACZjN1sxuXoGUgFnsyequawAlILq9Gd19EawERHUkm4fuAikB0RzN5OHboEpAFGeyeOp9ACVgtLMZPP1GmBIwSo3sVQ2vnzBHDzVPulUfhTANaK12xpoF1jSgplYn1+ZnbEXgjNZbRbeVRRHYo9c63X1nVwTu6X0dOfSiVRkoZezNk3B3bZRibdHuFP4DHUYrOWhV/n8AAAAASUVORK5CYII=")
PWA_ICON_512 = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAASUklEQVR4nO3dPZIb1xWG4R4WY4ZcAANtRLtx6kBVXoCrGDj1brQRBVqAQm2ADsZDYoYYoLtxf86553liVxnoZvH9+qJNP22E9Onzl2+zPwNAC3//9efT7M/Az9yUSQQe4JmBMIeLPoDYAxxjFPTnAncg+ABtGQTtuaANCD7AWAbB41zAk0QfIAZj4BwX7QDRB4jNGNjPhbpD9AFyMgZuc3HeIfwAazAErnNRLog+wNqMgR9ciE34AaoxBIoPAOEHqK3yECj5xYUfgEsVh0CpLyz8ANxSaQiU+KLCD8ARFYbAh9kfoDfxB+CoCu1YduFUuHkA9LfqacByX0r4AehhtSGw1E8A4g9AL6s1Zok1s9pNASC2FU4D0p8AiD8Ao63QntQDYIUbAEBO2RuU8ggj+0UHYC0ZfxJIdwIg/gBEk7FNqQZAxgsMQA3ZGpXiyCLbRQWgtgw/CYQ/ARB/ALLJ0K7QAyDDBQSAa6I3LOwAiH7hAOCeyC0LOQAiXzAAOCJq08INgKgXCgDOiti2UAMg4gUCgBaiNS7MAIh2YQCgtUitCzEAIl0QAOgpSvOmD4AoFwIARonQvqkDIMIFAIAZZjdw2gCY/cUBYLaZLZwyAMQfAJ7NauLwASD+APDajDYOHQDiDwDXjW7ksAEg/gBw28hWDhkA4g8A+4xq5vR/BwAAGK/7APD0DwDHjGhn1wEg/gBwTu+GdhsA4g8Aj+nZUu8AAEBBXQaAp38AaKNXU5sPAPEHgLZ6tLXpABB/AOijdWO9AwAABTUbAJ7+AaCvlq1tMgDEHwDGaNVcPwEAQEEPDwBP/wAwVov2OgEAgIIeGgCe/gFgjkcbfHoAiD8AzPVIi/0EAAAFnRoAnv4BIIazTXYCAAAFHR4Anv4BIJYzbXYCAAAFHRoAnv4BIKajjXYCAAAF7R4Anv4BILYjrXYCAAAF7RoAnv4BIIe9zXYCAAAFGQAAUNDdAeD4HwBy2dNuJwAAUNDNAeDpHwByutdwJwAAUJABAAAFvTsAHP8DQG63Wu4EAAAKMgAAoKCrA8DxPwCs4b2mOwEAgIIMAAAo6KcB4PgfANZyre1OAACgIAMAAAoyAACgoFcDwO//ALCmt413AgAABRkAAFCQAQAABX0fAH7/B4C1XbbeCQAAFGQAAEBBBgAAFGQAAEBBH7bNC4AAUMVL850AAEBBBgAAFGQAAEBBBgAAFGQAAEBBBgAAFGQAAEBBT/4NAACoxwkAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABRkAABAQQYAABT0cfYHAKCeX37/bdd/7o9fv3b+JHU9ffr85dvsDwHA2vYG/x6DoB0DAIBuWoX/LUPgcQYAAM31Cv9bhsB5XgIEoKlR8R/937UaJwAANDE7xk4DjnECAMDDZsc/ymfIxAAA4CGRwhvps0RnAABwWsTgRvxMERkAAJwSObSRP1sUBgAAh2UIbIbPOJMBAAAFGQAAHJLpyTrTZx3NAABgt4xBzfiZRzAAAKAgAwCAXTI/SWf+7L0YAABQkAEAwF0rPEGv8B1aMgAAoCADAAAKMgAAoCADAICbVvrtfKXv8igDAAAKMgAAoCADAAAKMgAAeJffzNf1cfYHACAe4V+fAQDAd8Jfh58AANi2TfyrcQIAUJzw12QAABQl/LX5CQCgoKrx/+PXr7M/QhhOAAAKqRp+fmYAABQg/LxlAAAsTPh5j3cAABYl/q/5/f81JwAAixF+9jAAABYh/O/z9P8zAwAgOeHnDO8AACQm/vd5+r/OCQBAQsK/j/i/zwAASET4acVPAABJiP8xnv5vcwIAEJzwHyf+9xkAAEEJ/zniv48BABCM8J8n/vt5BwAgEPE/T/yPcQIAEIDwnyf85xgAABMJ/2PE/zwDAGCClcN/GeVe31P4H/f06fOXb7M/BEAlq8b/VpRbfWfhb8cAABhk1fBv2/Ew770Wgt+PAQDQmfATkXcAADoRfiLz7wAAdCD+ROcEAKAh4ScLAwCgkVXjL/xrMgAAGlgx/sK/NgMA4AErhn/bxL8CAwDgpBXjL/x1GAAACH9BBgDACas8/Qt/Xf4dAICDxJ8VOAEAOGCF+As/22YAAJQh/FzyEwDATpmf/sWft5wAAOyQNf7Cz3sMAIA7MsZf+LnHAABYiPCzl3cAAG7I9PQv/hzhBADgHVniL/ycYQAAXJEh/sLPIwwAgGSEnxa8AwDwRuSnf/GnFScAABeixl/4ac0AAPi/iPEXfnoxAAACEn568w4AwBbr6V/8GcEJAFBelPgLPyM5AQBKE3+qMgAAoCADACjL0z+VGQBASeJPdQYAUI74gwEAACUZAEApnv7hmQEAlCH+8IMBAJQg/vCaAQAABRkAwPI8/cPPDABgaeIP1xkAwLLEH95nAABAQQYAsCRP/3CbAQAsR/zhPgMAWIr4wz4GAAAUZAAAy/D0D/sZAMASxB+OMQCA9MQfjjMAAKAgAwBIzdM/nGMAAGmJP5xnAAApiT88xgAAgIIMACAdT//wOAMASEX8oQ0DAEhD/KEdAwAACjIAgBQ8/UNbBgAQnvhDewYAEJr4Qx8GAAAUZAAAYXn6h34MACAk8Ye+DAAgHPGH/gwAACjIAABC8fQPYxgAQBjiD+MYAEAI4g9jGQAAUJABAEzn6R/GMwCAqcQf5jAAgGnEH+YxAACgIAMAmMLTP8xlAADDiT/MZwAAQ4k/xGAAAEBBBgAwjKd/iMMAAIYQf4jFAAC6E3+IxwAAgIIMAKArT/8QkwEAdCP+EJcBAHQh/hCbAQAABRkAQHOe/iE+AwBoSvwhBwMAaEb8IY+Psz8AtHYrQsIA8Ozp0+cv32Z/CHjUmSdPY6AtT/+QiwFAeo+GRzAeJ/6QjwFAWq2jIx7niD/k5CVAUuoRnV9+/y1MzAB6cwJAOqMi7YnyviiDyb2C4wwA0pgVG3G5TvwhNwOAFCLERmh+iHA/ts09gUd4B4DwosTGOwLASpwAEFrk4FZ9+oxyT6pef2jFACCsKKG5p1KIotyTStccejEACCdKZI5aPUpR7svq1xlG8Q4AoUSJzBneEQAycQJAGKvFc6Un1Sj3ZqVrCrMZAIQQJTA9ZI9WlHuT/TpCNAYA00UJTG8ZAxbl3mS8dhDdx9kfgLqixGWUl+8rZkAETgCYolr8r4k+BKLco+jXCbIyABguSliiiBi4KPco4rWBVRgADBUlLBFFiV2UexTlesCq/DsADBMlLFH5dwSAkZwA0J2onTPjCTjKvfL0D/0ZAHQVJSiZjYphlHsl/jCGAUA3UYKyip5hjHKvxB/G8Q4AXUQJykq8IwC05ASA5kRqjFZPy1Hul6d/GMsAoKkoMankkXBGuV/iD+MZADQRJSSVHY1olHsm/jCHdwB4WJSQVOcdAeAIJwA8RHDiuvVkHeW+efqHeQwATosSEW57G9ko9038YS4DgFOiRGSPy9Bk+tyt/fHr1zDfX/xhPgOAQ6IEZI8MR+BVGQAwnwHAbpmiuTcwmb7TKsQfYjAA2CVTKM8EJtP3y0z8IQ4DgLsyxfHRwGT6rtmIP8Ti3wHgpkxBbBGYP379KlRACU4AuKpa+N+T6TpEZlRBPAYAP8kUvVFhyXRNohF/iMkA4JVMoZsRlkzXJwLxh7i8A8B3meI2KyzeEQBW4QSAbdvE/6xM1220SPcJ+JkBUFymgEUOSqbrOELkewU8MwAKyxStLEHJdE17yXKvoDrvABSVKVSZguIdASALJwAFif84ma51C9nvF1RiABSTKUgrxSTTdT9rpfsFFRgARWQL0KoxyXYf9lr1fsHKPs7+APSXKTqrh+Tl+2W6J8CanAAsLlNoVo//NZnuz3sq3jdYgQGwsExxqR6RTPfqUvX7BpkZAIvKFBQR+cF9A0bxDsBiMgVk20TkLe8IAKM4AVhIpmgI/z5R76n7B/kZAIuIGoprxOO4SPfX/YM1GAALiBSHe8TjMbPvtfsH6/D/BZDc7CAcIR6P8/81ALTiBCCpTOHfNvHvZeSfA/cQ1mIAJJQp/qIxRu8/E+4jrMcASEb8uaXHnw/3EdZkACQi/uzV6s+K+wjrMgCSEH/OeOTPjfsIazMAEhB/HvXL77/t+lcG3T+owwAITPgB6MW/AxCU+APQkwEQkPgD0JsBEIz4AzCCARCI+AMwysfZHwDhB2A8JwCTiT8AMxgAE4k/ALMYAJOIPwAzGQATiD8As3kJcCDhByAKJwCDiD8AkRgAA4g/ANEYAJ2JPwARGQAdiT8AUXkJsAPhByA6JwCNiT8AGRgADYk/AFkYAA1liWqWzwlAPwZAY9HjGv3zATCGAVCI+APw4unT5y/fZn+IFUV6H0D4AXjLCUAnUaIb5XMAEIsB0NHs+M7+7wcgLgOgs1kRFn8AbjEAFiT+ANzjJcBBRrwUKPwA7OUEYJDecRZ/AI4wAAbqFWnxB+AoA2Cw1rEWfwDOMAAmaBVt8QfgrI+zPwDHCT8Aj3ICMMnZiIs/AC0YABMdjbn4A9CKATDZ3qiLPwAtGQAB3Iu7+APQmpcAAxN+AHpxAhDE29iLPwA9GQCBvERf/AHozf8ZEAAU5AQAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgIAMAAAoyAACgoI+zPwCv/fs//539EQC6+dc//zH7I/B/T58+f/k2+0Mg/EAthsB8BsBkwg9UZgjM4x2AicQfqM7fg/MYAJP4Qw/wzN+HcxgAAFCQATCBtQvwmr8XxzMAAKAgA2AwKxfgOn8/jmUAAEBBBgAAFPTh77/+fJr9IQCAcf7+688nJwAAUJABAAAFGQCD+XevAa7z9+NYBgAAFGQATGDlArzm78XxDAAAKMgAmMTaBXjm78M5Pmzb8/8ecPYHqcgfeqA6fw+O99L87+H/9PnLt3kfB/8GNlCJ8M9jAARlCAArE/75DAAAKOhlAHgJEAAK+j4AvAgIAGu7bL0TAAAoyAAAgIIMAAAo6NUA8B4AAKzpbeOdAABAQQYAABRkAABAQT8NAO8BAMBarrXdCQAAFGQAAEBBVweAnwEAYA3vNd0JAAAUZAAAQEHvDgA/AwBAbrda7gQAAAoyAACgoJsDwM8AAJDTvYY7AQCAgu4OAKcAAJDLnnY7AQCAggwAACho1wDwMwAA5LC32U4AAKCg3QPAKQAAxHak1U4AAKCgQwPAKQAAxHS00U4AAKCgwwPAKQAAxHKmzU4AAKCgUwPAKQAAxHC2yU4AAKCg0wPAKQAAzPVIix86ATACAGCORxvsJwAAKOjhAeAUAADGatFeJwAAUFCTAeAUAADGaNXcZicARgAA9NWytX4CAICCmg4ApwAA0EfrxjY/ATACAKCtHm3t8hOAEQAAbfRqqncAAKCgbgPAKQAAPKZnS7ueABgBAHBO74Z2/wnACACAY0a00zsAAFDQkAHgFAAA9hnVzGEnAEYAANw2spVDfwIwAgDgutGNHP4OgBEAAK/NaOOUlwCNAAB4NquJ0/5XAEYAANXNbOHU/xmgEQBAVbMbOP3fAZh9AQBgtAjtmz4Ati3GhQCAEaI0L8QA2LY4FwQAeonUujADYNtiXRgAaCla40INgG2Ld4EA4FER2xZuAGxbzAsFAGdEbVrIAbBtcS8YAOwVuWVhB8C2xb5wAHBL9IaFHgDbFv8CAsBbGdoV/gNe+vT5y7fZnwEA3pMh/C/CnwBcynRhAaglW6NSDYBty3eBAVhfxjal+8CX/CQAwEwZw/8i3QnApcwXHoDcsjco9QDYtvw3AIB8VmhP+i9wyU8CAPS0QvhfpD8BuLTSjQEgltUas9SXueQ0AIAWVgv/iyW/1CVDAIAzVg3/i6V+Arhm9RsIQHsV2rH8F7zkNACAWyqE/0WZL3rJEADgUqXwvyj3hS8ZAgC1VQz/i7Jf/JIhAFBL5fC/KH8BLhkCAGsT/h9ciHcYAwBrEP3rXJQ7DAGAnIT/NhfnAGMAIDbR38+FOskYAIhB9M9x0RowBgDGEv3HuYAdGAQAbQl+ey7oAAYBwDGC358LPIlRAPBM7Odw0YMyEIBVCHxM/wOrkMTSNZTB1gAAAABJRU5ErkJggg==")


# ---------------------------------------------------------------- Phone over Wi-Fi (8.65): off unless started with --lan
LAN_FILE = os.path.join(DATA_DIR, "lan.json")
LAN_ON = False
LAN_FAILS = {}
# These carry a PIN, an API secret or the switch that enables real orders. They are never accepted from another device.
LAN_BLOCK = {"/robot/arm", "/trade/place", "/trade/cancel", "/trade/config", "/settrade/config", "/tfex/config", "/notify/config"}
LAN_OPEN = {"/ping", "/manifest.webmanifest", "/sw.js", "/icon-192.png", "/icon-512.png", "/"}


def lan_token():
    """The pairing code. Created once, kept in lan.json (owner-only), never sent anywhere except to a request from this computer."""
    try:
        with open(LAN_FILE, "r", encoding="utf-8") as f:
            t = str(json.load(f).get("token") or "")
        if len(t) >= 16:
            return t
    except Exception:
        pass
    import secrets
    t = secrets.token_urlsafe(12)
    try:
        with open(LAN_FILE, "w", encoding="utf-8") as f:
            json.dump({"token": t}, f)
        try:
            os.chmod(LAN_FILE, 0o600)
        except Exception:
            pass
    except Exception:
        pass
    return t


def lan_ips():
    out = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(0.5); s.connect(("10.255.255.255", 1)); out.append(s.getsockname()[0]); s.close()
    except Exception:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not ip.startswith("127.") and ip not in out:
                out.append(ip)
    except Exception:
        pass
    return out


def _is_loopback(addr):
    return str(addr).startswith("127.") or str(addr) in ("::1", "localhost") or str(addr).startswith("::ffff:127.")


def _lan_gate(handler, path, is_post):
    """Returns True when the request was refused (the answer is already sent)."""
    handler._lan_ok = False
    ip = handler.client_address[0]
    if _is_loopback(ip):
        return False
    def no(code, msg):
        handler._send(code, json.dumps({"ok": False, "error": msg}).encode(), "application/json"); return True
    if not LAN_ON:
        return no(403, "Phone access is switched off. Start the helper with --lan on the computer.")
    if path in LAN_OPEN and not is_post:
        handler._lan_ok = True
        return False
    now = time.time(); fails = [t for t in LAN_FAILS.get(ip, []) if now - t < 600]
    if len(fails) >= 8:
        return no(429, "Too many wrong pairing codes. Wait ten minutes.")
    tok = handler.headers.get("X-Robodel-Token") or ""
    if not tok:
        tok = urllib.parse.parse_qs(urllib.parse.urlparse(handler.path).query).get("token", [""])[0]
    import hmac
    if not hmac.compare_digest(tok.encode(), lan_token().encode()):
        fails.append(now); LAN_FAILS[ip] = fails
        return no(401, "Wrong or missing pairing code. Copy it from the helper window on the computer.")
    LAN_FAILS.pop(ip, None)
    if path in LAN_BLOCK:
        return no(403, "For safety your PIN, API secrets and the real-order switch are never accepted over Wi-Fi. Do this on the computer itself.")
    handler._lan_ok = True
    return False


def _local_origin(handler):
    if getattr(handler, "_lan_ok", False):
        return True
    o = handler.headers.get("Origin")
    if not o or o == "null":
        return True
    h = urllib.parse.urlparse(o).hostname or ""
    return h in ("127.0.0.1", "localhost", "::1")



# ---------------------------------------------------------------- Settrade Open API (real-time SET prices)
SETTRADE_FILE = os.path.join(DATA_DIR, "settrade.json")
_st = {"inv": None, "market": None, "login_at": 0, "watch": [], "cache": {}, "err": "", "ok_at": 0, "n": 0, "keys": []}
_st_lock = threading.Lock()


def _investor_login(Investor, cfg):
    """Log in with the saved values. A short numeric broker id (13) is retried as the 3-digit code (013)."""
    def mk(b):
        return Investor(app_id=cfg["app_id"], app_secret=cfg["app_secret"], broker_id=b, app_code=cfg["app_code"], is_auto_queue=False)
    b = str(cfg["broker_id"]).strip()
    try:
        return mk(b)
    except Exception as e:
        if b.isdigit() and len(b) < 3:
            try:
                return mk(b.zfill(3))
            except Exception:
                pass
        raise e


def settrade_load():
    try:
        with open(SETTRADE_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        d = d if isinstance(d, dict) else {}
    except Exception:
        d = {}
    if d and not str(d.get("app_code") or "").strip():
        d["app_code"] = "ALGO_EQ"
    return d


def settrade_masked(cfg):
    def m(v):
        v = str(v or "")
        return ("*" * max(0, len(v) - 4) + v[-4:]) if v else ""
    return {"broker_id": cfg.get("broker_id", ""), "app_code": cfg.get("app_code", ""), "app_id": m(cfg.get("app_id")),
            "app_secret": m(cfg.get("app_secret")), "on": bool(cfg.get("on")), "max": int(cfg.get("max") or 40), "sweep": int(cfg.get("sweep") if cfg.get("sweep") is not None else 20), "stream": bool(cfg.get("stream")), "stream_max": int(cfg.get("stream_max") or 150), "big_value": int(cfg.get("big_value") or 1000000),
            "ready": bool(cfg.get("broker_id") and cfg.get("app_code") and cfg.get("app_id") and cfg.get("app_secret")),
            "status": {"err": _st["err"], "ok_at": int(_st["ok_at"] * 1000), "n": _st["n"], "keys": _st["keys"]}}


def settrade_save(new):
    cfg = settrade_load()
    for k in ("broker_id", "app_code", "app_id", "app_secret"):
        if k in new and new[k] is not None:
            v = str(new[k]).strip()
            if v.startswith("*") and k in ("app_id", "app_secret"):
                continue
            if v:
                cfg[k] = v
            else:
                cfg.pop(k, None)
    if "on" in new:
        cfg["on"] = bool(new["on"])
    if "big_value" in new:
        try:
            cfg["big_value"] = max(10000, min(10 ** 9, int(new["big_value"])))
        except Exception:
            pass
    if "max" in new:
        try:
            cfg["max"] = max(1, min(200, int(new["max"])))
        except Exception:
            pass
    if "stream" in new:
        cfg["stream"] = bool(new["stream"])
    if "stream_max" in new:
        try:
            cfg["stream_max"] = max(10, min(400, int(new["stream_max"])))
        except Exception:
            pass
    if "sweep" in new:
        try:
            cfg["sweep"] = max(0, min(60, int(new["sweep"])))
        except Exception:
            pass
    with open(SETTRADE_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f)
    with _st_lock:
        _st.update(inv=None, market=None, login_at=0, cache={}, err="")
    return cfg


def _st_market(cfg):
    with _st_lock:
        if _st["market"] is not None and time.time() - _st["login_at"] < 3 * 3600:
            return _st["market"]
        try:
            from settrade_v2 import Investor
        except ImportError:
            raise RuntimeError("The Settrade library is not installed. Open a terminal and run:  pip install settrade-v2   then restart this helper.")
        inv = _investor_login(Investor, cfg)
        _st.update(inv=inv, market=inv.MarketData(), login_at=time.time())
        return _st["market"]


def _st_num(v):
    try:
        f = float(v)
        return f if f == f else None
    except Exception:
        return None


def _parse_depth(raw):
    """Collect bid/offer levels from keys like bid_price1, bidVolume3, offer_price10 ... Returns {"bids":[[p,v],..],"asks":[[p,v],..]} or None."""
    lv = {"bid": {}, "ask": {}}
    try:
        for k, v in (raw or {}).items():
            m = re.match(r"^(bid|offer|ask)(price|volume|vol|qty)?(\d+)(price|volume|vol|qty)?$", re.sub(r"[^a-z0-9]", "", str(k).lower()))
            if not m:
                continue
            side = "bid" if m.group(1) == "bid" else "ask"
            kind = m.group(2) or m.group(4) or "price"
            lv[side].setdefault(int(m.group(3)), {})["p" if kind == "price" else "v"] = _st_num(v)
    except Exception:
        return None
    out = {}
    for side, key in (("bid", "bids"), ("ask", "asks")):
        rows = [[d.get("p"), d.get("v")] for i, d in sorted(lv[side].items()) if d.get("p") is not None or d.get("v") is not None]
        out[key] = rows[:10]
    return out if out["bids"] or out["asks"] else None


def _st_norm(raw):
    """Map a Settrade quote onto the fields the page uses. Names are matched loosely."""
    flat = {re.sub(r"[^a-z]", "", str(k).lower()): v for k, v in (raw or {}).items() if not re.search(r"\d", str(k))}
    depth = _parse_depth(raw)

    def pick(*names):
        for n in names:
            if n in flat and flat[n] is not None:
                return _st_num(flat[n])
        return None
    last = pick("last", "lastprice", "price", "close")
    if last is None:
        return None
    prior = pick("prior", "previousclose", "prevclose", "priorclose")
    chg = pick("change")
    if prior is None and chg is not None:
        prior = last - chg
    n = {"last": last, "prior": prior, "open": pick("open"), "high": pick("high"), "low": pick("low"),
            "vol": pick("totalvolume", "volume", "vol"), "status": str(flat.get("marketstatus") or flat.get("status") or ""),
            "bid": pick("bid", "bestbid", "bid1", "bidprice", "bidprice1"), "ask": pick("offer", "ask", "bestoffer", "offer1", "ask1", "offerprice", "offerprice1"),
            "bidvol": pick("bidvolume", "bidvol", "bid1volume", "bidvolume1", "bidqty"), "askvol": pick("offervolume", "offervol", "askvolume", "offer1volume", "offervolume1", "askqty"),
            "value": pick("totalvalue", "value"), "ceiling": pick("ceiling", "ceilingprice"), "floor": pick("floor", "floorprice"),
            "avg": pick("average", "averageprice", "avgprice"), "popen": pick("projectedopen", "projopen", "projectedopenprice", "projectedopen2"),
            "pvol": pick("projectedvolume", "projvolume", "projectedopenvolume"), "depth": depth}
    if depth:
        if n["bid"] is None and depth["bids"]:
            n["bid"], n["bidvol"] = depth["bids"][0][0], depth["bids"][0][1]
        if n["ask"] is None and depth["asks"]:
            n["ask"], n["askvol"] = depth["asks"][0][0], depth["asks"][0][1]
    return n


def settrade_quotes(symbols, cfg=None, fresh=False):
    cfg = cfg or settrade_load()
    market = _st_market(cfg)
    out, now = {}, time.time()
    todo = []
    for s in symbols:
        c = _st["cache"].get(s)
        if c and now - c[0] < 2 and not fresh:
            out[s] = c[1]
        else:
            todo.append(s)
    lock = threading.Lock()
    errs = []

    def one(sym):
        try:
            raw = market.get_quote_symbol(sym)
            if isinstance(raw, dict) and not _st["keys"]:
                _st["keys"] = sorted(raw.keys())[:40]
            n = _st_norm(raw)
            if n:
                with lock:
                    out[sym] = n
                    _st["cache"][sym] = (time.time(), n)
            else:
                errs.append(sym + ": no last price in the reply")
        except Exception as e:
            errs.append(sym + ": " + str(e)[:100])
    ths = [threading.Thread(target=one, args=(s,), daemon=True) for s in todo]
    for i in range(0, len(ths), 10):
        batch = ths[i:i + 10]
        for t in batch:
            t.start()
        for t in batch:
            t.join(20)
    if out:
        _st.update(ok_at=time.time(), n=len(out), err=("; ".join(errs[:2]) if errs else ""))
    elif errs:
        _st["err"] = "; ".join(errs[:2])
        with _st_lock:
            if any(("401" in e or "ogin" in e or "uthor" in e) for e in errs):
                _st.update(market=None, inv=None)
    return out


def settrade_overlay(syms, code, body):
    cfg = settrade_load()
    if not cfg.get("on") or not (cfg.get("app_id") and cfg.get("app_secret")):
        return code, body
    watch = set(_st["watch"])
    want = [s for s in syms if s.upper().endswith(".BK") and s[:-3].upper() in watch][: int(cfg.get("max") or 40)]
    if not want:
        return code, body
    try:
        got = settrade_quotes([s[:-3].upper() for s in want], cfg)
    except Exception as e:
        _st["err"] = str(e)[:200]
        return code, body
    if not got:
        return code, body
    try:
        j = json.loads(body.decode("utf-8")) if body else {}
    except Exception:
        j = {}
    qr = j.setdefault("quoteResponse", {})
    res = qr.get("result")
    if not isinstance(res, list):
        res = qr["result"] = []
    bysym = {str(r.get("symbol", "")).upper(): r for r in res if isinstance(r, dict)}
    now = int(time.time())
    for s in want:
        n = got.get(s[:-3].upper())
        if not n:
            continue
        r = bysym.get(s.upper())
        if r is None:
            r = {"symbol": s}
            res.append(r)
        r.update(regularMarketPrice=n["last"], regularMarketTime=now, marketState=("REGULAR" if not n["status"] or "open" in n["status"].lower() else r.get("marketState", "REGULAR")), _src="settrade")
        if n["prior"] is not None:
            r["regularMarketPreviousClose"] = n["prior"]
            r["regularMarketChange"] = n["last"] - n["prior"]
            r["regularMarketChangePercent"] = (n["last"] / n["prior"] - 1) * 100 if n["prior"] else None
        for src, dst in (("open", "regularMarketOpen"), ("high", "regularMarketDayHigh"), ("low", "regularMarketDayLow"), ("vol", "regularMarketVolume")):
            if n[src] is not None:
                r[dst] = n[src]
    return 200, json.dumps(j).encode()


# ---------- 8.48: live engine (auto-polls Settrade, builds the ticker and big-lot feed from volume changes) ----------
import collections
import datetime
_START_T = time.time()


def health_report():
    """Quick health report for the Self-check page. Local facts first, then two short internet probes."""
    out = []
    add = lambda k, name, st, msg, fix="": out.append({"k": k, "name": name, "st": st, "msg": msg, "fix": fix})
    add("helper", "Helper", "ok", "Running, version 8.65, up %d minutes. Python %s." % (int((time.time() - _START_T) / 60), sys.version.split()[0]))
    try:
        t = os.path.join(DATA_DIR, ".selfcheck.tmp")
        with open(t, "w") as f:
            f.write("x")
        os.remove(t)
        add("disk", "Data folder", "ok", "Writable: " + DATA_DIR)
    except Exception as e:
        add("disk", "Data folder", "bad", "Cannot write to %s (%s)." % (DATA_DIR, str(e)[:80]), "Move the helper to a folder you own, such as Documents.")
    for fn_, nm in ((NOTIFY_FILE, "Phone-alert keys file"), (SETTRADE_FILE, "Settrade keys file")):
        if os.path.exists(fn_):
            try:
                mode = os.stat(fn_).st_mode & 0o077
                if os.name == "nt" or mode == 0:
                    add("perm_" + nm[:3], nm, "ok", "Present" + ("" if os.name == "nt" else " and owner-only."))
                else:
                    add("perm_" + nm[:3], nm, "warn", "Present but other users on this computer can read it.", "Run: chmod 600 " + fn_)
            except Exception:
                pass
    for mod, why in (("settrade_v2", "live prices and orders"), ("pypdf", "reading PDF reports")):
        try:
            __import__(mod)
            add("mod_" + mod, "Python package " + mod, "ok", "Installed (%s)." % why)
        except Exception:
            add("mod_" + mod, "Python package " + mod, "warn" if mod == "pypdf" else "info", "Not installed (%s)." % why, "pip install " + mod.replace("_", "-"))
    nc = notify_load()
    ch = [k for k in ("ntfy", "telegram", "line") if nc.get(k) and any(nc[k].values() if isinstance(nc[k], dict) else [nc[k]])]
    add("notify", "Phone alerts", "ok" if ch else "info", ("Set up: " + ", ".join(ch)) if ch else "No phone channel saved yet.", "" if ch else "Settings, Phone alerts.")
    cfg = settrade_load()
    if cfg.get("app_id") and cfg.get("app_secret"):
        age = time.time() - _st.get("ok_at", 0) if _st.get("ok_at") else None
        if not cfg.get("on"):
            add("settrade", "Settrade live prices", "info", "Keys saved but live prices are switched off.", "Settings, Settrade: tick the option.")
        elif age is not None and age < 120:
            add("settrade", "Settrade live prices", "ok", "Last good answer %d seconds ago." % age)
        elif _st.get("err"):
            add("settrade", "Settrade live prices", "bad", "Last error: " + str(_st["err"])[:140], "Check the keys in Settings; they expire if you regenerate them at your broker.")
        else:
            add("settrade", "Settrade live prices", "warn", "No price asked for yet (open a page with stocks during market hours).")
        rt = _lv["rt"]
        if cfg.get("stream"):
            add("stream", "Streaming prices", "ok" if rt.get("on") and _lv.get("streamed") else "warn",
                "%d stocks streaming fresh, %d messages received." % (_lv.get("fresh_n", 0), _lv.get("streamed", 0)) if _lv.get("streamed") else "Switched on but no message received yet. %s" % (rt.get("err") or "Wait for market hours."),
                "" if _lv.get("streamed") else "If this stays empty in market hours, your account may not allow realtime; untick Streaming in Settings.")
    else:
        add("settrade", "Settrade live prices", "info", "Not set up (optional).", "Settings, Settrade.")
    try:
        rc = robot_cfg()
        add("robot", "Robot", "warn" if rc.get("killed") else "ok", "Emergency stop is ON; nothing will trade." if rc.get("killed") else "Mode: %s." % rc.get("mode", "off"), "Robot page, clear the emergency stop when you are ready." if rc.get("killed") else "")
    except Exception:
        pass
    res = {}

    def probe(name, url):
        t0 = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with _opener.open(req, timeout=5) as r:
                r.read(512)
            res[name] = (True, int((time.time() - t0) * 1000), "")
        except Exception as e:
            res[name] = (False, int((time.time() - t0) * 1000), str(e)[:80])
    ths = [threading.Thread(target=probe, args=(n, u), daemon=True) for n, u in (("Yahoo Finance", "https://query1.finance.yahoo.com/v8/finance/chart/PTT.BK?range=1d&interval=1d"), ("SET website", "https://www.set.or.th/en/home"))]
    for t in ths:
        t.start()
    for t in ths:
        t.join(7)
    for n in ("Yahoo Finance", "SET website"):
        r = res.get(n)
        if r and r[0]:
            add("net_" + n[:3], n, "ok" if r[1] < 3000 else "warn", "Reachable in %d ms." % r[1])
        else:
            add("net_" + n[:3], n, "bad", "Not reachable (%s)." % (r[2] if r else "timed out"), "Check the internet connection, a VPN or a firewall.")
    return {"ok": True, "version": "8.65", "at": int(time.time() * 1000), "checks": out}


_lv = {"vp": {}, "bs": {}, "since": {}, "rt": {"on": False, "err": "", "keys": [], "depth": {}, "subs": {}, "conn": None}, "want": {}, "order": [], "focus": [], "tape": {}, "big": collections.deque(maxlen=300), "prev": {}, "q": {}, "ts": 0, "th": None, "last_req": 0, "polls": 0, "ms": 0}
_lv_lock = threading.Lock()

LIVE_DIR = os.path.join(DATA_DIR, "live_data")


def _bkk_day(ts=None):
    return datetime.datetime.fromtimestamp(ts or time.time(), datetime.timezone(datetime.timedelta(hours=7))).strftime("%Y-%m-%d")


def _lv_state():
    out = {}
    for sym in set(list(_lv["vp"]) + list(_lv["bs"])):
        out[sym] = {"vp": {str(p): v for p, v in _lv["vp"].get(sym, {}).items()}, "bs": _lv["bs"].get(sym, [0, 0, 0]), "since": _lv["since"].get(sym),
                    "tape": list(_lv["tape"].get(sym, []))[-200:], "big": [e for e in _lv["big"] if e.get("sym") == sym][-100:]}
    return out


def _lv_save():
    try:
        os.makedirs(LIVE_DIR, exist_ok=True)
        day = _bkk_day()
        st = _lv_state()
        if not st:
            return
        tmp = os.path.join(LIVE_DIR, "live_%s.json.tmp" % day)
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"day": day, "syms": st}, f)
        os.replace(tmp, os.path.join(LIVE_DIR, "live_%s.json" % day))
        for fn in sorted(os.listdir(LIVE_DIR))[:-40]:
            if fn.startswith("live_") and fn.endswith(".json"):
                os.remove(os.path.join(LIVE_DIR, fn))
    except Exception as e:
        _st["err"] = ("could not save live data: " + str(e))[:120]


def _lv_load_today():
    if _lv.get("loaded") == _bkk_day():
        return
    _lv["loaded"] = _bkk_day()
    try:
        with open(os.path.join(LIVE_DIR, "live_%s.json" % _bkk_day()), "r", encoding="utf-8") as f:
            d = json.load(f)
        for sym, v in d.get("syms", {}).items():
            _lv["vp"][sym] = {float(p): r for p, r in v.get("vp", {}).items()}
            _lv["bs"][sym] = v.get("bs", [0, 0, 0])
            if v.get("since"):
                _lv["since"][sym] = v["since"]
            _lv["tape"][sym] = collections.deque(v.get("tape", []), maxlen=200)
            for e in v.get("big", []):
                _lv["big"].append(e)
    except Exception:
        pass


def live_days(sym):
    out = []
    try:
        names = sorted(n for n in os.listdir(LIVE_DIR) if n.startswith("live_") and n.endswith(".json"))[-15:]
    except Exception:
        names = []
    for n in reversed(names):
        try:
            with open(os.path.join(LIVE_DIR, n), "r", encoding="utf-8") as f:
                d = json.load(f)
            v = d.get("syms", {}).get(sym)
            if not v:
                continue
            vp = sorted(((float(p), sum(r)) for p, r in v.get("vp", {}).items()), key=lambda x: -x[1])
            out.append({"day": d.get("day"), "bs": v.get("bs", [0, 0, 0]), "big": len(v.get("big", [])), "since": v.get("since"), "top": list(vp[0]) if vp else None})
        except Exception:
            continue
    return out


def live_flow(sym, now=None):
    now = now or time.time()
    b = s = nb = 0
    for e in list(_lv["tape"].get(sym, [])):
        if now - e["t"] <= 300:
            if e["s"] == "B":
                b += e["q"]
            elif e["s"] == "S":
                s += e["q"]
            if e.get("big"):
                nb += 1
    bs = _lv["bs"].get(sym, [0, 0, 0])
    return [b, s, bs[0], bs[1], nb]



def _lv_feed(sym, n, big_value, big_shares):
    pv = _lv["prev"].get(sym)
    v, last = n.get("vol"), n["last"]
    _lv["prev"][sym] = (v, last)
    if pv is None or v is None or pv[0] is None:
        return
    if v < pv[0]:
        for k in ("tape", "vp", "bs", "since"):
            _lv[k].pop(sym, None)
        return
    dv = v - pv[0]
    if dv <= 0:
        return
    bid, ask = n.get("bid"), n.get("ask")
    if ask and last >= ask:
        side = "B"
    elif bid and last <= bid:
        side = "S"
    else:
        side = "B" if last > pv[1] else ("S" if last < pv[1] else "")
    val = dv * last
    vp = _lv["vp"].setdefault(sym, {})
    row = vp.setdefault(last, [0, 0, 0])
    row[0 if side == "B" else 1 if side == "S" else 2] += int(dv)
    bs = _lv["bs"].setdefault(sym, [0, 0, 0])
    bs[0 if side == "B" else 1 if side == "S" else 2] += int(dv)
    _lv["since"].setdefault(sym, int(time.time()))
    ent = {"t": int(time.time()), "p": last, "q": int(dv), "s": side, "v": int(val), "big": bool(val >= big_value or (big_shares and dv >= big_shares))}
    _lv["tape"].setdefault(sym, collections.deque(maxlen=200)).append(ent)
    if ent["big"]:
        _lv["big"].append(dict(ent, sym=sym))


def _rt_msg_to_dict(res):
    if isinstance(res, dict):
        return res
    for attr in ("to_dict", "dict", "_asdict"):
        f = getattr(res, attr, None)
        if callable(f):
            try:
                return f()
            except Exception:
                pass
    try:
        return dict(vars(res))
    except Exception:
        return {}


def _rt_subscribe(conn, name, sym, on_msg, on_err):
    import inspect
    fn = getattr(conn, name)
    try:
        params = inspect.signature(fn).parameters
    except Exception:
        params = {}
    kw = {}
    if not params or "on_message" in params or any(p.kind == p.VAR_KEYWORD for p in params.values()):
        kw["on_message"] = on_msg
    if "on_error" in params:
        kw["on_error"] = on_err
    sub = fn(sym, **kw)
    try:
        sub.start()
    except Exception:
        pass
    return sub


def _rt_sync(foc, extra=None):
    """Keep live subscriptions (10-level bid/offer and price info) for the stocks being viewed. Best effort: failures are reported in the panel."""
    rt = _lv["rt"]
    inv = _st.get("inv")
    if inv is None:
        return
    try:
        if rt["conn"] is None:
            mk = getattr(inv, "RealtimeDataConnection", None) or getattr(inv, "MQTTWebsocket", None)
            if mk is None:
                raise RuntimeError("this version of the Settrade library has no realtime connection")
            rt["conn"] = mk()
        conn = rt["conn"]
        extra = [x for x in (extra or []) if x not in foc]
        wanted = set(foc) | set(extra)
        for key in list(rt["subs"]):
            if key[1] not in wanted or (key[0] == "bo" and key[1] not in foc):
                try:
                    rt["subs"].pop(key).stop()
                except Exception:
                    rt["subs"].pop(key, None)
        for sym in list(foc) + extra:
            for kind, name in (("bo", "subscribe_bid_offer"), ("pi", "subscribe_price_info")):
                if (kind, sym) in rt["subs"] or not hasattr(conn, name):
                    continue
                if kind == "bo" and sym not in foc:
                    continue

                def on_msg(res, subscriber=None, _s=sym, _k=kind):
                    d = _rt_msg_to_dict(res)
                    if not d:
                        return
                    rt["keys_" + _k] = sorted(str(k) for k in d.keys())[:70]
                    if _k == "bo":
                        dp = _parse_depth(d)
                        if dp:
                            rt["depth"][_s] = (time.time(), dp)
                    else:
                        rt.setdefault("pi", {})[_s] = (time.time(), d)
                        if _s not in _lv["focus"]:
                            try:
                                n3 = _st_norm(d) or {}
                                if n3.get("last"):
                                    with _lv_lock:
                                        _lv_feed(_s, n3, _lv.get("cbv", 1000000), _lv.get("cbs", 0))
                                        _lv["q"][_s] = n3
                                        _lv.setdefault("qt", {})[_s] = time.time()
                                        _lv["streamed"] = _lv.get("streamed", 0) + 1
                            except Exception:
                                pass

                def on_err(*a, **k):
                    rt["err"] = "realtime: " + " ".join(str(x) for x in a)[:160]
                try:
                    rt["subs"][(kind, sym)] = _rt_subscribe(conn, name, sym, on_msg, on_err)
                except Exception as e:
                    rt["err_" + kind] = str(e)[:160]
        rt["on"] = bool(rt["subs"])
        rt["err"] = "; ".join(x for x in (rt.get("err_bo", ""), rt.get("err_pi", "")) if x) or (rt["err"] if rt["err"].startswith("realtime:") else "")
    except Exception as e:
        rt["on"] = False
        rt["err"] = str(e)[:160]


def _lv_loop():
    while True:
        try:
            cfg = settrade_load()
            now = time.time()
            if now - _lv["last_req"] > 90 or not cfg.get("on"):
                break
            cap = int(cfg.get("max") or 40)
            with _lv_lock:
                foc = list(_lv["focus"])
                rest = [s for s in _lv["order"] if s not in foc] if now - _lv["last_req"] < 15 else []
            syms = (foc + rest)[: max(cap, len(foc))]
            prio = [x for x in _lv.get("prio", []) if x in syms or True][:30]
            _lv["loop"] = _lv.get("loop", 0) + 1
            if prio and _lv.get("fast"):
                syms = list(dict.fromkeys(prio + foc)) if _lv["loop"] % 4 else list(dict.fromkeys(prio + syms))[: max(cap, len(prio))]
            stream = bool(cfg.get("stream"))
            smax = max(10, min(400, int(cfg.get("stream_max") or 150)))
            _lv["cbv"], _lv["cbs"] = int(cfg.get("big_value") or 1000000), int(cfg.get("big_shares") or 0)
            if stream:
                ex = list(dict.fromkeys(list(_lv.get("order", [])) + list(_lv.get("sweep") or [])))[:smax]
                _rt_sync(foc, ex)
            else:
                ex = []
                _rt_sync(foc)
            pia = _lv["rt"].get("pi", {})
            fresh = {x for x in ex if time.time() - pia.get(x, (0,))[0] < 10 and x in _lv["q"]}
            _lv["fresh_n"] = len(fresh)
            syms = [x for x in syms if x in foc or x in _lv.get("prio", []) or x not in fresh]
            swn = int(cfg.get("sweep") if cfg.get("sweep") is not None else 20)
            sw_now = []
            if swn > 0 and _lv.get("sweep") and now - _lv["last_req"] < 15 and now > _lv.get("sw_pause", 0):
                have = set(syms)
                pool = _lv["sweep"]
                i0 = _lv.get("sw_i", 0) % max(1, len(pool))
                for k in range(len(pool)):
                    if len(sw_now) >= swn:
                        break
                    sy = pool[(i0 + k) % len(pool)]
                    if sy not in have and sy not in fresh:
                        sw_now.append(sy)
                _lv["sw_i"] = (i0 + max(1, len(sw_now))) % max(1, len(pool))
            if syms or sw_now:
                t0 = time.time()
                got = settrade_quotes(syms + sw_now, cfg, fresh=True)
                if "429" in (_st.get("err") or "") or "too many" in (_st.get("err") or "").lower():
                    _lv["sw_pause"] = time.time() + 60
                bv, bs = int(cfg.get("big_value") or 1000000), int(cfg.get("big_shares") or 0)
                with _lv_lock:
                    for sym, n in got.items():
                        if sym in prio or sym in foc:
                            tick_record(sym, n)
                        _lv_feed(sym, n, bv, bs)
                        _lv["q"][sym] = n
                        _lv.setdefault("qt", {})[sym] = time.time()
                    _lv.update(ts=time.time(), polls=_lv["polls"] + 1, ms=int((time.time() - t0) * 1000))
        except Exception as e:
            _st["err"] = str(e)[:200]
        if time.time() - _lv.get("saved", 0) > 30:
            _lv["saved"] = time.time()
            with _lv_lock:
                _lv_save()
        time.sleep(0.8 if _lv.get("fast") and time.time() - _lv["last_req"] < 15 else 2.0)
    with _lv_lock:
        _lv_save()
    _lv["th"] = None


def live_snapshot(symbols, focus, fast=False, prio=None, sweep=None, since=0):
    cfg = settrade_load()
    if not cfg.get("on"):
        return {"ok": False, "error": "Settrade live prices are switched off in Settings."}
    if not (cfg.get("app_id") and cfg.get("app_secret")):
        return {"ok": False, "error": "Settrade keys are not saved yet."}
    now = time.time()
    with _lv_lock:
        _lv_load_today()
        _lv["last_req"] = now
        _lv["fast"] = bool(fast)
        _lv["prio"] = list(prio or [])[:30]
        _lv["focus"] = [f for f in focus][:3]
        _lv["order"] = list(dict.fromkeys(symbols))
        if sweep is not None:
            _lv["sweep"] = list(dict.fromkeys(sweep))[:1500]
        for s in symbols + _lv["focus"]:
            _lv["want"][s] = now
        for s in [k for k, t in _lv["want"].items() if now - t > 300]:
            _lv["want"].pop(s, None)
        if _lv["th"] is None or not _lv["th"].is_alive():
            _lv["th"] = threading.Thread(target=_lv_loop, daemon=True)
            _lv["th"].start()
    with _lv_lock:
        q = {s: _lv["q"][s] for s in set(symbols + focus) if s in _lv["q"]}
        qt = _lv.get("qt", {})
        sw = {s: _lv["q"][s] for s in (sweep or []) if s not in q and s in _lv["q"] and qt.get(s, 0) * 1000 > since}
        tape = {s: list(_lv["tape"].get(s, []))[-80:] for s in focus}
        big = list(_lv["big"])[-60:]
        extra = {}
        for s_ in focus:
            pi = _lv["rt"].get("pi", {}).get(s_)
            if pi and now - pi[0] < 15 and s_ in q:
                try:
                    n2 = _st_norm(pi[1]) or {}
                    for k_, v_ in n2.items():
                        if v_ not in (None, "", {}) and k_ not in ("last", "prior", "depth", "status") and q[s_].get(k_) is None:
                            q[s_] = dict(q[s_], **{k_: v_})
                except Exception:
                    pass
        for s_ in focus:
            d_ = _lv["rt"]["depth"].get(s_)
            vp = sorted(([p, *v] for p, v in _lv["vp"].get(s_, {}).items()), key=lambda r: -r[0])
            extra[s_] = {"vp": vp[:60], "bs": _lv["bs"].get(s_, [0, 0, 0]), "since": _lv["since"].get(s_), "rt_depth": d_[1] if d_ and now - d_[0] < 15 else None}
        return {"ok": True, "ts": int(_lv["ts"] * 1000), "age": round(now - _lv["ts"], 1) if _lv["ts"] else None, "q": q, "sw": sw, "stream": {"on": bool(settrade_load().get("stream")), "fresh": _lv.get("fresh_n", 0), "got": _lv.get("streamed", 0)}, "swts": int(now * 1000), "swn": len(_lv.get("sweep") or []), "sw_pause": bool(now < _lv.get("sw_pause", 0)), "tape": tape, "big": big,
                "flow": {k: live_flow(k, now) for k in q}, "extra": extra, "rt": {"on": _lv["rt"]["on"], "err": _lv["rt"]["err"], "keys_bo": _lv["rt"].get("keys_bo", []), "keys_pi": _lv["rt"].get("keys_pi", []), "keys_q": list(_st["keys"])}, "err": _st["err"], "polls": _lv["polls"], "ms": _lv["ms"], "big_value": int(cfg.get("big_value") or 1000000)}


YSX_HIST_FILE = os.path.join(DATA_DIR, "ysx_history.json")
_yh_lock = threading.Lock()
_yh = {"state": "idle", "phase": "", "done": 0, "total": 0, "msg": "", "errors": [], "stop": False, "found": {}, "t0": 0}
_yh_cache = None


def _ysx_get(url, limit=6_000_000, timeout=40):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with _opener.open(req, timeout=timeout) as r:
        return r.read(limit)


def pdf_text(data):
    """Text of a PDF with the table layout kept. pypdf first, then the pdftotext program."""
    import io, shutil, subprocess
    problems = []
    try:
        import pypdf
        rd = pypdf.PdfReader(io.BytesIO(data))
        parts = []
        for pg in rd.pages:
            try:
                parts.append(pg.extract_text(extraction_mode="layout") or "")
            except TypeError:
                parts.append(pg.extract_text() or "")
        t = "\n".join(parts)
        if t.strip():
            return t, "pypdf"
        problems.append("pypdf found no text")
    except ImportError:
        problems.append("pypdf is not installed")
    except Exception as e:
        problems.append("pypdf: %s" % e)
    exe = shutil.which("pdftotext")
    if exe:
        try:
            p = subprocess.run([exe, "-layout", "-", "-"], input=data, capture_output=True, timeout=60)
            t = p.stdout.decode("utf-8", "ignore")
            if t.strip():
                return t, "pdftotext"
        except Exception as e:
            problems.append("pdftotext: %s" % e)
    raise RuntimeError("Cannot read PDFs (%s). Install the reader once with:  pip install pypdf" % "; ".join(problems))


_NUMRE = r"-?\d[\d,]*(?:\.\d+)?"
_TIMERE = re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\b")
_CODERE = re.compile(r"\b(\d{5})0000\b")


def _fnum(s):
    return float(s.replace(",", ""))


def parse_ysx_monthly(text):
    """One row per stock: open/high/low/close, each followed by its day of the month (bare "04" or "(04)"), then volume and value.
    Real layout (checked on the May 2026 report): code, name, O d H d L d C d, [net change], continuous vol/value, [block high low vol value], total vol/value."""
    lines = text.splitlines()
    rows = []
    isday = lambda x: re.fullmatch(r"\d{1,2}", x) is not None and 1 <= int(x) <= 31
    for i, line in enumerate(lines):
        m = _CODERE.search(line)
        if not m:
            continue
        rest = line[m.end():]
        for extra in range(1, 3):
            if len(re.findall(_NUMRE, rest.replace("(", " ").replace(")", " "))) >= 10:
                break
            if i + extra < len(lines) and not _CODERE.search(lines[i + extra]):
                rest += " " + lines[i + extra]
        tok = re.findall(_NUMRE, rest.replace("(", " ").replace(")", " "))
        if len(tok) < 8 or not all(isday(tok[k]) for k in (1, 3, 5, 7)):
            continue
        o, h, l, c = (_fnum(tok[k]) for k in (0, 2, 4, 6))
        if not (l <= min(o, c) and max(o, c) <= h and l > 0):
            continue
        tail = [_fnum(x) for x in tok[8:]]
        vol = val = None
        if len(tail) >= 2:
            v, w = tail[-2], tail[-1]
            if v > 0 and l * 0.97 <= w / v <= h * 1.03:
                vol, val = v, w
        rows.append([m.group(1), o, h, l, c, vol, val])
    return rows


def parse_ysx_daily(text):
    """Whole-day statistics: base price, listed shares, open/high/low/close (+ times), net change, volumes, values, market cap."""
    rows = []
    for line in text.splitlines():
        m = _CODERE.search(line)
        if not m:
            continue
        rest = _TIMERE.sub(" ", line[m.end():])
        nm = re.search(r"(?<![A-Za-z.])-?\d[\d,]*", rest)
        if not nm:
            continue
        T = [_fnum(x) for x in re.findall(_NUMRE, rest[nm.start():])]
        if len(T) < 8:
            continue
        base, shares = T[0], T[1]
        o, h, l, c = T[2:6]
        mcap = T[-1]
        if shares < 1e5 or base <= 0 or l <= 0:
            continue
        if not (l <= min(o, c) and max(o, c) <= h and 0.5 * base <= c <= 2 * base):
            continue
        if mcap > 0 and abs(c * shares / 1e6 - mcap) > max(1.5, 0.01 * mcap):
            continue
        mid = T[7:-1] if len(T) > 8 else []
        val = max(mid) if mid else None
        vol = None
        if val:
            cands = [v for v in mid if v > 0 and v != val and l * 0.99 <= val / v <= h * 1.01]
            vol = max(cands) if cands else None
        rows.append([m.group(1), o, h, l, c, vol, val])
    return rows


def _yh_load():
    global _yh_cache
    if _yh_cache is None:
        try:
            with open(YSX_HIST_FILE, encoding="utf-8") as f:
                _yh_cache = json.load(f)
        except Exception:
            _yh_cache = {"v": 1, "files": {}, "found": {}, "at": 0}
    return _yh_cache


def _yh_save():
    c = _yh_load()
    tmp = YSX_HIST_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(c, f, separators=(",", ":"))
    os.replace(tmp, YSX_HIST_FILE)


def ysx_discover(years):
    """Finds the PDF report links on the listing pages. Returns (monthly, daily, problems)."""
    monthly, daily, problems = {}, {}, []
    pages = []
    for y in years:
        pages.append(("m", YSX + "/mktdata/historicaldata/monthly-report/?cbomonthyear=%d" % y))
        pages.append(("d", YSX + "/mktdata/historicaldata/daily-report/?cbohisyear=%d" % y))
    pages += [("md", YSX + "/main-board/mktdata/historicaldata/"), ("md", YSX + "/pre-listing-board/marketdata/historical-data/")]
    for kind, url in pages:
        if _yh["stop"]:
            break
        try:
            body = _ysx_get(url, 3_000_000).decode("utf-8", "ignore")
        except Exception as e:
            problems.append("%s: %s" % (url.replace(YSX, ""), e))
            continue
        for href in re.findall(r"href=[\"']([^\"']+?\.pdf)[\"']", body, re.I):
            full = urllib.parse.urljoin(url, htmllib.unescape(href))
            name = full.rsplit("/", 1)[-1]
            md = re.match(r"hd_(\d{2})(\d{2})(\d{4})(?:_(\d{1,2}))?\.pdf$", name, re.I)
            mm = re.match(r"hd_(\d{2})(\d{4})\.pdf$", name, re.I)
            if md:
                d, mo, y, n = int(md.group(1)), int(md.group(2)), int(md.group(3)), int(md.group(4) or 0)
                if 1 <= mo <= 12 and 1 <= d <= 31:
                    key = "%04d-%02d-%02d" % (y, mo, d)
                    grp = "pl" if "pre-listing" in url else "mb"
                    cur = daily.get((grp, key))
                    if not cur or n > cur[0]:
                        daily[(grp, key)] = (n, full)
            elif mm and 1 <= int(mm.group(1)) <= 12:
                monthly["%s-%s" % (mm.group(2), mm.group(1))] = full
    return monthly, daily, problems


def ysx_guess(monthly, daily, all_daily):
    """The listing pages only show one year without a working year selector, so build the links from their naming pattern:
    uploads/YYYY/MM/hd_MMYYYY.pdf (monthly) and uploads/YYYY/MM/hd_DDMMYYYY_07.pdf (whole-day). Returns [(kind, when, url, alt_url)]."""
    import datetime as _dt
    out = []
    today = _dt.date.today()
    first = _dt.date(2016, 3, 1)
    have_m = set(monthly)
    y, mth = first.year, first.month
    while (y, mth) < (today.year, today.month):
        ym = "%04d-%02d" % (y, mth)
        if ym not in have_m:
            ny, nm = (y + 1, 1) if mth == 12 else (y, mth + 1)
            u1 = "%s/wp-content/uploads/%04d/%02d/hd_%02d%04d.pdf" % (YSX, y, mth, mth, y)
            u2 = "%s/wp-content/uploads/%04d/%02d/hd_%02d%04d.pdf" % (YSX, ny, nm, mth, y)
            out.append(("m", ym, u1, u2))
        y, mth = (y + 1, 1) if mth == 12 else (y, mth + 1)
    have_d = {k for (_g, k) in daily}
    start = _dt.date(2016, 3, 25) if all_daily else max(_dt.date(2016, 3, 25), today - _dt.timedelta(days=3 * 365))
    d = today - _dt.timedelta(days=1)
    while d >= start:
        if d.weekday() < 5:
            key = d.isoformat()
            if key not in have_d:
                out.append(("d", key, "%s/wp-content/uploads/%04d/%02d/hd_%02d%02d%04d_07.pdf" % (YSX, d.year, d.month, d.day, d.month, d.year), None))
        d -= _dt.timedelta(days=1)
    return out


def ysx_hist_job(refresh=False, all_daily=False):
    c = _yh_load()
    _yh.update(state="running", phase="Looking for the reports on ysx-mm.com", done=0, total=0, msg="", errors=[], stop=False, t0=time.time())
    try:
        now_y = time.gmtime().tm_year
        monthly, daily, problems = ysx_discover(range(2016, now_y + 1))
        _yh["errors"] += problems[:10]
        c["found"] = {"monthly": len(monthly), "daily": len(daily)}
        _yh["found"] = c["found"]
        todo = []
        for ym in sorted(monthly):
            u = monthly[ym]
            f = c["files"].get(u)
            if not f or (not f.get("ok") and refresh) or (f.get("ok") and not f.get("rows") and refresh):
                todo.append(("m", ym, u, None))
        for (grp, ymd) in sorted(daily, reverse=True):
            u = daily[(grp, ymd)][1]
            f = c["files"].get(u)
            if not f or (not f.get("ok") and refresh):
                todo.append(("d", ymd, u, None))
        # links the listing pages did not show: build them from the naming pattern (404 = no report that day)
        import datetime as _dt
        now_ms = time.time()
        for kind, when, u1, u2 in ysx_guess(monthly, daily, all_daily):
            f = c["files"].get(u1) or (c["files"].get(u2) if u2 else None)
            recent = (kind == "m" and when >= _dt.date.fromtimestamp(now_ms - 100 * 86400).strftime("%Y-%m")) or (kind == "d" and when >= _dt.date.fromtimestamp(now_ms - 7 * 86400).isoformat())
            if f and (f.get("ok") or not f.get("miss") or not recent):
                continue
            todo.append((kind, when, u1, u2))
        todo.sort(key=lambda t: t[1], reverse=True)       # newest first
        todo.sort(key=lambda t: t[0] != "m")              # monthly reports first (quick, they cover all years)
        listed = set(monthly.values()) | {v[1] for v in daily.values()}
        _yh["total"] = len(todo)
        if not monthly and not daily and not todo:
            _yh["errors"].append("No PDF links were found on the YSX historical-data pages. The site may have changed.")
        bad = ok = 0
        for k, (kind, when, url, alt) in enumerate(todo):
            if _yh["stop"]:
                break
            _yh.update(phase=("Monthly reports" if kind == "m" else "Daily reports") + " (" + when + ")", done=k)
            guessed = url not in listed
            try:
                try:
                    raw = _ysx_get(url)
                except urllib.error.HTTPError as e:
                    if e.code == 404 and alt:
                        url = alt
                        raw = _ysx_get(url)
                    else:
                        raise
                text, how = pdf_text(raw)
                rows = parse_ysx_monthly(text) if kind == "m" else parse_ysx_daily(text)
                c["files"][url] = {"k": kind, "d": when, "ok": True, "rows": rows}
                ok += bool(rows)
                bad += not rows
            except RuntimeError as e:  # cannot read PDFs at all: stop early, say how to fix
                _yh["errors"].append(str(e)); _yh["msg"] = str(e); break
            except urllib.error.HTTPError as e:
                if guessed and e.code in (404, 403):   # no report for that date (holiday, or not published yet)
                    c["files"][url] = {"k": kind, "d": when, "ok": False, "miss": True, "t": int(now_ms)}
                else:
                    c["files"][url] = {"k": kind, "d": when, "ok": False, "err": str(e)[:160]}
                    bad += 1
                    if len(_yh["errors"]) < 12:
                        _yh["errors"].append("%s: %s" % (url.rsplit("/", 1)[-1], e))
            except Exception as e:
                c["files"][url] = {"k": kind, "d": when, "ok": False, "err": str(e)[:160]}
                bad += 1
                if len(_yh["errors"]) < 12:
                    _yh["errors"].append("%s: %s" % (url.rsplit("/", 1)[-1], e))
            if k % 20 == 19:
                _yh_save()
            time.sleep(0.2)
        c["at"] = int(time.time() * 1000)
        _yh_save()
        _yh.update(done=_yh["total"] if not _yh["stop"] else _yh["done"], state="done", phase="Finished" if not _yh["stop"] else "Stopped", msg=_yh["msg"] or "%d reports read, %d with nothing usable" % (ok, bad))
    except Exception as e:
        _yh.update(state="error", msg=str(e))


def ysx_hist_start(refresh=False, all_daily=False):
    with _yh_lock:
        if _yh["state"] == "running":
            return False
        _yh["state"] = "running"
    threading.Thread(target=ysx_hist_job, args=(refresh, all_daily), daemon=True).start()
    return True


def ysx_hist_data():
    c = _yh_load()
    stocks = {}
    for u, f in c["files"].items():
        if not f.get("ok"):
            continue
        for r in f.get("rows") or []:
            s = stocks.setdefault(r[0], {"d": {}, "m": {}})
            if f["k"] == "d":
                s["d"][f["d"]] = r[1:]
            else:
                s["m"][f["d"] + "-01"] = r[1:]
    out = {k: {"d": [[d] + v for d, v in sorted(s["d"].items())], "m": [[d] + v for d, v in sorted(s["m"].items())]} for k, s in stocks.items()}
    files = c["files"].values()
    return {"stocks": out, "at": c.get("at", 0), "found": c.get("found", {}), "files": {"ok": sum(1 for f in files if f.get("ok") and f.get("rows")), "empty": sum(1 for f in files if f.get("ok") and not f.get("rows")), "failed": sum(1 for f in files if not f.get("ok") and not f.get("miss")), "missing": sum(1 for f in files if f.get("miss"))}}


def ysx_hist_sample(url):
    if urllib.parse.urlparse(url).hostname not in ("ysx-mm.com", "www.ysx-mm.com"):
        raise ValueError("Only ysx-mm.com links")
    text, how = pdf_text(_ysx_get(url))
    name = url.rsplit("/", 1)[-1]
    kind = "m" if re.match(r"hd_\d{6}\.pdf$", name, re.I) else "d"
    rows = parse_ysx_monthly(text) if kind == "m" else parse_ysx_daily(text)
    return {"url": url, "reader": how, "kind": kind, "rows": rows, "text": text[:7000]}


class Handler(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        url = urllib.parse.urlparse(self.path)
        if _lan_gate(self, url.path, True):
            return
        if url.path in ("/settrade/config", "/settrade/watch"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 100_000)
                body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                if url.path == "/settrade/watch":
                    _st["watch"] = [str(x).upper() for x in body.get("symbols", []) if re.match(r"^[A-Za-z0-9&\-]{1,16}$", str(x))][:300]
                    return self._send(200, b'{"ok":true}', "application/json")
                return self._send(200, json.dumps(settrade_masked(settrade_save(body))).encode(), "application/json")
            except Exception as e:
                return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
        if url.path == "/tfex/config":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 100_000)
                body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                return self._send(200, json.dumps(tfex_masked(tfex_save(body))).encode(), "application/json")
            except Exception as e:
                return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
        if url.path in ("/robot/config", "/robot/arm", "/robot/disarm", "/robot/kill", "/robot/resume", "/robot/order", "/robot/cancel", "/robot/audit", "/robot/equity", "/robot/guard", "/robot/entry", "/robot/shock"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 50_000)
                body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                p = url.path
                if p == "/robot/config":
                    r = dict(robot_status(), cfg=robot_save(body))
                elif p == "/robot/arm":
                    r = robot_arm(body)
                elif p == "/robot/disarm":
                    r = robot_disarm("disarmed by you")
                elif p == "/robot/kill":
                    r = robot_kill(str(body.get("reason") or "kill switch pressed"))
                elif p == "/robot/resume":
                    r = robot_resume(body)
                elif p == "/robot/order":
                    r = robot_order(body)
                elif p == "/robot/cancel":
                    r = robot_cancel(body)
                elif p == "/robot/equity":
                    r = robot_equity(body)
                elif p == "/robot/guard":
                    r = robot_guard_set(body)
                elif p == "/robot/entry":
                    r = robot_entry_set(body)
                elif p == "/robot/shock":
                    r = robot_shock_set(body)
                else:
                    robot_audit(str(body.get("kind") or "note"), body.get("data") if isinstance(body.get("data"), (dict, list)) else str(body.get("data") or ""))
                    r = {"ok": True}
                return self._send(200, json.dumps(r).encode(), "application/json")
            except Exception as e:
                return self._send(400, json.dumps({"error": str(e)[:200]}).encode(), "application/json")
        if url.path == "/ytmeta":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 60_000)
                body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                return self._send(200, json.dumps(yt_meta(body.get("urls") or [])).encode(), "application/json")
            except Exception as e:
                return self._send(400, json.dumps({"error": str(e)[:200]}).encode(), "application/json")
        if url.path in ("/trade/config", "/trade/preview", "/trade/place", "/trade/cancel"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 20_000)
                body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                fn = {"/trade/config": lambda b: dict(trade_save(b), ok=True), "/trade/preview": trade_preview, "/trade/place": trade_place, "/trade/cancel": trade_cancel}[url.path]
                return self._send(200, json.dumps(fn(body)).encode(), "application/json")
            except Exception as e:
                return self._send(400, json.dumps({"error": str(e)[:200]}).encode(), "application/json")
        if url.path in ("/notify/config", "/notify/send", "/notify/daily"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 100_000)
                body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                if url.path == "/notify/config":
                    return self._send(200, json.dumps(notify_masked(notify_save(body))).encode(), "application/json")
                if url.path == "/notify/daily":
                    return self._send(200, json.dumps(daily_report_send(force=True) or {"_none": {"ok": False, "error": "No phone channel is set up yet."}}).encode(), "application/json")
                return self._send(200, json.dumps(notify_send(body.get("title"), body.get("text"))).encode(), "application/json")
            except Exception as e:
                return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
        if url.path != "/translate":
            return self._send(404, b"Not found", "text/plain")
        try:
            n = min(int(self.headers.get("Content-Length") or 0), 2_000_000)
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
            strings = [s for s in body.get("strings", []) if isinstance(s, str)][:400]
            tr, failed = translate_many(strings)
            return self._send(200, json.dumps({"tr": tr, "untranslated": failed}).encode(), "application/json")
        except Exception as e:
            return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Robodel-Token")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()

    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        if _lan_gate(self, url.path, False):
            return
        if url.path == "/lan/info":
            if not _is_loopback(self.client_address[0]):
                return self._send(403, b'{"ok":false,"error":"Only the computer itself can read the pairing code."}', "application/json")
            return self._send(200, json.dumps({"ok": True, "on": LAN_ON, "ips": lan_ips() if LAN_ON else [], "port": self.server.server_address[1], "token": lan_token() if LAN_ON else ""}).encode(), "application/json")
        if url.path == "/manifest.webmanifest":
            return self._send(200, PWA_MANIFEST.encode(), "application/manifest+json")
        if url.path == "/sw.js":
            return self._send(200, PWA_SW.encode(), "application/javascript")
        if url.path in ("/icon-192.png", "/icon-512.png"):
            return self._send(200, PWA_ICON_192 if "192" in url.path else PWA_ICON_512, "image/png")
        if url.path == "/lan/check":
            return self._send(200, b'{"ok":true}', "application/json")

        if url.path == "/proxy":
            target = urllib.parse.parse_qs(url.query).get("url", [""])[0]
            host = urllib.parse.urlparse(target).hostname
            if host not in ALLOWED_HOSTS:
                return self._send(403, b'{"error":"Only Yahoo Finance is relayed"}', "application/json")
            try:
                with _open(target) as r:
                    return self._send(r.status, r.read(), "application/json")
            except urllib.error.HTTPError as e:
                return self._send(e.code, e.read() or b"{}", "application/json")
            except Exception as e:  # network error, timeout
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/fund":
            symbol = urllib.parse.parse_qs(url.query).get("symbol", [""])[0]
            if not SYMBOL_RE.match(symbol):
                return self._send(400, b'{"error":"Bad symbol"}', "application/json")
            try:
                code, body = fetch_fundamentals(symbol)
                return self._send(code, body, "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/finhist":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            qs = urllib.parse.parse_qs(url.query); symbol = (qs.get("symbol", [""])[0] or "").upper()
            if not SYMBOL_RE.match(symbol):
                return self._send(400, b'{"error":"Bad symbol"}', "application/json")
            try:
                return self._send(200, json.dumps(fh_get(symbol, qs.get("refresh", ["0"])[0] == "1")).encode(), "application/json")
            except Exception as e:
                return self._send(200, json.dumps({"ok": False, "error": str(e)[:200]}).encode(), "application/json")

        if url.path == "/quote":
            syms = [x for x in urllib.parse.parse_qs(url.query).get("symbols", [""])[0].split(",") if x]
            if not syms or len(syms) > 300 or not all(SYMBOL_RE.match(x) for x in syms):
                return self._send(400, b'{"error":"Bad symbols"}', "application/json")
            try:
                code, body = fetch_quotes(syms)
            except Exception as e:
                code, body = 502, json.dumps({"error": str(e)}).encode()
            try:
                c2, b2 = settrade_overlay(syms, code, body if code == 200 else b"")
                if c2 == 200 and (code != 200 or b2 is not body):
                    code, body = c2, b2
            except Exception as e:
                _st["err"] = str(e)[:200]
            return self._send(code, body, "application/json")

        if url.path in ("/selfcheck", "/ticks/status"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                r = selfcheck() if url.path == "/selfcheck" else dict(tick_status(), ok=True)
                return self._send(200, json.dumps(r, default=str).encode(), "application/json")
            except Exception as e:
                return self._send(200, json.dumps({"ok": False, "error": str(e)[:200]}).encode(), "application/json")

        if url.path in ("/speed", "/robot/shock"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            if url.path == "/speed":
                return self._send(200, json.dumps(speed_test()).encode(), "application/json")
            _shock_load()
            return self._send(200, json.dumps(dict(_shock, ok=True, blocking=shock_blocks())).encode(), "application/json")
        if url.path == "/robot/entries":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            return self._send(200, json.dumps(robot_entries()).encode(), "application/json")
        if url.path == "/robot/guards":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                since = int(urllib.parse.parse_qs(url.query).get("since", ["0"])[0] or 0)
            except Exception:
                since = 0
            return self._send(200, json.dumps(robot_guards(since)).encode(), "application/json")

        if url.path in ("/robot/status", "/robot/log"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            if url.path == "/robot/status":
                r = robot_status()
            else:
                r = {"ok": True, "log": robot_log(int((urllib.parse.parse_qs(url.query).get("n", ["200"])[0] or 200)))}
            return self._send(200, json.dumps(r).encode(), "application/json")

        if url.path in ("/trade/config", "/trade/orders", "/trade/account"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            r = {"/trade/config": lambda: dict(trade_cfg(), ok=True), "/trade/orders": trade_orders, "/trade/account": trade_account}[url.path]()
            return self._send(200, json.dumps(r).encode(), "application/json")

        if url.path == "/settrade/config":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            return self._send(200, json.dumps(settrade_masked(settrade_load())).encode(), "application/json")

        if url.path == "/settrade/live":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            qs = urllib.parse.parse_qs(url.query)
            ok = lambda x: re.match(r"^[A-Za-z0-9&\-]{1,16}$", x)
            syms = [x.upper() for x in qs.get("symbols", [""])[0].split(",") if ok(x)][:200]
            sweep = [x.upper() for x in qs.get("sweep", [""])[0].split(",") if ok(x)][:1500] if "sweep" in qs else None
            try:
                since = int(qs.get("since", ["0"])[0])
            except Exception:
                since = 0
            foc = [x.upper() for x in qs.get("focus", [""])[0].split(",") if ok(x)][:3]
            prio = [x.upper() for x in qs.get("prio", [""])[0].split(",") if ok(x)][:30]
            fast = qs.get("fast", ["0"])[0] == "1"
            try:
                return self._send(200, json.dumps(live_snapshot(syms, foc, fast, prio, sweep, since)).encode(), "application/json")
            except Exception as e:
                return self._send(200, json.dumps({"ok": False, "error": str(e)[:200]}).encode(), "application/json")

        if url.path == "/settrade/days":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            sym = urllib.parse.parse_qs(url.query).get("sym", [""])[0].upper()
            if not re.match(r"^[A-Za-z0-9&\-]{1,16}$", sym):
                return self._send(400, b'{"error":"bad symbol"}', "application/json")
            with _lv_lock:
                cur = {"day": _bkk_day(), "bs": _lv["bs"].get(sym, [0, 0, 0]), "since": _lv["since"].get(sym), "big": len([e for e in _lv["big"] if e.get("sym") == sym]),
                       "top": (lambda v: list(max(v, key=lambda x: x[1])) if v else None)([(p, sum(r)) for p, r in _lv["vp"].get(sym, {}).items()])}
            return self._send(200, json.dumps({"ok": True, "today": cur, "days": [d for d in live_days(sym) if d["day"] != cur["day"]]}).encode(), "application/json")

        if url.path == "/settrade/test":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            cfg = settrade_load()
            try:
                if not (cfg.get("broker_id") and cfg.get("app_code") and cfg.get("app_id") and cfg.get("app_secret")):
                    raise RuntimeError("Fill in and save all four fields first.")
                _st["keys"] = []
                got = settrade_quotes(["PTT"], cfg)
                if not got:
                    raise RuntimeError(_st["err"] or "Logged in, but no quote came back for PTT.")
                return self._send(200, json.dumps({"ok": True, "symbol": "PTT", "quote": got["PTT"], "fields": _st["keys"]}).encode(), "application/json")
            except Exception as e:
                return self._send(200, json.dumps({"ok": False, "error": str(e)[:300], "fields": _st["keys"]}).encode(), "application/json")

        if url.path in ("/tfex/config", "/tfex/test", "/tfex/quotes", "/tfex/account"):
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            try:
                if url.path == "/tfex/config":
                    return self._send(200, json.dumps(tfex_masked(tfex_load())).encode(), "application/json")
                if url.path == "/tfex/test":
                    return self._send(200, json.dumps(tfex_test()).encode(), "application/json")
                if url.path == "/tfex/account":
                    return self._send(200, json.dumps(dict(tfex_account(), ok=True), default=str).encode(), "application/json")
                syms = [x for x in urllib.parse.parse_qs(url.query).get("symbols", [""])[0].split(",") if x]
                if not syms or len(syms) > 80 or not all(_TFEX_SYM.match(x) for x in syms):
                    return self._send(400, b'{"error":"Bad symbols"}', "application/json")
                got, errs = tfex_quotes([x.upper() for x in syms])
                return self._send(200, json.dumps({"ok": True, "quotes": got, "missing": [x.upper() for x in syms if x.upper() not in got], "err": "; ".join(errs[:2]), "at": int(time.time() * 1000)}).encode(), "application/json")
            except Exception as e:
                return self._send(200, json.dumps({"ok": False, "error": str(e)[:300]}).encode(), "application/json")

        if url.path == "/siamchart/table":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            try:
                return self._send(200, json.dumps(siam_table(q.get("url"), q.get("force") == "1")).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/signs":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            try:
                return self._send(200, json.dumps(signs_fetch(q.get("url"))).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/notify/config":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            return self._send(200, json.dumps(notify_masked(notify_load())).encode(), "application/json")

        if url.path == "/ysx":
            try:
                force = urllib.parse.parse_qs(url.query).get("force", [""])[0] == "1"
                return self._send(200, json.dumps(ysx_fetch(force)).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/wb":
            try:
                return self._send(200, wb_mcap(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path.startswith("/ysxhist/"):
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            try:
                sub = url.path.split("/ysxhist/", 1)[1]
                if sub == "start":
                    started = ysx_hist_start(q.get("refresh") == "1", q.get("all") == "1")
                    return self._send(200, json.dumps({"started": started}).encode(), "application/json")
                if sub == "stop":
                    _yh["stop"] = True
                    return self._send(200, b'{"ok":true}', "application/json")
                if sub == "status":
                    st = {k: v for k, v in _yh.items() if k != "stop"}
                    st["elapsed"] = int(time.time() - _yh["t0"]) if _yh["t0"] else 0
                    return self._send(200, json.dumps(st).encode(), "application/json")
                if sub == "data":
                    return self._send(200, json.dumps(ysx_hist_data()).encode(), "application/json")
                if sub == "sample":
                    return self._send(200, json.dumps(ysx_hist_sample(q.get("url", ""))).encode(), "application/json")
                return self._send(404, b'{"error":"unknown"}', "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/health":
            if not _local_origin(self):
                return self._send(403, b'{"error":"Not allowed from this site"}', "application/json")
            return self._send(200, json.dumps(health_report()).encode(), "application/json")

        if url.path == "/ping":
            return self._send(200, b'{"ok":true,"version":"8.65"}', "application/json")

        if url.path == "/investor":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            try:
                return self._send(200, json.dumps(investor_fetch(q.get("url"))).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/dw/list":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            try:
                return self._send(200, json.dumps(dw_list(q.get("force") == "1", q.get("url"))).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/dw/history":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            sym = (q.get("sym") or "").upper()
            if not DW_RE.match(sym):
                return self._send(400, json.dumps({"ok": False, "error": "not a DW symbol"}).encode(), "application/json")
            try:
                return self._send(200, json.dumps(dw_history(sym, q.get("force") == "1")).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/dw/quotes":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            syms = [x for x in re.split(r"[,\s]+", (q.get("syms") or "").upper()) if DW_RE.match(x)][:60]
            try:
                return self._send(200, json.dumps(dw_quotes(syms)).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/wr/list":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            try:
                return self._send(200, json.dumps(wr_list(q.get("force") == "1", q.get("url"))).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/wr/history":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            sym = (q.get("sym") or "").upper()
            if not WR_RE.match(sym):
                return self._send(400, json.dumps({"ok": False, "error": "not a warrant symbol"}).encode(), "application/json")
            try:
                return self._send(200, json.dumps(wr_history(sym, q.get("force") == "1")).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/wr/quotes":
            q = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            syms = [x for x in re.split(r"[,\s]+", (q.get("syms") or "").upper()) if WR_RE.match(x)][:60]
            try:
                return self._send(200, json.dumps(wr_quotes(syms)).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/companies":
            try:
                return self._send(200, json.dumps(fetch_companies(urllib.parse.parse_qs(url.query).get("force") == ["1"])).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"ok": False, "error": str(e)}).encode(), "application/json")

        if url.path == "/iaa":
            symbol = urllib.parse.parse_qs(url.query).get("symbol", [""])[0]
            if not SYMBOL_RE.match(symbol):
                return self._send(400, b'{"error":"Bad symbol"}', "application/json")
            try:
                return self._send(200, json.dumps(fetch_iaa(symbol)).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/9hoon":
            qs = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            page = qs.pop("page_name", qs.pop("p", ""))
            check = qs.pop("check", "") == "1"
            lang = qs.pop("lang", "")
            try:
                data = fetch_9hoon(page, qs, check)
                if lang == "en" and not check:
                    data = translate_9hoon(dict(data), page)
                return self._send(200, json.dumps(data).encode(), "application/json")
            except ValueError as e:
                return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/drratios":
            try:
                return self._send(200, json.dumps(fetch_dr_ratios()).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/drlist":
            try:
                return self._send(200, json.dumps(fetch_dr_list()).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/macronews":
            qs = urllib.parse.parse_qs(url.query)
            try:
                return self._send(200, json.dumps(macro_news(qs.get("region", ["th"])[0], qs.get("topic", ["all"])[0], qs.get("force", [""])[0] == "1")).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)[:200]}).encode(), "application/json")

        if url.path == "/idxnews":
            qs = urllib.parse.parse_qs(url.query)
            name = qs.get("name", [""])[0][:80].strip()
            country = qs.get("country", [""])[0][:60].strip()
            if len(name) < 2:
                return self._send(400, b'{"error":"Bad name"}', "application/json")
            try:
                return self._send(200, json.dumps(index_news(name, country, qs.get("sym", [""])[0])).encode(), "application/json")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}).encode(), "application/json")

        if url.path == "/watchnews":
            qs = urllib.parse.parse_qs(url.query)
            syms = [x.upper() for x in qs.get("symbols", [""])[0].split(",") if SYMBOL_RE.match(x.upper())][:15]
            return self._send(200, json.dumps(watch_news(syms)).encode(), "application/json")

        if url.path == "/news":
            qs = urllib.parse.parse_qs(url.query)
            symbol = qs.get("symbol", [""])[0].upper()
            name = qs.get("name", [""])[0][:120]
            if not SYMBOL_RE.match(symbol):
                return self._send(400, b'{"error":"Bad symbol"}', "application/json")
            if qs.get("kind", [""])[0] == "dr":
                return self._send(200, json.dumps(fetch_dr_news(symbol, name)).encode(), "application/json")
            return self._send(200, json.dumps(fetch_news(symbol, name)).encode(), "application/json")

        if url.path == "/siamchart/probe":
            data = siam_probe()
            body = json.dumps(data, ensure_ascii=False, indent=1)
            page = ("<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                    "<title>SiamChart probe</title><body style='font:14px system-ui,sans-serif;margin:16px'>"
                    "<h2>SiamChart probe</h2><p>Press the button, then paste the copied text into the chat with Claude.</p>"
                    "<button onclick=\"navigator.clipboard.writeText(document.getElementById('o').textContent).then(()=>this.textContent='Copied')\" "
                    "style='font-size:16px;padding:8px 16px'>Copy result</button>"
                    "<pre id='o' style='white-space:pre-wrap;word-break:break-all;background:#f4f4f4;padding:10px;border-radius:8px'>"
                    + htmllib.escape(body) + "</pre></body>")
            return self._send(200, page.encode("utf-8"), "text/html; charset=utf-8")

        if url.path == "/status":
            return self._send(200, status_page().encode("utf-8"), "text/html; charset=utf-8")

        if url.path in ("/", "/index.html", "/" + PAGE):
            path = pick_page()
            if not path:
                return self._send(404, status_page(missing=True).encode("utf-8"), "text/html; charset=utf-8")
            try:
                with open(path, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            except Exception as e:
                PAGE_ERRORS[path] = str(e)
                return self._send(500, status_page(missing=True).encode("utf-8"), "text/html; charset=utf-8")

        self._send(404, b"Not found", "text/plain")

    def log_message(self, fmt, *args):
        pass


CHECKS = {}


def run_checks():
    """Startup self-test, also shown at /status."""
    CHECKS["python"] = f"{platform.python_version()} on {'Android' if IS_ANDROID else platform.system()}"
    CHECKS["certificates"] = SSL_SOURCE
    page = pick_page()
    CHECKS["page"] = page or "NOT FOUND"
    try:
        with _open("https://query1.finance.yahoo.com/v8/finance/chart/%5ESET.BK?range=5d&interval=1d", 12) as r:
            r.read(200)
        CHECKS["internet"] = "OK (Yahoo Finance reachable over HTTPS)"
    except ssl.SSLError as e:
        CHECKS["internet"] = f"HTTPS certificate problem: {e}. Fix: install certifi (Pydroid 3: menu > Pip > certifi; others: pip install certifi), then restart."
    except urllib.error.HTTPError as e:
        CHECKS["internet"] = f"OK (Yahoo answered HTTP {e.code})"
    except Exception as e:
        msg = str(e)
        hint = " Fix: install certifi (Pydroid 3: menu > Pip > certifi), then restart." if "CERTIFICATE" in msg.upper() else " Check the phone or PC is online."
        CHECKS["internet"] = f"FAILED: {msg}.{hint}"
    return CHECKS


def status_page(missing=False):
    esc = htmllib.escape
    rows = "".join(f"<tr><th>{esc(k)}</th><td>{esc(str(v))}</td></tr>" for k, v in CHECKS.items())
    folders = "".join(f"<li>{esc(d)}{' &mdash; ' + esc(PAGE_ERRORS[d]) if d in PAGE_ERRORS else ''}</li>" for d in page_folders())
    perm = ""
    if PAGE_ERRORS and IS_ANDROID:
        perm = ("<p><b>Android blocked access to a folder.</b> Allow file access: Settings &gt; Apps &gt; Pydroid 3 &gt; "
                "Permissions &gt; Files (or &lsquo;All files&rsquo;), then restart the helper. Or save the page in the same "
                "folder as proxy.py.</p>")
    head = (f"<h1>Page file not found</h1><p>Save <b>{PAGE}</b> (any file named Robodel*.html works) in one of these folders, then reload this page:</p>"
            if missing else "<h1>Robodel 8.65 helper status</h1>")
    return (f"<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>Robodel 8.65 helper</title><body style='font:15px/1.5 system-ui,sans-serif;max-width:760px;margin:24px auto;padding:0 16px'>"
            f"{head}{perm}<ul>{folders}</ul><table style='border-collapse:collapse'>{rows}</table>"
            f"<p style='color:#666'>Developed by Henry Poudel</p></body>")


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    # On Windows this flag lets two copies share a port, so an old copy could keep
    # answering with an old page. Only use it elsewhere.
    allow_reuse_address = not IS_WINDOWS


def _bind():
    last = None
    for port in range(PORT, PORT + 10):
        try:
            return Server(("0.0.0.0" if LAN_ON else "127.0.0.1", port), Handler), port
        except OSError as e:
            last = e
    raise OSError(f"Ports {PORT}-{PORT + 9} are all in use ({last}). Close other copies of the helper and try again.")


def main():
    if "--kill" in sys.argv[1:]:
        with open(KILL_FILE, "w", encoding="utf-8") as f:
            f.write("kill " + time.strftime("%Y-%m-%d %H:%M:%S"))
        print("KILL file written. A running helper stops the robot within 2 seconds and cancels open orders if it was armed.")
        print("To resume later, use the Robot page (type RESUME ROBOT).")
        return
    for _a, _act in (("--install", "install"), ("--uninstall", "uninstall")):
        if _a in sys.argv[1:]:
            autostart(_act, dry="--dry" in sys.argv[1:])
            return
    threading.Thread(target=_rb_watch, daemon=True).start()
    threading.Thread(target=_dr_loop, daemon=True).start()
    with _en["lock"]:
        _en_load()
        if _en["e"]:
            _en["th"] = threading.Thread(target=_en_loop, daemon=True)
            _en["th"].start()
    with _gd["lock"]:
        _gd_load()
        if _gd["g"]:
            _gd["th"] = threading.Thread(target=_gd_loop, daemon=True)
            _gd["th"].start()
    for arg in sys.argv[1:] + ([os.environ["SCANNER_DIR"]] if os.environ.get("SCANNER_DIR") else []):
        EXTRA_DIRS.append(arg if os.path.isdir(arg) else os.path.dirname(os.path.abspath(arg)))
    global LAN_ON
    LAN_ON = ("--lan" in sys.argv[1:]) or os.environ.get("ROBODEL_LAN") == "1"
    httpd, port = _bind()
    url = f"http://localhost:{port}"
    print("Robodel 8.65 helper - Developed by Henry Poudel")
    print(f"Open {url} in your browser   (status: {url}/status)")
    if LAN_ON:
        print("PHONE ACCESS IS ON (--lan). Your phone must be on the same Wi-Fi.")
        for ip in lan_ips():
            print(f"  Helper address for the phone:  http://{ip}:{port}")
        print(f"  Pairing code (type it in the app, never share it):  {lan_token()}")
        print("  Your PIN and API secrets are never accepted over Wi-Fi. Use only a Wi-Fi you trust.")
    if port != PORT:
        print(f"Note: port {PORT} was busy, so {port} is used instead.")
    for k, v in run_checks().items():
        print(f"  {k:<13} {v}")
    if CHECKS.get("page") == "NOT FOUND":
        print(f"  -> Save {PAGE} next to proxy.py or in Downloads, then reload the browser page.")
    if IS_ANDROID:
        print("Android: keep Pydroid running (switch to Chrome with the Recent apps button,")
        print("or use split screen). Android may pause apps left in the background.")
    print("Press Ctrl+C (or Pydroid's stop button) to stop.")
    if not os.environ.get("NO_BROWSER"):
        def _open_browser():
            try:
                import webbrowser
                webbrowser.open(url)
            except Exception:
                pass
        threading.Timer(1.0, _open_browser).start()
    with httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception:
        traceback.print_exc()
        print("\nThe helper stopped because of the error above.")
        if IS_WINDOWS and sys.stdin and sys.stdin.isatty():
            try:
                input("Press Enter to close this window...")
            except Exception:
                pass
