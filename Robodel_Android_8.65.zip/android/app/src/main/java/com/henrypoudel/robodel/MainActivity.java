package com.henrypoudel.robodel;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
