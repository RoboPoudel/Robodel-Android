package com.henrypoudel.robodel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/** Keeps the Robodel helper (Python) running inside the app, with a visible notification so Android does not stop it. */
public class HelperService extends Service {
    private static boolean started = false;
    private PowerManager.WakeLock wake;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String ch = "robodel_helper";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            nm.createNotificationChannel(new NotificationChannel(ch, "Robodel helper", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new NotificationCompat.Builder(this, ch)
                .setContentTitle("Robodel helper is running")
                .setContentText("Live prices, alerts and the robot need it. Tap to open.")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
        ServiceCompat.startForeground(this, 1, n, Build.VERSION.SDK_INT >= 34 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE : 0);
        if (wake == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) { wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "robodel:helper"); wake.setReferenceCounted(false); wake.acquire(); }
        }
        if (!started) {
            started = true;
            final String dir = getFilesDir().getAbsolutePath();
            Thread t = new Thread(() -> {
                try {
                    if (!Python.isStarted()) Python.start(new AndroidPlatform(getApplicationContext()));
                    Python.getInstance().getModule("android_main").callAttr("run", dir);
                } catch (Throwable e) {
                    android.util.Log.e("Robodel", "Helper stopped: " + e);
                    started = false;
                }
            }, "robodel-helper");
            t.setDaemon(true);
            t.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (wake != null && wake.isHeld()) wake.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
