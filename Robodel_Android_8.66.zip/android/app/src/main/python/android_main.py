"""Starts the Robodel helper inside the Android app (Chaquopy). The helper is the same file as on a computer."""
import os, sys, threading

_started = False


def run(files_dir):
    global _started
    if _started:
        return
    _started = True
    os.environ["HOME"] = files_dir            # the helper keeps its settings and keys in the app's private storage
    os.environ["ROBODEL_DATA"] = files_dir
    os.environ["NO_BROWSER"] = "1"
    os.environ.setdefault("PORT", "8787")
    try:
        import certifi
        os.environ["SSL_CERT_FILE"] = certifi.where()
        os.environ["REQUESTS_CA_BUNDLE"] = certifi.where()
    except Exception as e:
        print("certifi not available:", e)
    try:
        os.chdir(files_dir)
    except Exception:
        pass
    sys.argv = ["robodel8.py"]
    import robodel8
    robodel8.main()                           # blocks: serves http://localhost:8787 for the page in this app
